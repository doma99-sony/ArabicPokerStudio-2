var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// server/index.ts
import express2 from "express";

// server/routes.ts
import { createServer } from "http";

// server/storage.ts
import createMemoryStore from "memorystore";
import session from "express-session";
import fs from "fs";
import path from "path";

// server/card-utils.ts
function createDeck() {
  const suits = ["hearts", "diamonds", "clubs", "spades"];
  const values = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];
  const deck = [];
  for (const suit of suits) {
    for (const value of values) {
      deck.push({ suit, value });
    }
  }
  return deck;
}
function shuffleDeck(deck) {
  const shuffled = [...deck];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}
function dealCardsToPlayer(deck, count) {
  const hand = [];
  for (let i = 0; i < count; i++) {
    if (deck.length > 0) {
      const card = deck.pop();
      hand.push(card);
    }
  }
  return hand;
}

// server/game-room.ts
var gameStateCache = /* @__PURE__ */ new Map();
function createGameRoom(table) {
  const players = /* @__PURE__ */ new Map();
  setInterval(() => {
    gameStateCache.clear();
  }, 6e4);
  let round = {
    roundNumber: 1,
    deck: shuffleDeck(createDeck()),
    communityCards: [],
    pot: 0,
    currentBet: 0,
    dealer: 0,
    smallBlind: table.smallBlind,
    bigBlind: table.bigBlind,
    currentTurn: 0,
    lastRaisePosition: 0,
    gameStatus: "waiting",
    turnStartTime: Date.now(),
    // تهيئة وقت بدء الدور
    gameHistory: []
    // تهيئة سجل أحداث اللعبة
  };
  const TURN_TIMEOUT_SECONDS = 12;
  const addEventToHistory = (action, player, playerId, amount) => {
    const historyItem = {
      id: Math.random().toString(36).substring(2, 10),
      // إنشاء معرف فريد
      round: round.roundNumber,
      action,
      player,
      playerId,
      amount,
      timestamp: Date.now()
    };
    round.gameHistory.push(historyItem);
    console.log(`\u062A\u0645 \u0625\u0636\u0627\u0641\u0629 \u062D\u062F\u062B \u0644\u0644\u0633\u062C\u0644: ${player} - ${action}${amount ? ` (${amount})` : ""}`);
  };
  const startTurnTimer = () => {
    if (round.turnTimeoutId) {
      clearTimeout(round.turnTimeoutId);
    }
    round.turnStartTime = Date.now();
    round.turnTimeoutId = setTimeout(() => {
      if (round.currentTurn === -1 || round.gameStatus === "waiting" || round.gameStatus === "showdown") {
        return;
      }
      const currentPlayer = players.get(round.currentTurn);
      if (!currentPlayer) return;
      console.log(`\u062A\u0645 \u0627\u0646\u062A\u0647\u0627\u0621 \u0648\u0642\u062A \u0627\u0644\u0644\u0627\u0639\u0628 ${currentPlayer.username} - \u064A\u062A\u0645 \u062A\u0646\u0641\u064A\u0630 \u0625\u062C\u0631\u0627\u0621 \u062A\u0644\u0642\u0627\u0626\u064A`);
      addEventToHistory("timeout", currentPlayer.username, currentPlayer.id);
      if (currentPlayer.isAI) {
        console.log(`\u0627\u0644\u0644\u0627\u0639\u0628 ${currentPlayer.username} \u0647\u0648 \u0644\u0627\u0639\u0628 \u0648\u0647\u0645\u064A (AI)\u060C \u0633\u064A\u062A\u0645 \u0627\u062A\u062E\u0627\u0630 \u0642\u0631\u0627\u0631 \u0630\u0643\u064A...`);
        let handStrength = 0.5;
        if (currentPlayer.cards && currentPlayer.cards.length > 0) {
          const ranks = currentPlayer.cards.map((card) => card.rank);
          const suits = currentPlayer.cards.map((card) => card.suit);
          const highCards = ranks.filter((r) => ["A", "K", "Q", "J", "10"].includes(r));
          handStrength += highCards.length * 0.1;
          if (ranks[0] === ranks[1]) {
            handStrength += 0.3;
          }
          if (suits[0] === suits[1]) {
            handStrength += 0.2;
          }
          if (round.communityCards.length > 0) {
            for (const card of round.communityCards) {
              if (ranks.includes(card.rank)) {
                handStrength += 0.2;
              }
              if (suits.includes(card.suit)) {
                handStrength += 0.1;
              }
            }
          }
          handStrength = Math.max(0, Math.min(1, handStrength));
        }
        let aiAction;
        let aiAmount;
        if (round.currentBet > 0 && round.currentBet > currentPlayer.betAmount) {
          const randomFactor = Math.random() * 0.3;
          if (handStrength + randomFactor > 0.7) {
            if (Math.random() < 0.6) {
              aiAction = "raise";
              const maxRaise = Math.min(currentPlayer.chips, round.currentBet * 3);
              const minRaise = round.currentBet * 2;
              aiAmount = Math.floor(minRaise + (maxRaise - minRaise) * handStrength);
            } else {
              aiAction = "call";
            }
          } else if (handStrength + randomFactor > 0.4) {
            if (Math.random() < 0.2) {
              aiAction = "raise";
              aiAmount = Math.floor(round.currentBet * 1.5);
            } else if (Math.random() < 0.7) {
              aiAction = "call";
            } else {
              aiAction = "fold";
            }
          } else {
            if (Math.random() < 0.2 && round.gameStatus === "preflop") {
              aiAction = "raise";
              aiAmount = Math.floor(round.currentBet * 2);
            } else if (Math.random() < 0.3) {
              aiAction = "call";
            } else {
              aiAction = "fold";
            }
          }
        } else {
          const randomFactor = Math.random() * 0.3;
          if (handStrength + randomFactor > 0.6) {
            if (Math.random() < 0.8) {
              aiAction = "bet";
              const minBet = round.bigBlind;
              const maxBet = Math.min(currentPlayer.chips, round.pot * 0.7);
              aiAmount = Math.floor(minBet + (maxBet - minBet) * handStrength);
            } else {
              aiAction = "check";
            }
          } else if (handStrength + randomFactor > 0.3) {
            if (Math.random() < 0.3) {
              aiAction = "bet";
              aiAmount = Math.floor(round.bigBlind * 2);
            } else {
              aiAction = "check";
            }
          } else {
            if (Math.random() < 0.1) {
              aiAction = "bet";
              aiAmount = Math.floor(round.bigBlind * 3);
            } else {
              aiAction = "check";
            }
          }
        }
        console.log(`\u0627\u0644\u0644\u0627\u0639\u0628 \u0627\u0644\u0648\u0647\u0645\u064A ${currentPlayer.username} \u064A\u062A\u062E\u0630 \u0642\u0631\u0627\u0631\u064B\u0627: ${aiAction} (\u0642\u0648\u0629 \u0627\u0644\u064A\u062F: ${handStrength.toFixed(2)})`);
        performAction(currentPlayer.id, aiAction, aiAmount);
        return;
      }
      const activePlayers = Array.from(players.values()).filter((p) => !p.folded);
      if (activePlayers.length === 2) {
        const winner = activePlayers.find((p) => p.id !== round.currentTurn);
        if (winner) {
          console.log(`\u064A\u0646\u0633\u062D\u0628 ${currentPlayer.username} \u0648\u0628\u0627\u0644\u062A\u0627\u0644\u064A ${winner.username} \u064A\u0641\u0648\u0632 \u062A\u0644\u0642\u0627\u0626\u064A\u0627\u064B`);
          currentPlayer.folded = true;
          addEventToHistory("fold", currentPlayer.username, currentPlayer.id);
          addEventToHistory("win", winner.username, winner.id, round.pot + currentPlayer.betAmount);
          winner.chips += round.pot + currentPlayer.betAmount;
          round.gameStatus = "showdown";
          if (round.turnTimeoutId) {
            clearTimeout(round.turnTimeoutId);
            round.turnTimeoutId = void 0;
          }
          setTimeout(() => {
            if (players.size >= 2 && round.gameStatus === "showdown") {
              startNewRound();
            }
          }, 3e3);
          return;
        }
      }
      performAction(round.currentTurn, "fold");
    }, TURN_TIMEOUT_SECONDS * 1e3);
  };
  const getAvailablePosition = () => {
    const positions = Array.from(players.values()).map((p) => p.position);
    for (let i = 0; i < table.maxPlayers; i++) {
      if (!positions.includes(i)) {
        return i;
      }
    }
    return -1;
  };
  const getNextPlayerTurn = (currentPosition) => {
    const playerArray = Array.from(players.values());
    if (playerArray.length <= 1) return -1;
    const maxPosition = playerArray.length;
    let next = (currentPosition + 1) % maxPosition;
    const startPosition = next;
    do {
      const player = playerArray.find((p) => p.position === next);
      if (player && !player.folded && player.chips > 0) {
        return player.id;
      }
      next = (next + 1) % maxPosition;
    } while (next !== startPosition);
    return -1;
  };
  const isRoundComplete = () => {
    const playerArray = Array.from(players.values());
    let activePlayers = 0;
    let matchedBets = 0;
    for (const player of playerArray) {
      if (!player.folded) {
        activePlayers++;
        if (player.isAllIn || player.betAmount === round.currentBet) {
          matchedBets++;
        }
      }
    }
    return matchedBets === activePlayers;
  };
  const advanceGameStage = () => {
    if (round.turnTimeoutId) {
      clearTimeout(round.turnTimeoutId);
      round.turnTimeoutId = void 0;
    }
    for (const player of players.values()) {
      round.pot += player.betAmount;
      player.betAmount = 0;
    }
    round.currentBet = 0;
    const stageAction = {
      id: `${Date.now()}-${Math.floor(Math.random() * 1e3)}`,
      round: round.roundNumber,
      action: round.gameStatus === "preflop" ? "flop" : round.gameStatus === "flop" ? "turn" : round.gameStatus === "turn" ? "river" : round.gameStatus === "river" ? "showdown" : "start_round",
      player: "\u0627\u0644\u0646\u0638\u0627\u0645",
      playerId: -1,
      timestamp: Date.now()
    };
    round.gameHistory.push(stageAction);
    switch (round.gameStatus) {
      case "waiting":
      case "showdown":
        startNewRound();
        break;
      case "preflop":
        round.gameStatus = "flop";
        let flopCards = [];
        for (let i = 0; i < 3; i++) {
          flopCards.push(...dealCardsToPlayer(round.deck, 1));
        }
        round.communityCards = flopCards;
        console.log("\u062A\u0645 \u062A\u0648\u0632\u064A\u0639 \u0628\u0637\u0627\u0642\u0627\u062A \u0627\u0644\u0641\u0644\u0648\u0628:", flopCards);
        round.currentTurn = getNextPlayerTurn(round.dealer);
        if (round.currentTurn !== -1) startTurnTimer();
        break;
      case "flop":
        round.gameStatus = "turn";
        const turnCard = dealCardsToPlayer(round.deck, 1);
        round.communityCards = [...round.communityCards, ...turnCard];
        console.log("\u062A\u0645 \u062A\u0648\u0632\u064A\u0639 \u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u062A\u064A\u0631\u0646:", turnCard);
        round.currentTurn = getNextPlayerTurn(round.dealer);
        if (round.currentTurn !== -1) startTurnTimer();
        break;
      case "turn":
        round.gameStatus = "river";
        const riverCard = dealCardsToPlayer(round.deck, 1);
        round.communityCards = [...round.communityCards, ...riverCard];
        console.log("\u062A\u0645 \u062A\u0648\u0632\u064A\u0639 \u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u0631\u064A\u0641\u0631:", riverCard);
        round.currentTurn = getNextPlayerTurn(round.dealer);
        if (round.currentTurn !== -1) startTurnTimer();
        break;
      case "river":
        round.gameStatus = "showdown";
        for (const player of players.values()) {
          player.cards = player.cards.map((card) => ({ ...card, hidden: false }));
        }
        break;
    }
  };
  const startNewRound = () => {
    console.log("\u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629 \u0645\u0646 \u0627\u0644\u0644\u0639\u0628...");
    round.roundNumber++;
    round.deck = shuffleDeck(createDeck());
    round.communityCards = [];
    round.pot = 0;
    round.currentBet = 0;
    const startRoundAction = {
      id: `${Date.now()}-${Math.floor(Math.random() * 1e3)}`,
      round: round.roundNumber,
      action: "start_round",
      player: "\u0627\u0644\u0646\u0638\u0627\u0645",
      playerId: -1,
      timestamp: Date.now()
    };
    round.gameHistory.push(startRoundAction);
    round.gameStatus = "preflop";
    for (const player of players.values()) {
      player.folded = false;
      player.betAmount = 0;
      player.isAllIn = false;
    }
    if (players.size > 0) {
      round.dealer = getNextPlayerTurn(round.dealer);
    }
    const playerArray = Array.from(players.values());
    let dealerIndex = playerArray.findIndex((p) => p.id === round.dealer);
    if (dealerIndex === -1) dealerIndex = 0;
    const orderedPlayers = [
      ...playerArray.slice(dealerIndex + 1),
      ...playerArray.slice(0, dealerIndex + 1)
    ];
    for (const player of orderedPlayers) {
      const firstCard = dealCardsToPlayer(round.deck, 1)[0];
      player.cards = [{ ...firstCard, hidden: false }];
      console.log(`\u062A\u0645 \u062A\u0648\u0632\u064A\u0639 \u0627\u0644\u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u0623\u0648\u0644\u0649 \u0644\u0644\u0627\u0639\u0628 ${player.username}`);
      gameStateCache.clear();
    }
    for (const player of orderedPlayers) {
      const secondCard = dealCardsToPlayer(round.deck, 1)[0];
      player.cards.push({ ...secondCard, hidden: false });
      console.log(`\u062A\u0645 \u062A\u0648\u0632\u064A\u0639 \u0627\u0644\u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u062B\u0627\u0646\u064A\u0629 \u0644\u0644\u0627\u0639\u0628 ${player.username}`);
      gameStateCache.clear();
    }
    const smallBlindPlayer = getNextPlayerTurn(round.dealer);
    if (smallBlindPlayer !== -1) {
      const player = players.get(smallBlindPlayer);
      if (player) {
        const smallBlindAmount = Math.min(player.chips, round.smallBlind);
        player.betAmount = smallBlindAmount;
        player.chips -= smallBlindAmount;
        if (player.chips === 0) player.isAllIn = true;
        round.currentBet = smallBlindAmount;
      }
    }
    const bigBlindPlayer = getNextPlayerTurn(smallBlindPlayer);
    if (bigBlindPlayer !== -1) {
      const player = players.get(bigBlindPlayer);
      if (player) {
        const bigBlindAmount = Math.min(player.chips, round.bigBlind);
        player.betAmount = bigBlindAmount;
        player.chips -= bigBlindAmount;
        if (player.chips === 0) player.isAllIn = true;
        round.currentBet = bigBlindAmount;
      }
    }
    round.currentTurn = getNextPlayerTurn(bigBlindPlayer);
    round.gameStatus = "preflop";
    if (round.currentTurn !== -1) {
      startTurnTimer();
      console.log(`\u0628\u062F\u0621 \u0645\u0624\u0642\u062A \u0627\u0646\u062A\u0638\u0627\u0631 \u0644\u0644\u0627\u0639\u0628 \u0627\u0644\u0623\u0648\u0644 ${round.currentTurn}`);
    }
  };
  const endRound = () => {
    const activePlayers = Array.from(players.values()).filter((p) => !p.folded);
    const results = [];
    if (activePlayers.length === 1) {
      const winner = activePlayers[0];
      winner.chips += round.pot;
      results.push({
        playerId: winner.id,
        chipsChange: round.pot
      });
      for (const player of players.values()) {
        if (player.id !== winner.id) {
          const lostChips = player.betAmount;
          results.push({
            playerId: player.id,
            chipsChange: -lostChips
          });
        }
      }
    } else if (activePlayers.length > 1) {
      const splitAmount = Math.floor(round.pot / activePlayers.length);
      const remainder = round.pot % activePlayers.length;
      for (let i = 0; i < activePlayers.length; i++) {
        const player = activePlayers[i];
        let winAmount = splitAmount;
        if (i === 0) winAmount += remainder;
        player.chips += winAmount;
        results.push({
          playerId: player.id,
          chipsChange: winAmount - player.betAmount
        });
      }
      for (const player of players.values()) {
        if (player.folded) {
          const lostChips = player.betAmount;
          results.push({
            playerId: player.id,
            chipsChange: -lostChips
          });
        }
      }
    }
    return results;
  };
  const isGameOver = () => {
    const activePlayers = Array.from(players.values()).filter((p) => !p.folded);
    const gameEnded = activePlayers.length <= 1 || round.gameStatus === "showdown";
    if (gameEnded) {
      console.log(`\u0627\u0644\u0644\u0639\u0628\u0629 \u0627\u0646\u062A\u0647\u062A. \u0644\u0627\u0639\u0628\u064A\u0646 \u0646\u0634\u0637\u064A\u0646: ${activePlayers.length}, \u0627\u0644\u062D\u0627\u0644\u0629: ${round.gameStatus}`);
      if (activePlayers.length === 1) {
        console.log(`\u0627\u0644\u0641\u0627\u0626\u0632 \u0628\u0627\u0644\u062C\u0648\u0644\u0629: ${activePlayers[0].username} \u0628\u0633\u0628\u0628 \u0627\u0646\u0633\u062D\u0627\u0628 \u0628\u0627\u0642\u064A \u0627\u0644\u0644\u0627\u0639\u0628\u064A\u0646`);
      }
    }
    return gameEnded;
  };
  const getGameStateForPlayer = (playerId) => {
    const playerArray = Array.from(players.values());
    const currentPlayer = players.get(playerId);
    const positionedPlayers = playerArray.map((player) => {
      return {
        id: player.id,
        username: player.username,
        chips: player.chips,
        avatar: player.avatar || "",
        position: player.id === playerId ? "bottom" : player.position === (currentPlayer?.position || 0) + 1 ? "bottomRight" : player.position === (currentPlayer?.position || 0) + 2 ? "right" : player.position === (currentPlayer?.position || 0) + 3 ? "top" : "left",
        isCurrentPlayer: player.id === playerId,
        isTurn: round.currentTurn === player.id,
        isActive: true,
        // تعيين جميع اللاعبين كنشطين
        isAllIn: player.isAllIn || false,
        isVIP: false,
        // يمكن تغييرها لاحقًا بناءً على حالة VIP للاعب
        cards: player.id === playerId || round.gameStatus === "showdown" ? player.cards : player.cards.map((card) => ({ ...card, hidden: true })),
        folded: player.folded,
        betAmount: player.betAmount
      };
    });
    let turnTimeLeft = void 0;
    if (round.currentTurn !== -1 && round.gameStatus !== "waiting" && round.gameStatus !== "showdown") {
      const elapsedTime = Math.floor((Date.now() - round.turnStartTime) / 1e3);
      turnTimeLeft = Math.max(0, TURN_TIMEOUT_SECONDS - elapsedTime);
    }
    return {
      id: table.id,
      tableName: table.name,
      players: positionedPlayers,
      communityCards: round.communityCards,
      pot: round.pot,
      dealer: round.dealer,
      currentTurn: round.currentTurn,
      smallBlind: round.smallBlind,
      bigBlind: round.bigBlind,
      round: round.roundNumber,
      currentBet: round.currentBet,
      userChips: currentPlayer?.chips || 0,
      gameStatus: round.gameStatus,
      turnTimeLeft,
      // إضافة الوقت المتبقي
      gameHistory: round.gameHistory
      // إرسال سجل الأحداث للواجهة
    };
  };
  const addPlayer = (playerId, username, chips, avatar, requestedPosition, isAI) => {
    if (players.has(playerId)) {
      return { success: false, message: "\u0627\u0644\u0644\u0627\u0639\u0628 \u0645\u0648\u062C\u0648\u062F \u0628\u0627\u0644\u0641\u0639\u0644 \u0641\u064A \u0627\u0644\u0644\u0639\u0628\u0629" };
    }
    if (players.size >= table.maxPlayers) {
      return { success: false, message: "\u0627\u0644\u0637\u0627\u0648\u0644\u0629 \u0645\u0645\u062A\u0644\u0626\u0629" };
    }
    if (chips < table.minBuyIn) {
      return { success: false, message: "\u0631\u0642\u0627\u0642\u0627\u062A \u063A\u064A\u0631 \u0643\u0627\u0641\u064A\u0629 \u0644\u0644\u0627\u0646\u0636\u0645\u0627\u0645" };
    }
    let position = -1;
    if (requestedPosition !== void 0) {
      const positions = Array.from(players.values()).map((p) => p.position);
      if (requestedPosition >= 0 && requestedPosition < table.maxPlayers && !positions.includes(requestedPosition)) {
        position = requestedPosition;
      } else {
        position = getAvailablePosition();
      }
    } else {
      position = getAvailablePosition();
    }
    if (position === -1) {
      return { success: false, message: "\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0648\u0627\u0636\u0639 \u0645\u062A\u0627\u062D\u0629" };
    }
    const player = {
      id: playerId,
      username,
      chips,
      avatar,
      position,
      cards: [],
      folded: false,
      betAmount: 0,
      isAllIn: false,
      isAI: isAI || false
      // تعيين حالة اللاعب الوهمي
    };
    players.set(playerId, player);
    if (players.size === 1) {
      round.dealer = playerId;
    }
    if (players.size >= 2 && round.gameStatus === "waiting") {
      console.log(`\u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629 \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627 - \u0639\u062F\u062F \u0627\u0644\u0644\u0627\u0639\u0628\u064A\u0646: ${players.size}`);
      setTimeout(() => {
        if (players.size >= 2 && round.gameStatus === "waiting") {
          round.gameStatus = "preflop";
          startNewRound();
          gameStateCache.clear();
          console.log(`\u062A\u0645 \u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629 \u0628\u0646\u062C\u0627\u062D - \u0627\u0644\u062D\u0627\u0644\u0629: ${round.gameStatus}`);
        }
      }, 1e3);
    }
    if (isAI && playerId < 0) {
      setInterval(() => {
        if (round.currentTurn === playerId && players.has(playerId)) {
          const aiPlayer = players.get(playerId);
          if (!aiPlayer) return;
          setTimeout(() => {
            let aiAction;
            let aiAmount;
            const rand = Math.random();
            if (round.currentBet === 0 || round.currentBet === aiPlayer.betAmount) {
              if (rand < 0.7) {
                aiAction = "check";
              } else {
                aiAction = "raise";
                aiAmount = round.currentBet + Math.min(
                  Math.floor(aiPlayer.chips * 0.2),
                  // Bet up to 20% of chips
                  round.bigBlind * 2
                  // Or double the big blind
                );
              }
            } else {
              if (rand < 0.3) {
                aiAction = "fold";
              } else if (rand < 0.8) {
                aiAction = "call";
              } else {
                aiAction = "raise";
                aiAmount = round.currentBet + Math.min(
                  Math.floor(aiPlayer.chips * 0.2),
                  round.bigBlind * 2
                );
              }
            }
            performAction(playerId, aiAction, aiAmount);
          }, 1e3);
        }
      }, 2e3);
    }
    return { success: true };
  };
  const removePlayer = (playerId) => {
    const player = players.get(playerId);
    if (!player) {
      return { success: false, message: "\u0627\u0644\u0644\u0627\u0639\u0628 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F \u0641\u064A \u0627\u0644\u0644\u0639\u0628\u0629" };
    }
    const returnedChips = player.chips;
    players.delete(playerId);
    if (round.currentTurn === playerId) {
      round.currentTurn = getNextPlayerTurn(player.position);
    }
    if (players.size === 1 && round.gameStatus !== "waiting") {
      const lastPlayer = Array.from(players.values())[0];
      lastPlayer.chips += round.pot;
      round.gameStatus = "waiting";
    }
    if (players.size === 0) {
      round = {
        roundNumber: 1,
        deck: shuffleDeck(createDeck()),
        communityCards: [],
        pot: 0,
        currentBet: 0,
        dealer: 0,
        smallBlind: table.smallBlind,
        bigBlind: table.bigBlind,
        currentTurn: 0,
        lastRaisePosition: 0,
        gameStatus: "waiting",
        turnStartTime: Date.now(),
        // إعادة تعيين وقت بدء الدور
        gameHistory: []
        // إعادة تعيين سجل الأحداث
      };
      if (round.turnTimeoutId) {
        clearTimeout(round.turnTimeoutId);
        round.turnTimeoutId = void 0;
      }
    }
    return { success: true, chips: returnedChips };
  };
  const performAction = (playerId, action, amount) => {
    if (action === "restart_round") {
      console.log(`\u0625\u062C\u0631\u0627\u0621 \u0625\u0639\u0627\u062F\u0629 \u062A\u0634\u063A\u064A\u0644 \u0627\u0644\u062C\u0648\u0644\u0629 \u0645\u0646 \u0627\u0644\u0644\u0627\u0639\u0628 ${playerId}`);
      const restartActionHistoryItem = {
        id: `${Date.now()}-${Math.floor(Math.random() * 1e3)}`,
        round: round.roundNumber,
        action: "restart_round",
        player: players.get(playerId)?.username || "\u0645\u062C\u0647\u0648\u0644",
        playerId,
        timestamp: Date.now()
      };
      round.gameHistory.push(restartActionHistoryItem);
      startNewRound();
      return {
        success: true,
        message: "\u062A\u0645 \u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629",
        gameState: getGameStateForPlayer(playerId)
      };
    }
    if (round.currentTurn !== playerId) {
      return { success: false, message: "\u0644\u064A\u0633 \u062F\u0648\u0631\u0643" };
    }
    const player = players.get(playerId);
    if (!player) {
      return { success: false, message: "\u0627\u0644\u0644\u0627\u0639\u0628 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F \u0641\u064A \u0627\u0644\u0644\u0639\u0628\u0629" };
    }
    const actionHistoryItem = {
      id: `${Date.now()}-${Math.floor(Math.random() * 1e3)}`,
      round: round.roundNumber,
      action,
      player: player.username,
      playerId: player.id,
      amount: action === "bet" || action === "raise" || action === "call" ? amount : void 0,
      timestamp: Date.now()
    };
    round.gameHistory.push(actionHistoryItem);
    switch (action) {
      case "fold":
        player.folded = true;
        break;
      case "check":
        if (round.currentBet > 0) {
          return { success: false, message: "\u0644\u0627 \u064A\u0645\u0643\u0646\u0643 \u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629\u060C \u0647\u0646\u0627\u0643 \u0631\u0647\u0627\u0646 \u062D\u0627\u0644\u064A" };
        }
        break;
      case "call":
        const callAmount = Math.min(player.chips, round.currentBet - player.betAmount);
        player.chips -= callAmount;
        player.betAmount += callAmount;
        if (player.chips === 0) player.isAllIn = true;
        break;
      case "raise":
        if (!amount || amount <= round.currentBet) {
          return { success: false, message: "\u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0645\u0628\u0644\u063A \u0627\u0644\u0631\u0641\u0639 \u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0631\u0647\u0627\u0646 \u0627\u0644\u062D\u0627\u0644\u064A" };
        }
        if (amount > player.chips + player.betAmount) {
          return { success: false, message: "\u0644\u0627 \u062A\u0645\u0644\u0643 \u0631\u0642\u0627\u0642\u0627\u062A \u0643\u0627\u0641\u064A\u0629 \u0644\u0644\u0631\u0641\u0639 \u0628\u0647\u0630\u0627 \u0627\u0644\u0645\u0628\u0644\u063A" };
        }
        const raiseAmount = amount - player.betAmount;
        player.chips -= raiseAmount;
        player.betAmount = amount;
        round.currentBet = amount;
        round.lastRaisePosition = player.position;
        if (player.chips === 0) player.isAllIn = true;
        break;
      case "all_in":
        const allInAmount = player.chips;
        player.betAmount += allInAmount;
        player.chips = 0;
        player.isAllIn = true;
        if (player.betAmount > round.currentBet) {
          round.currentBet = player.betAmount;
          round.lastRaisePosition = player.position;
        }
        break;
      case "restart_round":
        console.log(`\u0637\u0644\u0628 \u0625\u0639\u0627\u062F\u0629 \u0628\u062F\u0621 \u0627\u0644\u062C\u0648\u0644\u0629 \u0645\u0646 \u0627\u0644\u0644\u0627\u0639\u0628 ${player.username}`);
        const restartActionHistoryItem = {
          id: `${Date.now()}-${Math.floor(Math.random() * 1e3)}`,
          round: round.roundNumber,
          action: "restart_round",
          player: player.username,
          playerId: player.id,
          timestamp: Date.now()
        };
        round.gameHistory.push(restartActionHistoryItem);
        for (const [_, p] of players) {
          p.folded = false;
          p.betAmount = 0;
          p.isAllIn = false;
          p.cards = [];
        }
        startNewRound();
        gameStateCache.clear();
        return {
          success: true,
          message: "\u062A\u0645 \u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629 \u0628\u0646\u062C\u0627\u062D"
        };
      default:
        return { success: false, message: "\u0625\u062C\u0631\u0627\u0621 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D" };
    }
    round.currentTurn = getNextPlayerTurn(player.position);
    if (round.currentTurn !== -1) {
      startTurnTimer();
      console.log(`\u0628\u062F\u0621 \u0645\u0624\u0642\u062A \u0627\u0646\u062A\u0638\u0627\u0631 \u0644\u0644\u0627\u0639\u0628 ${round.currentTurn}`);
    }
    if (isRoundComplete()) {
      if (isGameOver()) {
        const results = endRound();
        for (const [_, p] of players) {
          p.folded = false;
          p.betAmount = 0;
          p.isAllIn = false;
          p.cards = [];
        }
        console.log("\u0627\u0644\u062C\u0648\u0644\u0629 \u0627\u0646\u062A\u0647\u062A\u060C \u062C\u062F\u0648\u0644\u0629 \u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629...");
        setTimeout(() => {
          if (players.size >= 2) {
            console.log("\u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629 \u062A\u0644\u0642\u0627\u0626\u064A\u0627\u064B \u0628\u0639\u062F \u0627\u0646\u062A\u0647\u0627\u0621 \u0627\u0644\u062C\u0648\u0644\u0629 \u0627\u0644\u0633\u0627\u0628\u0642\u0629...");
            startNewRound();
            gameStateCache.clear();
          }
        }, 2e3);
        return {
          success: true,
          gameEnded: true,
          results
        };
      } else {
        advanceGameStage();
      }
    }
    return { success: true };
  };
  return {
    getGameStateForPlayer,
    addPlayer,
    removePlayer,
    performAction
  };
}

// server/storage.ts
var MemStorage = class {
  // تحويل إلى عام للسماح بالوصول من routes.ts
  users;
  tables;
  gameRooms;
  playerProfiles;
  sessionStore;
  // Express session store
  currentId;
  currentTableId;
  currentGameHistoryId;
  // إضافة وظيفة لبدء جولة جديدة
  startNewRound = async (tableId) => {
    console.log(`\u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629 \u0641\u064A \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId}`);
    const gameRoom = this.gameRooms.get(tableId);
    if (!gameRoom) {
      return { success: false, message: "\u0627\u0644\u0637\u0627\u0648\u0644\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629" };
    }
    try {
      const users2 = Array.from(this.users.values());
      let anyPlayerId = -1;
      for (const user of users2) {
        const gameState = gameRoom.getGameStateForPlayer(user.id);
        if (gameState.players.some((p) => p.isCurrentPlayer)) {
          anyPlayerId = user.id;
          break;
        }
      }
      if (anyPlayerId === -1) {
        return { success: false, message: "\u0644\u0627 \u064A\u0648\u062C\u062F \u0644\u0627\u0639\u0628\u064A\u0646 \u0645\u062A\u0627\u062D\u064A\u0646 \u0639\u0644\u0649 \u0627\u0644\u0637\u0627\u0648\u0644\u0629" };
      }
      const result = await this.performGameAction(tableId, anyPlayerId, "restart_round");
      return {
        success: true,
        message: "\u062A\u0645 \u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629 \u0628\u0646\u062C\u0627\u062D",
        gameState: result.gameState
      };
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629:", error);
      return { success: false, message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629" };
    }
  };
  constructor() {
    this.users = /* @__PURE__ */ new Map();
    this.tables = /* @__PURE__ */ new Map();
    this.gameRooms = /* @__PURE__ */ new Map();
    this.playerProfiles = /* @__PURE__ */ new Map();
    this.sessionStore = new (createMemoryStore(session))({
      checkPeriod: 864e5
    });
    this.currentId = 1;
    this.currentTableId = 1;
    this.currentGameHistoryId = 1;
    this.initializeGameTables();
  }
  // Initialize some default game tables
  initializeGameTables() {
    this.createTableCategory("\u0646\u0648\u0628", 10, 20, 2e4, 5, 10, "poker");
    this.createTableCategory("\u0644\u0633\u0647 \u0628\u062A\u0639\u0644\u0645", 50, 100, 1e5, 5, 10, "poker");
    this.createTableCategory("\u0645\u062D\u062A\u0631\u0641", 250, 500, 5e5, 5, 10, "poker");
    this.createTableCategoryWithNames(
      ["\u0627\u0644\u0641\u0627\u062C\u0631 \u0627\u0644\u0645\u0635\u0631\u064A", "\u0627\u0644\u0641\u0627\u062C\u0631 \u0627\u0644\u0633\u0639\u0648\u062F\u064A", "\u0627\u0644\u0641\u0627\u062C\u0631 \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A\u064A", "\u0627\u0644\u0641\u0627\u062C\u0631 \u0627\u0644\u0643\u0648\u064A\u062A\u064A", "\u0627\u0644\u0641\u0627\u062C\u0631 \u0627\u0644\u0644\u0628\u0646\u0627\u0646\u064A", "\u0627\u0644\u0641\u0627\u062C\u0631 \u0627\u0644\u0623\u0631\u062F\u0646\u064A", "\u0627\u0644\u0641\u0627\u062C\u0631 \u0627\u0644\u0645\u063A\u0631\u0628\u064A"],
      1e5,
      2e5,
      1e6,
      5,
      "poker"
    );
    this.createTableCategoryWithNames(
      ["\u0627\u0644\u0645\u0635\u0631\u064A\u064A\u0646", "\u0627\u0644\u0633\u0639\u0648\u062F\u064A\u064A\u0646", "\u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A\u064A\u064A\u0646", "\u0627\u0644\u0643\u0648\u064A\u062A\u064A\u064A\u0646", "\u0627\u0644\u0644\u0628\u0646\u0627\u0646\u064A\u064A\u0646", "\u0627\u0644\u0623\u0631\u062F\u0646\u064A\u064A\u0646", "\u0627\u0644\u0645\u063A\u0627\u0631\u0628\u0629"],
      1e5,
      2e5,
      1e6,
      5,
      "poker"
    );
    this.createTableCategoryWithNames(
      ["\u0627\u0644\u0645\u0635\u0631\u064A\u064A\u0646 1", "\u0627\u0644\u0645\u0635\u0631\u064A\u064A\u0646 2", "\u0627\u0644\u0645\u0635\u0631\u064A\u064A\u0646 3", "\u0627\u0644\u0645\u0635\u0631\u064A\u064A\u0646 4", "\u0627\u0644\u0645\u0635\u0631\u064A\u064A\u0646 5", "\u0627\u0644\u0645\u0635\u0631\u064A\u064A\u0646 6", "\u0627\u0644\u0645\u0635\u0631\u064A\u064A\u0646 7"],
      1e5,
      2e5,
      1e6,
      5,
      "poker"
    );
    this.createTableCategoryWithNames(
      ["\u0627\u0644\u062D\u0644\u0648", "\u0627\u0644\u062D\u0627\u062F\u0642", "\u0627\u0644\u062D\u0631\u0627\u0642"],
      50,
      100,
      1e5,
      9,
      "arab_poker"
    );
    this.createTableCategory("\u0633\u0647\u0644", 10, 20, 1e4, 2, 5, "naruto");
    this.createTableCategory("\u0645\u062A\u0648\u0633\u0637", 50, 100, 5e4, 2, 5, "naruto");
    this.createTableCategory("\u0635\u0639\u0628", 500, 1e3, 5e5, 2, 5, "naruto");
    this.createTableCategory("\u0645\u0628\u062A\u062F\u0626", 10, 20, 1e4, 2, 5, "tekken");
    this.createTableCategory("\u0645\u062A\u0645\u0631\u0633", 100, 200, 1e5, 2, 5, "tekken");
    this.createTableCategory("\u0645\u062D\u062A\u0631\u0641", 1e3, 2e3, 1e6, 2, 5, "tekken");
    this.createTableCategory("\u0639\u0627\u062F\u064A", 50, 100, 1e4, 4, 5, "domino");
    this.createTableCategory("VIP", 500, 1e3, 1e5, 4, 5, "domino");
  }
  // إنشاء فئة من الطاولات
  createTableCategory(categoryName, smallBlind, bigBlind, minBuyIn, maxPlayers, tableCount, gameType) {
    for (let i = 1; i <= tableCount; i++) {
      const currentPlayers = Math.floor(Math.random() * maxPlayers);
      let status = "available";
      if (currentPlayers === maxPlayers) {
        status = "full";
      } else if (currentPlayers > 0) {
        status = "available";
      }
      const now = /* @__PURE__ */ new Date();
      const table = {
        id: this.currentTableId++,
        name: `${categoryName} ${i}`,
        smallBlind,
        bigBlind,
        minBuyIn,
        maxBuyIn: minBuyIn * 10,
        maxPlayers,
        currentPlayers,
        status,
        category: categoryName,
        // إضافة فئة الطاولة
        gameType,
        // إضافة نوع اللعبة
        createdAt: now,
        updatedAt: now,
        isVip: false,
        requiredVipLevel: 0
      };
      this.tables.set(table.id, table);
      this.gameRooms.set(table.id, createGameRoom(table));
    }
  }
  // إنشاء فئة من الطاولات بأسماء محددة
  createTableCategoryWithNames(tableNames, smallBlind, bigBlind, minBuyIn, maxPlayers, gameType) {
    for (let i = 0; i < tableNames.length; i++) {
      const tableName = tableNames[i];
      const currentPlayers = Math.floor(Math.random() * maxPlayers);
      let status = "available";
      if (currentPlayers === maxPlayers) {
        status = "full";
      } else if (currentPlayers > 0) {
        status = "available";
      }
      const now = /* @__PURE__ */ new Date();
      const table = {
        id: this.currentTableId++,
        name: tableName,
        smallBlind,
        bigBlind,
        minBuyIn,
        maxBuyIn: minBuyIn * 10,
        maxPlayers,
        currentPlayers,
        status,
        category: "\u0627\u0644\u0641\u0627\u062C\u0631",
        // فئة الطاولة
        gameType,
        isVip: true,
        requiredVipLevel: 1,
        createdAt: now,
        updatedAt: now,
        tableSettings: {}
      };
      this.tables.set(table.id, table);
      this.gameRooms.set(table.id, createGameRoom(table));
    }
  }
  // User operations
  // إضافة وظائف تحديث المستخدم
  async updateUsername(userId, username) {
    const user = this.users.get(userId);
    if (!user) return void 0;
    user.username = username;
    this.users.set(userId, user);
    return user;
  }
  // دالة عامة لتحديث بيانات المستخدم
  async updateUser(userId, updateData) {
    const user = this.users.get(userId);
    if (!user) return void 0;
    const updatedUser = { ...user, ...updateData };
    this.users.set(userId, updatedUser);
    const profile = this.playerProfiles.get(userId);
    if (profile) {
      if (updateData.username) profile.username = updateData.username;
      if (updateData.avatar) profile.avatar = updateData.avatar;
      this.playerProfiles.set(userId, profile);
    }
    console.log(`\u062A\u0645 \u062A\u062D\u062F\u064A\u062B \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u0628\u0646\u062C\u0627\u062D`);
    return updatedUser;
  }
  async uploadAvatar(userId, avatar) {
    let fileType = avatar.mimetype.split("/")[1];
    if (!fileType || !["jpeg", "jpg", "png", "gif"].includes(fileType)) {
      fileType = "jpeg";
    }
    const uniqueId = Date.now().toString();
    const relativePath = `/uploads/avatars/${userId}_${uniqueId}.${fileType}`;
    const avatarUrl = relativePath;
    const uploadDir = path.join(process.cwd(), "public/uploads/avatars");
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    try {
      const fullPath = path.join(process.cwd(), "public", relativePath);
      fs.writeFileSync(fullPath, avatar.data);
      console.log(`\u062A\u0645 \u062D\u0641\u0638 \u0635\u0648\u0631\u0629 \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0634\u062E\u0635\u064A \u0628\u0646\u062C\u0627\u062D \u0641\u064A: ${fullPath}`);
    } catch (error) {
      console.error("\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062A\u062E\u0632\u064A\u0646 \u0635\u0648\u0631\u0629 \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0634\u062E\u0635\u064A:", error);
      return `https://via.placeholder.com/150?text=user_${userId}`;
    }
    const user = this.users.get(userId);
    if (user) {
      user.avatar = avatarUrl;
      this.users.set(userId, user);
    }
    const profile = this.playerProfiles.get(userId);
    if (profile) {
      profile.avatar = avatarUrl;
      this.playerProfiles.set(userId, profile);
    }
    return avatarUrl;
  }
  async uploadCoverPhoto(userId, coverPhoto) {
    let fileType = coverPhoto.mimetype.split("/")[1];
    if (!fileType || !["jpeg", "jpg", "png", "gif"].includes(fileType)) {
      fileType = "jpeg";
    }
    const uniqueId = Date.now().toString();
    const relativePath = `/uploads/covers/${userId}_${uniqueId}.${fileType}`;
    const coverPhotoUrl = relativePath;
    const uploadDir = path.join(process.cwd(), "public/uploads/covers");
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    try {
      const fullPath = path.join(process.cwd(), "public", relativePath);
      fs.writeFileSync(fullPath, coverPhoto.data);
      console.log(`\u062A\u0645 \u062D\u0641\u0638 \u0635\u0648\u0631\u0629 \u0627\u0644\u063A\u0644\u0627\u0641 \u0628\u0646\u062C\u0627\u062D \u0641\u064A: ${fullPath}`);
    } catch (error) {
      console.error("\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062A\u062E\u0632\u064A\u0646 \u0635\u0648\u0631\u0629 \u0627\u0644\u063A\u0644\u0627\u0641:", error);
      return `https://via.placeholder.com/1200x400?text=cover_${userId}`;
    }
    const profile = this.playerProfiles.get(userId);
    if (profile) {
      profile.coverPhoto = coverPhotoUrl;
      this.playerProfiles.set(userId, profile);
    }
    return coverPhotoUrl;
  }
  async convertGuestToRegistered(userId, username, password) {
    const user = this.users.get(userId);
    if (!user) return void 0;
    user.username = username;
    user.password = password;
    this.users.set(userId, user);
    const profile = this.playerProfiles.get(userId);
    if (profile) {
      profile.username = username;
      this.playerProfiles.set(userId, profile);
    }
    return user;
  }
  async getUser(id) {
    return this.users.get(id);
  }
  async getUserByUsername(username) {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  // وظيفة للحصول على المستخدمين باستخدام دالة فلتر معينة
  async getUsersByFilter(filter) {
    return Array.from(this.users.values()).filter(filter);
  }
  async createUser(insertUser) {
    const id = this.currentId++;
    const userCode = this.generateUniqueUserCode();
    const user = {
      ...insertUser,
      id,
      chips: 1e6,
      // مليون رقاقة ترحيبية للمستخدمين الجدد
      avatar: null,
      // استخدام null بدلاً من undefined
      userCode
      // إضافة معرف المستخدم المكون من 5 أرقام
    };
    this.users.set(id, user);
    this.createInitialPlayerProfile(user);
    return user;
  }
  // دالة مساعدة لإنشاء معرف فريد من 5 أرقام لكل مستخدم
  generateUniqueUserCode() {
    const min = 1e4;
    const max = 99999;
    let userCode;
    do {
      const randomCode = Math.floor(Math.random() * (max - min + 1)) + min;
      userCode = randomCode.toString();
      const isCodeTaken = Array.from(this.users.values()).some((user) => user.userCode === userCode);
      if (!isCodeTaken) {
        break;
      }
    } while (true);
    return userCode;
  }
  async updateUserChips(userId, newChips, type, description) {
    try {
      const user = await this.getUser(userId);
      if (!user) return void 0;
      const chipsChange = newChips - user.chips;
      user.chips = newChips;
      this.users.set(userId, user);
      console.log(`\u062A\u0645 \u062A\u062D\u062F\u064A\u062B \u0631\u0635\u064A\u062F \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u0641\u064A \u0627\u0644\u0630\u0627\u0643\u0631\u0629\u060C \u0627\u0644\u0631\u0635\u064A\u062F \u0627\u0644\u062C\u062F\u064A\u062F: ${newChips}`);
      if (type && chipsChange !== 0) {
        console.log(`\u0633\u062C\u0644 \u0645\u0639\u0627\u0645\u0644\u0629: \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} - ${type} - \u0627\u0644\u062A\u063A\u064A\u064A\u0631: ${chipsChange} - \u0627\u0644\u0648\u0635\u0641: ${description || "\u063A\u064A\u0631 \u0645\u062A\u0648\u0641\u0631"}`);
      }
      return user;
    } catch (error) {
      console.error(`\u062E\u0637\u0623 \u063A\u064A\u0631 \u0645\u062A\u0648\u0642\u0639 \u0641\u064A \u062A\u062D\u062F\u064A\u062B \u0631\u0635\u064A\u062F \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId}:`, error);
      return void 0;
    }
  }
  // Create initial player profile with default stats
  async createInitialPlayerProfile(user) {
    const achievements2 = [
      {
        id: "beginner",
        name: "\u0644\u0627\u0639\u0628 \u0645\u0628\u062A\u062F\u0626",
        icon: "fa-trophy",
        unlocked: true,
        description: "\u0627\u0646\u0636\u0645 \u0625\u0644\u0649 \u0644\u0639\u0628\u0629 \u0627\u0644\u0628\u0648\u0643\u0631"
      },
      {
        id: "winner",
        name: "\u0641\u0627\u0626\u0632 5 \u0645\u0631\u0627\u062A",
        icon: "fa-medal",
        unlocked: false,
        description: "\u0641\u0627\u0632 5 \u0645\u0631\u0627\u062A \u0641\u064A \u0627\u0644\u0628\u0648\u0643\u0631"
      },
      {
        id: "table_champ",
        name: "\u0628\u0637\u0644 \u0627\u0644\u0637\u0627\u0648\u0644\u0629",
        icon: "fa-crown",
        unlocked: false,
        description: "\u0641\u0627\u0632 \u0641\u064A \u0646\u0641\u0633 \u0627\u0644\u0637\u0627\u0648\u0644\u0629 3 \u0645\u0631\u0627\u062A \u0645\u062A\u062A\u0627\u0644\u064A\u0629"
      },
      {
        id: "poker_king",
        name: "\u0645\u0644\u0643 \u0627\u0644\u0628\u0648\u0643\u0631",
        icon: "fa-gem",
        unlocked: false,
        description: "\u062C\u0645\u0639 \u0623\u0643\u062B\u0631 \u0645\u0646 2,000,000 \u0631\u0642\u0627\u0642\u0629"
      }
    ];
    const stats = {
      gamesPlayed: 0,
      wins: 0,
      highestWin: 0,
      winRate: 0,
      achievements: achievements2,
      joinDate: (/* @__PURE__ */ new Date()).toLocaleDateString("ar-SA")
    };
    const profile = {
      ...user,
      stats,
      gameHistory: []
    };
    this.playerProfiles.set(user.id, profile);
  }
  // Game table operations
  async getGameTables() {
    return Array.from(this.tables.values());
  }
  // Get game tables by type
  async getGameTablesByType(gameType) {
    return Array.from(this.tables.values()).filter((table) => table.gameType === gameType);
  }
  async getGameTable(tableId) {
    return this.tables.get(tableId);
  }
  // إنشاء طاولة جديدة
  async createTable(tableData) {
    const tableId = this.currentTableId++;
    const newTable = {
      id: tableId,
      name: tableData.name || `\u0637\u0627\u0648\u0644\u0629 ${tableId}`,
      gameType: tableData.gameType || "poker",
      smallBlind: tableData.smallBlind || 10,
      bigBlind: tableData.bigBlind || (tableData.smallBlind ? tableData.smallBlind * 2 : 20),
      minBuyIn: tableData.minBuyIn || 200,
      maxBuyIn: tableData.maxBuyIn || 2e3,
      maxPlayers: tableData.maxPlayers || 9,
      currentPlayers: 0,
      status: "available",
      category: tableData.category || "\u0639\u0627\u0645",
      tableSettings: tableData.tableSettings || {},
      ownerId: tableData.ownerId,
      isVip: tableData.isVip || false,
      password: tableData.password,
      requiredVipLevel: tableData.requiredVipLevel || 0,
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date(),
      tableImage: tableData.tableImage
    };
    console.log(`\u062A\u0645 \u0625\u0646\u0634\u0627\u0621 \u0637\u0627\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629: ${newTable.name} (${newTable.id})`);
    this.tables.set(tableId, newTable);
    this.gameRooms.set(tableId, createGameRoom(newTable));
    return newTable;
  }
  // إزالة اللاعبين الوهميين من جميع الطاولات
  async removeVirtualPlayers() {
    console.log("\u062C\u0627\u0631\u064A \u0625\u0632\u0627\u0644\u0629 \u062C\u0645\u064A\u0639 \u0627\u0644\u0644\u0627\u0639\u0628\u064A\u0646 \u0627\u0644\u0648\u0647\u0645\u064A\u064A\u0646 \u0645\u0646 \u0627\u0644\u0637\u0627\u0648\u0644\u0627\u062A...");
    for (const table of this.tables.values()) {
      const oldCount = table.currentPlayers;
      table.currentPlayers = 0;
      table.status = "available";
      console.log(`\u062A\u0645 \u062A\u0641\u0631\u064A\u063A \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${table.id} (${table.name}) \u0645\u0646 ${oldCount} \u0644\u0627\u0639\u0628 \u0648\u0647\u0645\u064A`);
    }
    for (const [tableId, gameRoom] of this.gameRooms.entries()) {
      const table = this.tables.get(tableId);
      if (table) {
        this.gameRooms.set(tableId, createGameRoom(table));
      }
    }
    console.log("\u062A\u0645\u062A \u0625\u0632\u0627\u0644\u0629 \u062C\u0645\u064A\u0639 \u0627\u0644\u0644\u0627\u0639\u0628\u064A\u0646 \u0627\u0644\u0648\u0647\u0645\u064A\u064A\u0646 \u0628\u0646\u062C\u0627\u062D!");
  }
  // Game state operations
  async getGameState(tableId, userId) {
    const gameRoom = this.gameRooms.get(tableId);
    if (!gameRoom) return void 0;
    return gameRoom.getGameStateForPlayer(userId);
  }
  async joinTable(tableId, userId, position) {
    console.log(`\u0645\u062D\u0627\u0648\u0644\u0629 \u0627\u0646\u0636\u0645\u0627\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u0625\u0644\u0649 \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId} \u0628\u0627\u0644\u0645\u0648\u0636\u0639 ${position}`);
    const table = await this.getGameTable(tableId);
    if (!table) {
      console.log(`\u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId} \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629`);
      return { success: false, message: "\u0627\u0644\u0637\u0627\u0648\u0644\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629" };
    }
    if (table.status === "full") {
      console.log(`\u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId} \u0645\u0645\u062A\u0644\u0626\u0629`);
      return { success: false, message: "\u0627\u0644\u0637\u0627\u0648\u0644\u0629 \u0645\u0645\u062A\u0644\u0626\u0629" };
    }
    const user = await this.getUser(userId);
    if (!user) {
      console.log(`\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F`);
      return { success: false, message: "\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F" };
    }
    console.log(`\u062A\u062D\u0642\u0642 \u0645\u0646 \u0631\u0635\u064A\u062F \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${user.username}: ${user.chips} - \u0627\u0644\u062D\u062F \u0627\u0644\u0623\u062F\u0646\u0649 \u0644\u0644\u062F\u062E\u0648\u0644: ${table.minBuyIn}`);
    if (user.chips < table.minBuyIn) {
      console.log(`\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u0644\u0627 \u064A\u0645\u0644\u0643 \u0631\u0642\u0627\u0642\u0627\u062A \u0643\u0627\u0641\u064A\u0629`);
      return { success: false, message: "\u0644\u0627 \u062A\u0645\u0644\u0643 \u0631\u0642\u0627\u0642\u0627\u062A \u0643\u0627\u0641\u064A\u0629 \u0644\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0647\u0630\u0647 \u0627\u0644\u0637\u0627\u0648\u0644\u0629" };
    }
    const gameRoom = this.gameRooms.get(tableId);
    if (!gameRoom) {
      console.log(`\u063A\u0631\u0641\u0629 \u0627\u0644\u0644\u0639\u0628\u0629 ${tableId} \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629`);
      return { success: false, message: "\u063A\u0631\u0641\u0629 \u0627\u0644\u0644\u0639\u0628\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629" };
    }
    try {
      const currentGameState = gameRoom.getGameStateForPlayer(userId);
      const playerInGame = currentGameState.players.some((p) => p.id === userId);
      if (playerInGame) {
        console.log(`\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u0645\u0648\u062C\u0648\u062F \u0628\u0627\u0644\u0641\u0639\u0644 \u0641\u064A \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId}`);
        return {
          success: true,
          gameState: currentGameState,
          message: "\u0623\u0646\u062A \u0645\u0646\u0636\u0645 \u0628\u0627\u0644\u0641\u0639\u0644 \u0644\u0647\u0630\u0647 \u0627\u0644\u0637\u0627\u0648\u0644\u0629"
        };
      }
    } catch (error) {
      console.log(`\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u0644\u0645 \u064A\u0648\u062C\u062F \u0641\u064A \u0627\u0644\u063A\u0631\u0641\u0629 \u0633\u0627\u0628\u0642\u0627\u064B\u060C \u0633\u064A\u062A\u0645 \u0625\u0636\u0627\u0641\u062A\u0647 \u0627\u0644\u0622\u0646`);
    }
    const originalChips = user.chips;
    let updatedGameState;
    let joinSuccess = false;
    try {
      console.log(`\u0645\u062D\u0627\u0648\u0644\u0629 \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u0625\u0644\u0649 \u063A\u0631\u0641\u0629 \u0627\u0644\u0644\u0639\u0628\u0629`);
      const joinResult = gameRoom.addPlayer(userId, user.username, table.minBuyIn, user.avatar, position);
      console.log(`\u0646\u062A\u064A\u062C\u0629 \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645:`, joinResult);
      if (!joinResult.success) {
        console.log(`\u0641\u0634\u0644 \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId}: ${joinResult.message}`);
        return joinResult;
      }
      console.log(`\u062A\u062D\u062F\u064A\u062B \u0631\u0635\u064A\u062F \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u0645\u0646 ${user.chips} \u0625\u0644\u0649 ${user.chips - table.minBuyIn} (\u062E\u0635\u0645 ${table.minBuyIn} \u0631\u0642\u0627\u0642\u0629 \u0644\u0644\u062F\u062E\u0648\u0644)`);
      const updatedUser = await this.updateUserChips(userId, Math.max(0, user.chips - table.minBuyIn));
      if (!updatedUser) {
        throw new Error("\u0641\u0634\u0644 \u062A\u062D\u062F\u064A\u062B \u0631\u0635\u064A\u062F \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645");
      }
      table.currentPlayers++;
      if (table.currentPlayers >= table.maxPlayers) {
        table.status = "full";
      } else if (table.currentPlayers > 0) {
        table.status = "available";
      }
      this.tables.set(tableId, table);
      console.log(`\u062A\u0645 \u0627\u0646\u0636\u0645\u0627\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u0625\u0644\u0649 \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId} \u0628\u0646\u062C\u0627\u062D`);
      updatedGameState = gameRoom.getGameStateForPlayer(userId);
      console.log(`\u0639\u062F\u062F \u0627\u0644\u0644\u0627\u0639\u0628\u064A\u0646 \u0641\u064A \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId}: ${updatedGameState.players.length}`);
      if (updatedGameState.players.length === 1 && updatedGameState.gameStatus === "waiting") {
        console.log(`\u0644\u0627\u0639\u0628 \u0648\u062D\u064A\u062F \u0641\u064A \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId}\u060C \u0633\u064A\u062A\u0645 \u0625\u0636\u0627\u0641\u0629 \u0644\u0627\u0639\u0628 \u0648\u0647\u0645\u064A \u0628\u0639\u062F 3 \u062B\u0648\u0627\u0646\u064D...`);
        setTimeout(async () => {
          try {
            const currentState = gameRoom.getGameStateForPlayer(userId);
            if (currentState.players.length === 1 && currentState.gameStatus === "waiting") {
              const aiId = -Math.floor(Math.random() * 1e3) - 1;
              const aiNames = ["\u0631\u0648\u0628\u0648\u062A \u0630\u0643\u064A", "\u0644\u0627\u0639\u0628 \u0622\u0644\u064A", "\u062C\u064A\u0645\u064A \u0628\u0648\u062A", "\u0628\u0648\u062A \u0627\u0644\u0641\u0627\u062C\u0631", "\u0630\u0643\u0627\u0621 \u0627\u0635\u0637\u0646\u0627\u0639\u064A", "\u0628\u0648\u0643\u0631 \u0628\u0648\u062A"];
              const aiName = aiNames[Math.floor(Math.random() * aiNames.length)];
              console.log(`\u0625\u0636\u0627\u0641\u0629 \u0644\u0627\u0639\u0628 \u0648\u0647\u0645\u064A (${aiName}) \u0625\u0644\u0649 \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId}...`);
              const aiPosition = Math.floor(Math.random() * (table.maxPlayers - 1)) + 1;
              const aiResult = gameRoom.addPlayer(aiId, aiName, table.minBuyIn * 2, "/images/ai-avatar.png", aiPosition, true);
              if (aiResult.success) {
                console.log(`\u062A\u0645 \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0644\u0627\u0639\u0628 \u0627\u0644\u0648\u0647\u0645\u064A \u0628\u0646\u062C\u0627\u062D \u0625\u0644\u0649 \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId}`);
                table.currentPlayers = Math.min(table.currentPlayers + 1, table.maxPlayers);
                if (table.currentPlayers >= table.maxPlayers) {
                  table.status = "full";
                } else {
                  table.status = "available";
                }
                this.tables.set(tableId, table);
              } else {
                console.error(`\u0641\u0634\u0644 \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0644\u0627\u0639\u0628 \u0627\u0644\u0648\u0647\u0645\u064A: ${aiResult.message}`);
              }
            } else {
              console.log(`\u062A\u0645 \u0625\u0644\u063A\u0627\u0621 \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0644\u0627\u0639\u0628 \u0627\u0644\u0648\u0647\u0645\u064A \u0644\u0623\u0646 \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId} \u0623\u0635\u0628\u062D\u062A \u062A\u062D\u062A\u0648\u064A \u0639\u0644\u0649 \u0623\u0643\u062B\u0631 \u0645\u0646 \u0644\u0627\u0639\u0628 \u0648\u0627\u062D\u062F`);
            }
          } catch (error) {
            console.error(`\u062E\u0637\u0623 \u0639\u0646\u062F \u0645\u062D\u0627\u0648\u0644\u0629 \u0625\u0636\u0627\u0641\u0629 \u0644\u0627\u0639\u0628 \u0648\u0647\u0645\u064A: ${error}`);
          }
        }, 3e3);
      }
      if (updatedGameState.players.some((p) => p.id === userId)) {
        joinSuccess = true;
      } else {
        throw new Error("\u0627\u0644\u0644\u0627\u0639\u0628 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F \u0641\u064A \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0644\u0627\u0639\u0628\u064A\u0646 \u0628\u0639\u062F \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645");
      }
    } catch (error) {
      console.error(`\u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645: ${error}`);
      await this.updateUserChips(userId, originalChips);
      try {
        gameRoom.removePlayer(userId);
      } catch (removeError) {
        console.error(`\u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0645\u062D\u0627\u0648\u0644\u0629 \u0625\u0632\u0627\u0644\u0629 \u0627\u0644\u0644\u0627\u0639\u0628 \u0628\u0639\u062F \u0641\u0634\u0644 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645: ${removeError}`);
      }
      return {
        success: false,
        message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0627\u0644\u0637\u0627\u0648\u0644\u0629. \u0644\u0645 \u064A\u062A\u0645 \u062E\u0635\u0645 \u0623\u064A \u0631\u0642\u0627\u0642\u0627\u062A."
      };
    }
    if (!joinSuccess) {
      await this.updateUserChips(userId, originalChips);
      return {
        success: false,
        message: "\u0644\u0645 \u062A\u0646\u062C\u062D \u0639\u0645\u0644\u064A\u0629 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645. \u0644\u0645 \u064A\u062A\u0645 \u062E\u0635\u0645 \u0623\u064A \u0631\u0642\u0627\u0642\u0627\u062A."
      };
    }
    return {
      success: true,
      gameState: updatedGameState,
      isSpectator: false
    };
  }
  async leaveTable(tableId, userId) {
    const table = await this.getGameTable(tableId);
    if (!table) {
      return { success: false, message: "\u0627\u0644\u0637\u0627\u0648\u0644\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629" };
    }
    const gameRoom = this.gameRooms.get(tableId);
    if (!gameRoom) {
      return { success: false, message: "\u063A\u0631\u0641\u0629 \u0627\u0644\u0644\u0639\u0628\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629" };
    }
    const leaveResult = gameRoom.removePlayer(userId);
    if (!leaveResult.success) {
      return leaveResult;
    }
    const user = await this.getUser(userId);
    if (user && leaveResult.chips) {
      await this.updateUserChips(userId, user.chips + leaveResult.chips);
    }
    table.currentPlayers--;
    if (table.currentPlayers <= 0) {
      table.status = "available";
    } else if (table.currentPlayers < table.maxPlayers) {
      table.status = "available";
    }
    this.tables.set(tableId, table);
    return { success: true };
  }
  async performGameAction(tableId, userId, action, amount) {
    const gameRoom = this.gameRooms.get(tableId);
    if (!gameRoom) {
      return { success: false, message: "\u063A\u0631\u0641\u0629 \u0627\u0644\u0644\u0639\u0628\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629" };
    }
    const actionResult = gameRoom.performAction(userId, action, amount);
    if (!actionResult.success) {
      return actionResult;
    }
    if (actionResult.gameEnded && actionResult.results) {
      for (const result of actionResult.results) {
        const user = await this.getUser(result.playerId);
        if (user) {
          await this.updateUserChips(user.id, user.chips + result.chipsChange);
          await this.addGameToHistory(
            user.id,
            tableId,
            result.chipsChange > 0 ? "win" : "loss",
            result.chipsChange
          );
        }
      }
    }
    return {
      success: true,
      gameState: gameRoom.getGameStateForPlayer(userId)
    };
  }
  // Player profile operations
  async getPlayerProfile(userId) {
    return this.playerProfiles.get(userId);
  }
  async addGameToHistory(userId, tableId, result, chipsChange) {
    const profile = await this.getPlayerProfile(userId);
    if (!profile) return;
    const table = await this.getGameTable(tableId);
    const historyItem = {
      id: this.currentGameHistoryId++,
      date: (/* @__PURE__ */ new Date()).toLocaleDateString("ar-SA"),
      tableName: table ? table.name : "\u0637\u0627\u0648\u0644\u0629 \u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641\u0629",
      result,
      chipsChange: Math.abs(chipsChange)
    };
    profile.stats.gamesPlayed++;
    if (result === "win") {
      profile.stats.wins++;
      if (chipsChange > profile.stats.highestWin) {
        profile.stats.highestWin = chipsChange;
      }
    }
    profile.stats.winRate = Math.round(profile.stats.wins / profile.stats.gamesPlayed * 100);
    if (profile.stats.wins >= 5) {
      const winnerAchievement = profile.stats.achievements.find((a) => a.id === "winner");
      if (winnerAchievement && !winnerAchievement.unlocked) {
        winnerAchievement.unlocked = true;
      }
    }
    if (profile.chips >= 2e6) {
      const kingAchievement = profile.stats.achievements.find((a) => a.id === "poker_king");
      if (kingAchievement && !kingAchievement.unlocked) {
        kingAchievement.unlocked = true;
      }
    }
    profile.gameHistory.unshift(historyItem);
    if (profile.gameHistory.length > 20) {
      profile.gameHistory = profile.gameHistory.slice(0, 20);
    }
    this.playerProfiles.set(userId, profile);
  }
  // Badge operations
  async getBadgeCategories() {
    const categories = [
      {
        id: 1,
        name: "\u0625\u0646\u062C\u0627\u0632\u0627\u062A \u0627\u0644\u0644\u0639\u0628",
        description: "\u0634\u0627\u0631\u0627\u062A \u062A\u0645\u0646\u062D \u0639\u0646\u062F \u062A\u062D\u0642\u064A\u0642 \u0625\u0646\u062C\u0627\u0632\u0627\u062A \u0645\u0639\u064A\u0646\u0629 \u0641\u064A \u0627\u0644\u0644\u0639\u0628",
        icon: "\u{1F3C6}",
        sortOrder: 1
      },
      {
        id: 2,
        name: "\u0634\u0627\u0631\u0627\u062A VIP",
        description: "\u0634\u0627\u0631\u0627\u062A \u062E\u0627\u0635\u0629 \u0628\u0623\u0639\u0636\u0627\u0621 VIP",
        icon: "\u{1F451}",
        sortOrder: 2
      },
      {
        id: 3,
        name: "\u0623\u062D\u062F\u0627\u062B \u062E\u0627\u0635\u0629",
        description: "\u0634\u0627\u0631\u0627\u062A \u062A\u0645\u0646\u062D \u062E\u0644\u0627\u0644 \u0627\u0644\u0645\u0646\u0627\u0633\u0628\u0627\u062A \u0648\u0627\u0644\u0623\u062D\u062F\u0627\u062B \u0627\u0644\u062E\u0627\u0635\u0629",
        icon: "\u{1F389}",
        sortOrder: 3
      },
      {
        id: 4,
        name: "\u0645\u062C\u062A\u0645\u0639 \u0627\u0644\u0644\u0627\u0639\u0628\u064A\u0646",
        description: "\u0634\u0627\u0631\u0627\u062A \u062A\u062A\u0639\u0644\u0642 \u0628\u0627\u0644\u062A\u0641\u0627\u0639\u0644 \u0645\u0639 \u0627\u0644\u0645\u062C\u062A\u0645\u0639",
        icon: "\u{1F465}",
        sortOrder: 4
      }
    ];
    return categories;
  }
  async getBadges(categoryId) {
    const allBadges = [
      {
        id: 1,
        name: "\u0644\u0627\u0639\u0628 \u062C\u062F\u064A\u062F",
        description: "\u0627\u0646\u0636\u0645 \u0644\u0644\u0639\u0628\u0629 \u0648\u0623\u0643\u0645\u0644 \u0627\u0644\u062A\u0633\u062C\u064A\u0644",
        imageUrl: "/assets/badges/new-player.svg",
        categoryId: 1,
        isRare: false,
        isHidden: false,
        requiredVipLevel: 0,
        rarityLevel: 1,
        sortOrder: 1,
        color: "#4CAF50",
        createdAt: /* @__PURE__ */ new Date()
      },
      {
        id: 2,
        name: "\u0641\u0627\u0626\u0632 \u0645\u062D\u062A\u0631\u0641",
        description: "\u0641\u0627\u0632 \u0628\u0640 10 \u0645\u0628\u0627\u0631\u064A\u0627\u062A \u0645\u062A\u062A\u0627\u0644\u064A\u0629",
        imageUrl: "/assets/badges/pro-winner.svg",
        categoryId: 1,
        isRare: true,
        isHidden: false,
        requiredVipLevel: 0,
        rarityLevel: 4,
        sortOrder: 2,
        color: "#FFC107",
        glowColor: "#FFD700",
        effects: [
          { type: "glow", intensity: 5, color: "#FFD700", activationMode: "always" }
        ],
        createdAt: /* @__PURE__ */ new Date()
      },
      {
        id: 3,
        name: "\u0639\u0636\u0648 VIP",
        description: "\u0648\u0635\u0644 \u0625\u0644\u0649 \u0645\u0633\u062A\u0648\u0649 VIP",
        imageUrl: "/assets/badges/vip-member.svg",
        categoryId: 2,
        isRare: false,
        isHidden: false,
        requiredVipLevel: 1,
        rarityLevel: 2,
        sortOrder: 1,
        color: "#9C27B0",
        glowColor: "#E1BEE7",
        effects: [
          { type: "pulse", intensity: 3, activationMode: "hover" }
        ],
        createdAt: /* @__PURE__ */ new Date()
      },
      {
        id: 4,
        name: "\u0645\u0644\u064A\u0648\u0646\u064A\u0631 \u0627\u0644\u0631\u0642\u0627\u0626\u0642",
        description: "\u0627\u0645\u062A\u0644\u0643 \u0623\u0643\u062B\u0631 \u0645\u0646 \u0645\u0644\u064A\u0648\u0646 \u0631\u0642\u0627\u0642\u0629",
        imageUrl: "/assets/badges/chip-millionaire.svg",
        categoryId: 1,
        isRare: true,
        isHidden: false,
        requiredVipLevel: 0,
        rarityLevel: 3,
        sortOrder: 3,
        color: "#F44336",
        glowColor: "#FFCDD2",
        effects: [
          { type: "sparkle", intensity: 7, color: "#FFD700", activationMode: "hover" }
        ],
        createdAt: /* @__PURE__ */ new Date()
      },
      {
        id: 5,
        name: "\u0628\u0637\u0644 \u0631\u0645\u0636\u0627\u0646",
        description: "\u0634\u0627\u0631\u0643 \u0641\u064A \u0628\u0637\u0648\u0644\u0629 \u0631\u0645\u0636\u0627\u0646",
        imageUrl: "/assets/badges/ramadan-champion.svg",
        categoryId: 3,
        isRare: true,
        isHidden: false,
        requiredVipLevel: 0,
        rarityLevel: 3,
        sortOrder: 1,
        color: "#2196F3",
        effects: [
          { type: "rotate", intensity: 2, activationMode: "hover" }
        ],
        createdAt: /* @__PURE__ */ new Date()
      }
    ];
    if (categoryId !== void 0) {
      return allBadges.filter((badge) => badge.categoryId === categoryId);
    }
    return allBadges;
  }
  async getUserBadges(userId) {
    const profile = await this.getPlayerProfile(userId);
    if (!profile || !profile.badges) {
      return [];
    }
    return profile.badges;
  }
  async addUserBadge(userId, badgeId) {
    const profile = await this.getPlayerProfile(userId);
    if (!profile) return void 0;
    if (!profile.badges) {
      profile.badges = [];
    }
    const existingBadge = profile.badges.find((ub) => ub.badgeId === badgeId);
    if (existingBadge) {
      return existingBadge;
    }
    const allBadges = await this.getBadges();
    const badge = allBadges.find((b) => b.id === badgeId);
    if (!badge) {
      return void 0;
    }
    const userBadge = {
      id: Date.now(),
      // Use timestamp as ID for in-memory storage
      userId,
      badgeId,
      badge,
      acquiredAt: /* @__PURE__ */ new Date(),
      isEquipped: false,
      displayProgress: 100,
      // Default to complete
      source: "award"
      // Default source
    };
    profile.badges.push(userBadge);
    profile.badgeCount = profile.badges.length;
    profile.rareCount = profile.badges.filter((ub) => ub.badge.isRare).length;
    this.playerProfiles.set(userId, profile);
    return userBadge;
  }
  async equipBadge(userId, badgeId, position = 0) {
    const profile = await this.getPlayerProfile(userId);
    if (!profile || !profile.badges) return void 0;
    const userBadge = profile.badges.find((ub) => ub.badgeId === badgeId);
    if (!userBadge) return void 0;
    if (profile.equippedBadges && position !== void 0) {
      const badgeInPosition = profile.equippedBadges.find((ub) => ub.equippedPosition === position);
      if (badgeInPosition) {
        badgeInPosition.isEquipped = false;
        badgeInPosition.equippedPosition = void 0;
      }
    }
    userBadge.isEquipped = true;
    userBadge.equippedPosition = position;
    if (!profile.equippedBadges) {
      profile.equippedBadges = [];
    }
    const existingIndex = profile.equippedBadges.findIndex((ub) => ub.badgeId === badgeId);
    if (existingIndex >= 0) {
      profile.equippedBadges[existingIndex] = userBadge;
    } else {
      profile.equippedBadges.push(userBadge);
    }
    this.playerProfiles.set(userId, profile);
    return userBadge;
  }
  async unequipBadge(userId, badgeId) {
    const profile = await this.getPlayerProfile(userId);
    if (!profile || !profile.badges) return void 0;
    const userBadge = profile.badges.find((ub) => ub.badgeId === badgeId);
    if (!userBadge) return void 0;
    userBadge.isEquipped = false;
    userBadge.equippedPosition = void 0;
    if (profile.equippedBadges) {
      profile.equippedBadges = profile.equippedBadges.filter((ub) => ub.badgeId !== badgeId);
    }
    this.playerProfiles.set(userId, profile);
    return userBadge;
  }
  async addToFavorites(userId, badgeId, order = 0) {
    const profile = await this.getPlayerProfile(userId);
    if (!profile || !profile.badges) return void 0;
    const userBadge = profile.badges.find((ub) => ub.badgeId === badgeId);
    if (!userBadge) return void 0;
    userBadge.favoriteOrder = order;
    if (!profile.favoriteBadges) {
      profile.favoriteBadges = [];
    }
    const existingIndex = profile.favoriteBadges.findIndex((ub) => ub.badgeId === badgeId);
    if (existingIndex >= 0) {
      profile.favoriteBadges[existingIndex] = userBadge;
    } else {
      profile.favoriteBadges.push(userBadge);
    }
    profile.favoriteBadges.sort((a, b) => (a.favoriteOrder || 0) - (b.favoriteOrder || 0));
    this.playerProfiles.set(userId, profile);
    return userBadge;
  }
  async removeFromFavorites(userId, badgeId) {
    const profile = await this.getPlayerProfile(userId);
    if (!profile || !profile.badges) return void 0;
    const userBadge = profile.badges.find((ub) => ub.badgeId === badgeId);
    if (!userBadge) return void 0;
    userBadge.favoriteOrder = void 0;
    if (profile.favoriteBadges) {
      profile.favoriteBadges = profile.favoriteBadges.filter((ub) => ub.badgeId !== badgeId);
    }
    this.playerProfiles.set(userId, profile);
    return userBadge;
  }
};
var storage = new MemStorage();

// server/auth.ts
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import session2 from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import createMemoryStore2 from "memorystore";
import pgSession from "connect-pg-simple";
var scryptAsync = promisify(scrypt);
var MemoryStore = createMemoryStore2(session2);
var PostgreSqlStore = pgSession(session2);
async function hashPassword(password) {
  const salt = randomBytes(16).toString("hex");
  const buf = await scryptAsync(password, salt, 64);
  return `${buf.toString("hex")}.${salt}`;
}
async function comparePasswords(supplied, stored) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = await scryptAsync(supplied, salt, 64);
  return timingSafeEqual(hashedBuf, suppliedBuf);
}
function generateGuestUsername() {
  const guestId = Math.floor(1e5 + Math.random() * 9e5);
  return `\u0636\u064A\u0641_${guestId}`;
}
function generateUserCode() {
  return Math.floor(1e4 + Math.random() * 9e4).toString();
}
function setupAuth(app2) {
  const sessionSecret = process.env.SESSION_SECRET || "poker-game-secret-key";
  let sessionStore;
  if (process.env.DATABASE_URL) {
    console.log("\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0645\u062E\u0632\u0646 PostgreSQL \u0644\u0644\u062C\u0644\u0633\u0627\u062A");
    try {
      sessionStore = new PostgreSqlStore({
        conString: process.env.DATABASE_URL,
        tableName: "sessions",
        createTableIfMissing: true,
        pruneSessionInterval: 60 * 60,
        errorLog: console.error,
        disableTouch: false
      });
    } catch (err) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u0625\u0646\u0634\u0627\u0621 \u0645\u062E\u0632\u0646 \u062C\u0644\u0633\u0627\u062A PostgreSQL:", err);
      console.log("\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0645\u062E\u0632\u0646 \u0627\u0644\u0630\u0627\u0643\u0631\u0629 \u0644\u0644\u062C\u0644\u0633\u0627\u062A (\u0627\u062D\u062A\u064A\u0627\u0637\u064A)");
      sessionStore = new MemoryStore({
        checkPeriod: 864e5
        // مسح الجلسات المنتهية كل 24 ساعة
      });
    }
  } else {
    console.log("\u0639\u062F\u0645 \u0648\u062C\u0648\u062F \u0627\u062A\u0635\u0627\u0644 PostgreSQL\u060C \u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0645\u062E\u0632\u0646 \u0627\u0644\u0630\u0627\u0643\u0631\u0629 \u0644\u0644\u062C\u0644\u0633\u0627\u062A");
    sessionStore = new MemoryStore({
      checkPeriod: 864e5
      // مسح الجلسات المنتهية كل 24 ساعة
    });
  }
  const sessionSettings = {
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    store: sessionStore,
    // استخدام المخزن المناسب
    cookie: {
      secure: false,
      // تعطيل secure لبيئة التطوير
      maxAge: 30 * 24 * 60 * 60 * 1e3,
      // 30 يوم
      sameSite: "lax",
      httpOnly: true,
      path: "/"
    },
    // التأكد من أن session ID ثابت
    genid: function() {
      return Math.random().toString(36).substring(2) + Date.now().toString(36) + Math.random().toString(36).substring(2);
    }
  };
  app2.set("trust proxy", 1);
  app2.use(session2(sessionSettings));
  app2.use(passport.initialize());
  app2.use(passport.session());
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || !await comparePasswords(password, user.password)) {
          return done(null, false);
        } else {
          return done(null, user);
        }
      } catch (err) {
        return done(err);
      }
    })
  );
  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id, done) => {
    try {
      const user = await storage.getUser(id);
      if (!user) {
        console.log(`\u0644\u0645 \u064A\u062A\u0645 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0628\u0631\u0642\u0645 ${id}\u060C \u0625\u0632\u0627\u0644\u0629 \u062A\u062E\u0635\u064A\u0635 \u0627\u0644\u062C\u0644\u0633\u0629`);
        return done(null, false);
      }
      done(null, user);
    } catch (err) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u0627\u0633\u062A\u0631\u062C\u0627\u0639 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645:", err);
      done(null, false);
    }
  });
  app2.post("/api/register", async (req, res, next) => {
    try {
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).send("\u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0645\u0648\u062C\u0648\u062F \u0628\u0627\u0644\u0641\u0639\u0644");
      }
      const user = await storage.createUser({
        ...req.body,
        password: await hashPassword(req.body.password),
        userCode: generateUserCode(),
        // إضافة معرف فريد للمستخدم
        isGuest: false,
        authType: "email"
      });
      req.login(user, (err) => {
        if (err) return next(err);
        const oneMonth = 30 * 24 * 60 * 60 * 1e3;
        res.cookie("connect.sid", req.sessionID, {
          path: "/",
          httpOnly: true,
          sameSite: "lax",
          maxAge: oneMonth,
          secure: false
        });
        res.status(201).json(user);
      });
    } catch (err) {
      next(err);
    }
  });
  app2.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err, user, info) => {
      if (err) {
        return next(err);
      }
      if (!user) {
        return res.status(401).json({ message: "\u062E\u0637\u0623 \u0641\u064A \u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0623\u0648 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631" });
      }
      req.login(user, (err2) => {
        if (err2) {
          return next(err2);
        }
        const oneMonth = 30 * 24 * 60 * 60 * 1e3;
        res.cookie("connect.sid", req.sessionID, {
          path: "/",
          httpOnly: true,
          sameSite: "lax",
          maxAge: oneMonth,
          secure: false
        });
        return res.status(200).json(user);
      });
    })(req, res, next);
  });
  app2.post("/api/logout", (req, res, next) => {
    const sessionID = req.sessionID;
    req.logout((err) => {
      if (err) return next(err);
      req.session.destroy((err2) => {
        if (err2) return next(err2);
        res.clearCookie("connect.sid");
        res.setHeader("Set-Cookie", ["connect.sid=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT"]);
        return res.status(200).json({ message: "\u062A\u0645 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062E\u0631\u0648\u062C \u0628\u0646\u062C\u0627\u062D" });
      });
    });
  });
  app2.post("/api/login/guest", async (req, res, next) => {
    try {
      const guestUsername = generateGuestUsername();
      const guestPassword = Math.random().toString(36).slice(-10);
      const guestUser = await storage.createUser({
        username: guestUsername,
        password: await hashPassword(guestPassword),
        chips: 5e4,
        userCode: generateUserCode(),
        // إضافة معرف فريد
        isGuest: true,
        authType: "guest"
      });
      req.login(guestUser, (err) => {
        if (err) return next(err);
        const oneMonth = 30 * 24 * 60 * 60 * 1e3;
        res.cookie("connect.sid", req.sessionID, {
          path: "/",
          httpOnly: true,
          sameSite: "lax",
          maxAge: oneMonth,
          secure: false
        });
        res.status(200).json(guestUser);
      });
    } catch (err) {
      next(err);
    }
  });
  app2.post("/api/login/facebook", async (req, res, next) => {
    try {
      const fbUsername = `fb_${Math.floor(1e3 + Math.random() * 9e3)}`;
      const fbPassword = Math.random().toString(36).slice(-10);
      const fbUser = await storage.createUser({
        username: fbUsername,
        password: await hashPassword(fbPassword),
        chips: 1e5,
        userCode: generateUserCode(),
        // إضافة معرف فريد
        isGuest: false,
        authType: "facebook"
      });
      req.login(fbUser, (err) => {
        if (err) return next(err);
        const oneMonth = 30 * 24 * 60 * 60 * 1e3;
        res.cookie("connect.sid", req.sessionID, {
          path: "/",
          httpOnly: true,
          sameSite: "lax",
          maxAge: oneMonth,
          secure: false
        });
        res.status(200).json(fbUser);
      });
    } catch (err) {
      next(err);
    }
  });
  app2.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({
        error: "Unauthorized",
        message: "\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0633\u062C\u0644 \u062F\u062E\u0648\u0644\u0647",
        status: 401
      });
    }
    storage.getUser(req.user.id).then((updatedUser) => {
      if (!updatedUser) {
        return res.status(404).json({
          error: "NotFound",
          message: "\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F",
          status: 404
        });
      }
      req.login(updatedUser, (err) => {
        if (err) {
          console.error("\u062E\u0637\u0623 \u0641\u064A \u062A\u062D\u062F\u064A\u062B \u062C\u0644\u0633\u0629 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645:", err);
        }
        const oneMonth = 30 * 24 * 60 * 60 * 1e3;
        res.cookie("connect.sid", req.sessionID, {
          path: "/",
          httpOnly: true,
          sameSite: "lax",
          maxAge: oneMonth,
          secure: false
        });
        res.json(updatedUser);
      });
    }).catch((err) => {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u062C\u0644\u0628 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645:", err);
      res.json(req.user);
    });
  });
}

// server/poker.ts
import { WebSocketServer, WebSocket } from "ws";

// client/src/pages/poker-lobby/poker-masr/logic/poker-engine.ts
import * as pokerSolver from "pokersolver";
var SUITS = ["\u2660", "\u2665", "\u2666", "\u2663"];
var RANKS = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];
function createDeck2() {
  const deck = [];
  for (const suit of SUITS) {
    for (const rank of RANKS) {
      deck.push({ suit, rank, hidden: false });
    }
  }
  return deck;
}
function shuffleDeck2(deck) {
  const shuffledDeck = [...deck];
  for (let i = shuffledDeck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffledDeck[i], shuffledDeck[j]] = [shuffledDeck[j], shuffledDeck[i]];
  }
  return shuffledDeck;
}
var handTypesArabic = {
  "High Card": "\u0648\u0631\u0642\u0629 \u0639\u0627\u0644\u064A\u0629",
  "Pair": "\u0632\u0648\u062C",
  "Two Pair": "\u0632\u0648\u062C\u0627\u0646",
  "Three of a Kind": "\u062B\u0644\u0627\u062B\u064A\u0629",
  "Straight": "\u0633\u062A\u0631\u064A\u062A",
  "Flush": "\u0641\u0644\u0627\u0634",
  "Full House": "\u0641\u0644 \u0647\u0627\u0648\u0633",
  "Four of a Kind": "\u0631\u0628\u0627\u0639\u064A\u0629",
  "Straight Flush": "\u0633\u062A\u0631\u064A\u062A \u0641\u0644\u0627\u0634",
  "Royal Flush": "\u0631\u0648\u064A\u0627\u0644 \u0641\u0644\u0627\u0634"
};
var handRanks = {
  "High Card": 1,
  "Pair": 2,
  "Two Pair": 3,
  "Three of a Kind": 4,
  "Straight": 5,
  "Flush": 6,
  "Full House": 7,
  "Four of a Kind": 8,
  "Straight Flush": 9,
  "Royal Flush": 10
};
function formatCardForSolver(card) {
  const suitMap = {
    "\u2660": "s",
    // spades
    "\u2665": "h",
    // hearts
    "\u2666": "d",
    // diamonds
    "\u2663": "c"
    // clubs
  };
  let rank = card.rank;
  return rank + suitMap[card.suit];
}
function evaluatePlayerHand(playerCards, communityCards) {
  const allCardsFormatted = [...playerCards, ...communityCards].map(formatCardForSolver);
  const hand = pokerSolver.Hand.solve(allCardsFormatted);
  const handType = hand.name;
  const handRank = handRanks[handType] || 0;
  const handName = handTypesArabic[handType] || handType;
  let description = `${handName}`;
  let usedCards = [];
  const handValues = hand.values || [];
  const cardDescriptions = [];
  if (hand.cards && Array.isArray(hand.cards)) {
    usedCards = hand.cards;
  }
  if (handType === "High Card") {
    const highCard = valueToRankArabic(handValues[0]);
    description = `\u0648\u0631\u0642\u0629 \u0639\u0627\u0644\u064A\u0629: ${highCard}`;
  } else if (handType === "Pair") {
    const pairValue = valueToRankArabic(handValues[0]);
    const kicker = handValues.length > 1 ? valueToRankArabic(handValues[1]) : "";
    description = `\u0632\u0648\u062C \u0645\u0646 ${pairValue}${kicker ? ` \u0645\u0639 ${kicker}` : ""}`;
  } else if (handType === "Two Pair") {
    const pair1 = valueToRankArabic(handValues[0]);
    const pair2 = valueToRankArabic(handValues[1]);
    const kicker = handValues.length > 2 ? valueToRankArabic(handValues[2]) : "";
    description = `\u0632\u0648\u062C\u0627\u0646: ${pair1} \u0648 ${pair2}${kicker ? ` \u0645\u0639 ${kicker}` : ""}`;
  } else if (handType === "Three of a Kind") {
    const tripleValue = valueToRankArabic(handValues[0]);
    const kicker = handValues.length > 1 ? valueToRankArabic(handValues[1]) : "";
    description = `\u062B\u0644\u0627\u062B\u064A\u0629 \u0645\u0646 ${tripleValue}${kicker ? ` \u0645\u0639 ${kicker}` : ""}`;
  } else if (handType === "Straight") {
    const highStraight = valueToRankArabic(handValues[0]);
    const lowStraight = valueToRankArabic(handValues[4] || handValues[0] - 4);
    description = `\u0633\u062A\u0631\u064A\u062A \u0645\u0646 ${lowStraight} \u0625\u0644\u0649 ${highStraight}`;
  } else if (handType === "Flush") {
    const highFlush = valueToRankArabic(handValues[0]);
    const suit = usedCards.length > 0 ? translateSuit(usedCards[0].suit) : "";
    description = `\u0641\u0644\u0627\u0634 ${suit} \u0628\u0640 ${highFlush}`;
  } else if (handType === "Full House") {
    const tripleValue = valueToRankArabic(handValues[0]);
    const pairValue = valueToRankArabic(handValues[1]);
    description = `\u0641\u0644 \u0647\u0627\u0648\u0633: \u062B\u0644\u0627\u062B\u064A\u0629 ${tripleValue} \u0645\u0639 \u0632\u0648\u062C ${pairValue}`;
  } else if (handType === "Four of a Kind") {
    const quadValue = valueToRankArabic(handValues[0]);
    const kicker = handValues.length > 1 ? valueToRankArabic(handValues[1]) : "";
    description = `\u0631\u0628\u0627\u0639\u064A\u0629 \u0645\u0646 ${quadValue}${kicker ? ` \u0645\u0639 ${kicker}` : ""}`;
  } else if (handType === "Straight Flush") {
    const highStraightFlush = valueToRankArabic(handValues[0]);
    const suit = usedCards.length > 0 ? translateSuit(usedCards[0].suit) : "";
    description = `\u0633\u062A\u0631\u064A\u062A \u0641\u0644\u0627\u0634 ${suit} \u0625\u0644\u0649 ${highStraightFlush}`;
  } else if (handType === "Royal Flush") {
    const suit = usedCards.length > 0 ? translateSuit(usedCards[0].suit) : "";
    description = `\u0631\u0648\u064A\u0627\u0644 \u0641\u0644\u0627\u0634 ${suit}`;
  }
  let strength = handRank / 10;
  if (handValues.length > 0) {
    strength += handValues[0] / 150;
    if (handValues.length > 1) {
      strength += handValues[1] / 1500;
    }
    if (handValues.length > 2) {
      strength += handValues[2] / 15e3;
    }
  }
  return {
    handType,
    handRank,
    handName,
    description,
    cards: playerCards,
    // نعيد البطاقات الأصلية للاعب
    strength,
    solverResult: hand
    // نتيجة المكتبة الخام للاستخدام المتقدم في تحديد الفائز
  };
}
function valueToRankArabic(value) {
  if (!value && value !== 0) return "";
  const rankMap = {
    14: "\u0622\u0633",
    // A
    13: "\u0645\u0644\u0643",
    // K
    12: "\u0645\u0644\u0643\u0629",
    // Q
    11: "\u0634\u0627\u0628",
    // J
    10: "10",
    9: "9",
    8: "8",
    7: "7",
    6: "6",
    5: "5",
    4: "4",
    3: "3",
    2: "2"
  };
  return rankMap[value] || value.toString();
}
function translateSuit(suit) {
  const suitMap = {
    "s": "\u0627\u0644\u0628\u0633\u062A\u0648\u0646\u064A",
    "h": "\u0627\u0644\u0642\u0644\u0648\u0628",
    "d": "\u0627\u0644\u062F\u064A\u0646\u0627\u0631\u064A",
    "c": "\u0627\u0644\u0648\u0631\u0642\u0629"
  };
  return suitMap[suit] || suit;
}
function rotateDealer(currentDealerPosition, activePlayers) {
  return (currentDealerPosition + 1) % activePlayers;
}
function determineBlindPositions(dealerPosition, activePlayers) {
  if (activePlayers === 2) {
    return {
      smallBlind: dealerPosition,
      bigBlind: (dealerPosition + 1) % activePlayers
    };
  }
  return {
    smallBlind: (dealerPosition + 1) % activePlayers,
    bigBlind: (dealerPosition + 2) % activePlayers
  };
}
function determineFirstToAct(dealerPosition, activePlayers, phase) {
  if (phase === "preflop" /* PREFLOP */) {
    if (activePlayers === 2) {
      return dealerPosition;
    }
    return (dealerPosition + 3) % activePlayers;
  }
  return (dealerPosition + 1) % activePlayers;
}

// client/src/pages/poker-lobby/poker-masr/logic/game-manager.ts
import * as pokerSolver2 from "pokersolver";
var GameManager = class {
  state;
  /**
   * إنشاء مدير اللعبة جديد
   */
  constructor(blindAmount = { small: 5, big: 10 }, minBuyIn = 200, maxBuyIn = 2e3) {
    this.state = {
      players: [],
      currentRound: {
        roundNumber: 0,
        deck: [],
        communityCards: [],
        pot: 0,
        sidePots: [],
        currentBet: 0,
        minRaise: blindAmount.big,
        dealer: 0,
        smallBlind: { position: 0, amount: blindAmount.small },
        bigBlind: { position: 0, amount: blindAmount.big },
        currentTurn: -1,
        lastRaisePosition: 0,
        gamePhase: "preflop" /* PREFLOP */,
        bettingRoundComplete: false,
        actionHistory: [],
        turnStartTime: 0,
        turnTimeLimit: 30
      },
      blindAmount,
      minBuyIn,
      maxBuyIn,
      isRunning: false,
      waitingForPlayers: true,
      tableCardReveals: 0
    };
    this.state.currentRound = this.createNewRound(0);
  }
  /**
   * الحصول على حالة اللعبة الحالية (نسخة للقراءة فقط)
   */
  getGameState() {
    return this.state;
  }
  /**
   * إضافة لاعب إلى اللعبة
   */
  addPlayer(id, username, chips, avatar, position, isAI = false) {
    if (chips < this.state.minBuyIn) {
      return {
        success: false,
        message: `\u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0644\u062F\u064A\u0643 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644 ${this.state.minBuyIn} \u0631\u0642\u0627\u0642\u0629 \u0644\u0644\u0627\u0646\u0636\u0645\u0627\u0645.`
      };
    }
    if (chips > this.state.maxBuyIn) {
      chips = this.state.maxBuyIn;
    }
    if (this.state.players.some((p) => p.id === id)) {
      return {
        success: false,
        message: "\u0623\u0646\u062A \u0628\u0627\u0644\u0641\u0639\u0644 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0644\u0639\u0628\u0629."
      };
    }
    if (this.state.players.length >= 9) {
      return {
        success: false,
        message: "\u0627\u0644\u0637\u0627\u0648\u0644\u0629 \u0645\u0645\u062A\u0644\u0626\u0629. \u064A\u0631\u062C\u0649 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629 \u0644\u0627\u062D\u0642\u0627\u064B."
      };
    }
    let playerPosition = position;
    if (playerPosition === void 0 || this.state.players.some((p) => p.position === playerPosition)) {
      const usedPositions = this.state.players.map((p) => p.position);
      for (let pos = 0; pos < 9; pos++) {
        if (!usedPositions.includes(pos)) {
          playerPosition = pos;
          break;
        }
      }
    }
    const newPlayer = {
      id,
      username,
      chips,
      position: playerPosition || 0,
      cards: [],
      folded: false,
      betAmount: 0,
      isAllIn: false,
      isActive: true,
      isCurrentTurn: false,
      avatar,
      isAI
    };
    this.state.players.push(newPlayer);
    if (this.state.players.length >= 2 && this.state.waitingForPlayers) {
      this.state.waitingForPlayers = false;
      this.startNewRound();
    }
    return {
      success: true
    };
  }
  /**
   * إزالة لاعب من اللعبة
   */
  removePlayer(playerId) {
    const playerIndex = this.state.players.findIndex((p) => p.id === playerId);
    if (playerIndex === -1) {
      return {
        success: false,
        message: "\u0627\u0644\u0644\u0627\u0639\u0628 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0644\u0639\u0628\u0629."
      };
    }
    const player = this.state.players[playerIndex];
    const chips = player.chips;
    this.state.players.splice(playerIndex, 1);
    if (player.isCurrentTurn) {
      this.moveToNextPlayer();
    }
    if (this.state.players.length < 2) {
      this.state.isRunning = false;
      this.state.waitingForPlayers = true;
    }
    return {
      success: true,
      chips
    };
  }
  /**
   * تنفيذ إجراء من قبل لاعب
   */
  performAction(playerId, action, amount) {
    const playerIndex = this.state.players.findIndex((p) => p.id === playerId);
    if (playerIndex === -1) {
      return {
        success: false,
        message: "\u0627\u0644\u0644\u0627\u0639\u0628 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0644\u0639\u0628\u0629."
      };
    }
    const player = this.state.players[playerIndex];
    if (!player.isCurrentTurn) {
      return {
        success: false,
        message: "\u0644\u064A\u0633 \u062F\u0648\u0631\u0643."
      };
    }
    if (player.folded || player.isAllIn) {
      return {
        success: false,
        message: player.folded ? "\u0644\u0642\u062F \u0627\u0646\u0633\u062D\u0628\u062A \u0645\u0646 \u0647\u0630\u0647 \u0627\u0644\u062C\u0648\u0644\u0629." : "\u0644\u0642\u062F \u0648\u0636\u0639\u062A \u0643\u0644 \u0631\u0642\u0627\u0626\u0642\u0643 \u0628\u0627\u0644\u0641\u0639\u0644."
      };
    }
    const actionRecord = {
      playerId,
      action,
      amount,
      timestamp: Date.now()
    };
    this.state.currentRound.actionHistory.push(actionRecord);
    let actionResult = { success: true };
    switch (action) {
      case "fold" /* FOLD */:
        actionResult = this.handleFold(player);
        break;
      case "check" /* CHECK */:
        actionResult = this.handleCheck(player);
        break;
      case "call" /* CALL */:
        actionResult = this.handleCall(player);
        break;
      case "raise" /* RAISE */:
        actionResult = this.handleRaise(player, amount || 0);
        break;
      case "all_in" /* ALL_IN */:
        actionResult = this.handleAllIn(player);
        break;
      default:
        return {
          success: false,
          message: "\u0625\u062C\u0631\u0627\u0621 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D."
        };
    }
    if (actionResult.success) {
      if (!actionResult.roundComplete) {
        const nextTurnResult = this.moveToNextPlayer();
        if (nextTurnResult.phaseChanged) {
          actionResult.gamePhaseChanged = true;
        }
      }
    }
    return actionResult;
  }
  /**
   * التعامل مع إجراء الانسحاب (Fold)
   */
  handleFold(player) {
    player.folded = true;
    player.isCurrentTurn = false;
    const activePlayers = this.state.players.filter((p) => !p.folded);
    if (activePlayers.length === 1) {
      const winner = activePlayers[0];
      const winnerInfo = {
        playerId: winner.id,
        handDescription: "\u0627\u0644\u0641\u0648\u0632 \u0628\u0627\u0646\u0633\u062D\u0627\u0628 \u0627\u0644\u062C\u0645\u064A\u0639",
        winningAmount: this.state.currentRound.pot,
        potNumber: 0
      };
      winner.chips += this.state.currentRound.pot;
      return {
        success: true,
        gameStateChanged: true,
        roundComplete: true,
        winners: [winnerInfo]
      };
    }
    return {
      success: true,
      gameStateChanged: true
    };
  }
  /**
   * التعامل مع إجراء التمرير (Check)
   */
  handleCheck(player) {
    if (this.state.currentRound.currentBet > player.betAmount) {
      return {
        success: false,
        message: "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0627\u0644\u062A\u0645\u0631\u064A\u0631. \u064A\u062C\u0628 \u0639\u0644\u064A\u0643 \u0627\u0644\u0645\u062C\u0627\u0631\u0627\u0629 \u0623\u0648 \u0627\u0644\u0632\u064A\u0627\u062F\u0629 \u0623\u0648 \u0627\u0644\u0627\u0646\u0633\u062D\u0627\u0628."
      };
    }
    player.isCurrentTurn = false;
    return {
      success: true,
      gameStateChanged: true
    };
  }
  /**
   * التعامل مع إجراء المجاراة (Call)
   */
  handleCall(player) {
    const currentBet = this.state.currentRound.currentBet;
    const amountToCall = currentBet - player.betAmount;
    if (amountToCall === 0) {
      return this.handleCheck(player);
    }
    if (player.chips <= amountToCall) {
      return this.handleAllIn(player);
    }
    player.chips -= amountToCall;
    player.betAmount = currentBet;
    this.state.currentRound.pot += amountToCall;
    player.isCurrentTurn = false;
    return {
      success: true,
      gameStateChanged: true
    };
  }
  /**
   * التعامل مع إجراء الزيادة (Raise)
   */
  handleRaise(player, amount) {
    const currentBet = this.state.currentRound.currentBet;
    const minRaise = this.state.currentRound.minRaise;
    const totalBet = player.betAmount + amount;
    if (totalBet < currentBet + minRaise) {
      return {
        success: false,
        message: `\u064A\u062C\u0628 \u0623\u0646 \u062A\u0643\u0648\u0646 \u0627\u0644\u0632\u064A\u0627\u062F\u0629 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644 ${minRaise} \u0631\u0642\u0627\u0642\u0629 \u0641\u0648\u0642 \u0627\u0644\u0631\u0647\u0627\u0646 \u0627\u0644\u062D\u0627\u0644\u064A.`
      };
    }
    if (player.chips < amount) {
      return {
        success: false,
        message: "\u0644\u064A\u0633 \u0644\u062F\u064A\u0643 \u0631\u0642\u0627\u0626\u0642 \u0643\u0627\u0641\u064A\u0629 \u0644\u0647\u0630\u0647 \u0627\u0644\u0632\u064A\u0627\u062F\u0629."
      };
    }
    player.chips -= amount;
    this.state.currentRound.pot += amount;
    player.betAmount += amount;
    this.state.currentRound.currentBet = player.betAmount;
    this.state.currentRound.minRaise = player.betAmount - currentBet;
    this.state.currentRound.lastRaisePosition = player.position;
    player.isCurrentTurn = false;
    this.state.currentRound.bettingRoundComplete = false;
    return {
      success: true,
      gameStateChanged: true
    };
  }
  /**
   * التعامل مع إجراء وضع كل الرقائق (All-In)
   */
  handleAllIn(player) {
    const chips = player.chips;
    const currentBet = this.state.currentRound.currentBet;
    const totalBet = player.betAmount + chips;
    player.chips = 0;
    this.state.currentRound.pot += chips;
    player.betAmount += chips;
    player.isAllIn = true;
    player.isCurrentTurn = false;
    if (totalBet > currentBet) {
      this.state.currentRound.currentBet = totalBet;
      this.state.currentRound.minRaise = totalBet - currentBet;
      this.state.currentRound.lastRaisePosition = player.position;
      this.createSidePots();
      this.state.currentRound.bettingRoundComplete = false;
    }
    return {
      success: true,
      gameStateChanged: true
    };
  }
  /**
   * الانتقال إلى اللاعب التالي
   */
  moveToNextPlayer() {
    let phaseChanged = false;
    const round = this.state.currentRound;
    const activePlayers = this.state.players.filter((p) => !p.folded && !p.isAllIn && p.isActive);
    if (round.turnTimeoutId) {
      clearTimeout(round.turnTimeoutId);
      round.turnTimeoutId = void 0;
    }
    if (this.isBettingRoundComplete() || activePlayers.length <= 1 || this.state.players.every((p) => p.folded || p.isAllIn || p.betAmount === round.currentBet)) {
      round.bettingRoundComplete = true;
      phaseChanged = this.moveToNextPhase();
      return { phaseChanged };
    }
    const currentPlayerIndex = this.state.players.findIndex((p) => p.isCurrentTurn);
    let nextPlayerIndex = -1;
    if (currentPlayerIndex !== -1) {
      this.state.players[currentPlayerIndex].isCurrentTurn = false;
    }
    for (let i = 1; i <= this.state.players.length; i++) {
      const index = (currentPlayerIndex + i) % this.state.players.length;
      const player = this.state.players[index];
      if (!player.folded && !player.isAllIn && player.isActive) {
        nextPlayerIndex = index;
        break;
      }
    }
    if (nextPlayerIndex === -1) {
      round.bettingRoundComplete = true;
      phaseChanged = this.moveToNextPhase();
      return { phaseChanged };
    }
    this.state.players[nextPlayerIndex].isCurrentTurn = true;
    round.currentTurn = this.state.players[nextPlayerIndex].position;
    round.turnStartTime = Date.now();
    this.setTurnTimer(this.state.players[nextPlayerIndex].id);
    return { phaseChanged };
  }
  /**
   * الانتقال إلى المرحلة التالية من اللعبة
   */
  moveToNextPhase() {
    const round = this.state.currentRound;
    for (const player of this.state.players) {
      player.isCurrentTurn = false;
    }
    round.actionHistory.push({
      playerId: -1,
      // -1 يشير إلى إجراء النظام
      action: "check" /* CHECK */,
      // استخدام CHECK كإجراء افتراضي
      timestamp: Date.now(),
      amount: 0
    });
    let newPhase;
    switch (round.gamePhase) {
      case "preflop" /* PREFLOP */:
        this.dealCommunityCards(3);
        newPhase = "flop" /* FLOP */;
        break;
      case "flop" /* FLOP */:
        this.dealCommunityCards(1);
        newPhase = "turn" /* TURN */;
        break;
      case "turn" /* TURN */:
        this.dealCommunityCards(1);
        newPhase = "river" /* RIVER */;
        break;
      case "river" /* RIVER */:
        return this.handleShowdown();
      default:
        return false;
    }
    round.gamePhase = newPhase;
    round.actionHistory.push({
      playerId: -1,
      // -1 يشير إلى إجراء النظام
      action: "check" /* CHECK */,
      // استخدام CHECK كإجراء افتراضي
      timestamp: Date.now(),
      amount: 0
    });
    round.currentBet = 0;
    round.minRaise = this.state.blindAmount.big;
    round.bettingRoundComplete = false;
    for (const player of this.state.players) {
      if (!player.folded && !player.isAllIn) {
        player.betAmount = 0;
      }
    }
    const firstPlayerPosition = determineFirstToAct(
      round.dealer,
      this.state.players.length,
      round.gamePhase
    );
    let found = false;
    for (let i = 0; i < this.state.players.length; i++) {
      const position = (firstPlayerPosition + i) % this.state.players.length;
      const player = this.state.players.find((p) => p.position === position && !p.folded && !p.isAllIn);
      if (player) {
        player.isCurrentTurn = true;
        round.currentTurn = player.position;
        round.turnStartTime = Date.now();
        this.setTurnTimer(player.id);
        found = true;
        break;
      }
    }
    if (!found) {
      if (round.gamePhase === "river" /* RIVER */) {
        return this.handleShowdown();
      }
      return this.moveToNextPhase();
    }
    return true;
  }
  /**
   * التعامل مع مرحلة إظهار البطاقات وحساب الفائز (Showdown)
   */
  handleShowdown() {
    const round = this.state.currentRound;
    round.gamePhase = "showdown" /* SHOWDOWN */;
    const activePlayers = this.state.players.filter((p) => !p.folded);
    if (activePlayers.length === 1) {
      const winner = activePlayers[0];
      winner.chips += round.pot;
      const winnerInfo = {
        playerId: winner.id,
        handDescription: "\u0627\u0644\u0641\u0648\u0632 \u0628\u0627\u0646\u0633\u062D\u0627\u0628 \u0627\u0644\u062C\u0645\u064A\u0639",
        winningAmount: round.pot,
        potNumber: 0
      };
      this.resetForNextRound([winnerInfo]);
      return true;
    }
    activePlayers.forEach((player) => {
      player.cards.forEach((card) => {
        card.hidden = false;
      });
    });
    const playerHands = activePlayers.map((player) => {
      const evaluation = evaluatePlayerHand(player.cards, round.communityCards);
      return {
        player,
        evaluation,
        handStrength: evaluation.strength
      };
    });
    const handDetails = playerHands.map((ph) => {
      return {
        playerId: ph.player.id,
        username: ph.player.username,
        handType: ph.evaluation.handType,
        description: ph.evaluation.description,
        strength: ph.evaluation.strength
      };
    });
    round.actionHistory.push({
      playerId: -1,
      // -1 للإشارة إلى أنه حدث نظام
      action: "check" /* CHECK */,
      // استخدام CHECK كنوع إجراء افتراضي
      timestamp: Date.now(),
      amount: 0
      // يمكن إضافة معلومات مخصصة هنا أيضًا
    });
    playerHands.sort((a, b) => b.handStrength - a.handStrength);
    let winners = [];
    const mainPotWinners = this.determineWinners(playerHands, round.pot, 0);
    winners = winners.concat(mainPotWinners);
    for (let i = 0; i < round.sidePots.length; i++) {
      const sidePot = round.sidePots[i];
      const eligiblePlayers = playerHands.filter(
        (ph) => sidePot.eligiblePlayers.includes(ph.player.id)
      );
      const sidePotWinners = this.determineWinners(eligiblePlayers, sidePot.amount, i + 1);
      winners = winners.concat(sidePotWinners);
    }
    if (winners.length > 0) {
      const winnerIds = winners.map((w) => w.playerId);
      const winnerUsernames = winners.map((w) => {
        const player = this.state.players.find((p) => p.id === w.playerId);
        return player ? player.username : "\u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641";
      });
      round.actionHistory.push({
        playerId: -2,
        // -2 للإشارة إلى إعلان الفائزين
        action: "check" /* CHECK */,
        // استخدام CHECK كنوع إجراء افتراضي
        timestamp: Date.now(),
        amount: 0
        // يمكن إضافة معلومات مخصصة هنا أيضًا
      });
    }
    this.resetForNextRound(winners);
    return true;
  }
  /**
   * تحديد الفائزين وتوزيع البوت باستخدام مكتبة pokersolver
   */
  determineWinners(rankedPlayers, potAmount, potNumber) {
    if (rankedPlayers.length === 0) {
      return [];
    }
    const winners = [];
    const solverResults = rankedPlayers.filter((p) => p.evaluation && p.evaluation.solverResult).map((p) => p.evaluation.solverResult);
    if (solverResults.length === rankedPlayers.length && solverResults.length > 0) {
      const winningHands = pokerSolver2.Hand.winners(solverResults);
      const potWinners = rankedPlayers.filter(
        (p) => winningHands.some(
          (wh) => wh.name === p.evaluation.solverResult.name && JSON.stringify(wh.cards) === JSON.stringify(p.evaluation.solverResult.cards)
        )
      );
      const winAmount = Math.floor(potAmount / potWinners.length);
      for (const winner of potWinners) {
        winner.player.chips += winAmount;
        winners.push({
          playerId: winner.player.id,
          handDescription: winner.evaluation.description,
          winningAmount: winAmount,
          potNumber
        });
      }
    } else {
      const highestStrength = Math.max(...rankedPlayers.map((p) => p.handStrength));
      const potWinners = rankedPlayers.filter((p) => p.handStrength === highestStrength);
      const winAmount = Math.floor(potAmount / potWinners.length);
      for (const winner of potWinners) {
        winner.player.chips += winAmount;
        winners.push({
          playerId: winner.player.id,
          handDescription: winner.evaluation.description,
          winningAmount: winAmount,
          potNumber
        });
      }
    }
    return winners;
  }
  /**
   * إعادة تعيين اللعبة للجولة التالية
   */
  resetForNextRound(winners) {
    this.state.players = this.state.players.filter((p) => p.chips > 0);
    if (this.state.players.length < 2) {
      this.state.isRunning = false;
      this.state.waitingForPlayers = true;
      return;
    }
    this.startNewRound();
  }
  /**
   * بدء جولة جديدة
   */
  startNewRound() {
    const newDealerPosition = rotateDealer(
      this.state.currentRound.dealer,
      this.state.players.length
    );
    this.state.currentRound = this.createNewRound(newDealerPosition);
    this.state.isRunning = true;
    this.dealPlayerCards();
    this.placeBlindBets();
    const firstToAct = determineFirstToAct(
      newDealerPosition,
      this.state.players.length,
      "preflop" /* PREFLOP */
    );
    for (let i = 0; i < this.state.players.length; i++) {
      const position = (firstToAct + i) % this.state.players.length;
      const player = this.state.players.find((p) => p.position === position);
      if (player && !player.folded && !player.isAllIn) {
        player.isCurrentTurn = true;
        this.state.currentRound.currentTurn = player.position;
        this.state.currentRound.turnStartTime = Date.now();
        this.setTurnTimer(player.id);
        break;
      }
    }
  }
  /**
   * إنشاء جولة جديدة
   */
  createNewRound(dealerPosition) {
    const deck = shuffleDeck2(createDeck2());
    const playerCount = this.state?.players?.length || 2;
    const blindPositions = determineBlindPositions(dealerPosition, playerCount);
    const smallBlindAmount = this.state?.blindAmount?.small || 5;
    const bigBlindAmount = this.state?.blindAmount?.big || 10;
    return {
      roundNumber: this.state?.currentRound ? this.state.currentRound.roundNumber + 1 : 1,
      deck,
      communityCards: [],
      pot: 0,
      sidePots: [],
      currentBet: bigBlindAmount,
      minRaise: bigBlindAmount,
      dealer: dealerPosition,
      smallBlind: {
        position: blindPositions.smallBlind,
        amount: smallBlindAmount
      },
      bigBlind: {
        position: blindPositions.bigBlind,
        amount: bigBlindAmount
      },
      currentTurn: -1,
      lastRaisePosition: blindPositions.bigBlind,
      gamePhase: "preflop" /* PREFLOP */,
      bettingRoundComplete: false,
      actionHistory: [],
      turnStartTime: 0,
      turnTimeLimit: 30
      // 30 ثانية للدور
    };
  }
  /**
   * توزيع البطاقات على اللاعبين
   */
  dealPlayerCards() {
    for (const player of this.state.players) {
      player.cards = [];
      player.folded = false;
      player.betAmount = 0;
      player.isAllIn = false;
      player.isCurrentTurn = false;
    }
    for (let i = 0; i < 2; i++) {
      for (const player of this.state.players) {
        if (this.state.currentRound.deck.length > 0) {
          const card = this.state.currentRound.deck.pop();
          player.cards.push(card);
        }
      }
    }
  }
  /**
   * توزيع بطاقات المجتمع (community cards)
   */
  dealCommunityCards(count) {
    const round = this.state.currentRound;
    for (let i = 0; i < count; i++) {
      if (round.deck.length > 0) {
        const card = round.deck.pop();
        card.hidden = false;
        round.communityCards.push(card);
      }
    }
    this.state.tableCardReveals += count;
  }
  /**
   * وضع المكفوفين (small blind & big blind)
   */
  placeBlindBets() {
    const round = this.state.currentRound;
    const smallBlindPlayer = this.state.players.find((p) => p.position === round.smallBlind.position);
    const bigBlindPlayer = this.state.players.find((p) => p.position === round.bigBlind.position);
    if (smallBlindPlayer) {
      const smallBlindAmount = Math.min(smallBlindPlayer.chips, round.smallBlind.amount);
      smallBlindPlayer.chips -= smallBlindAmount;
      smallBlindPlayer.betAmount = smallBlindAmount;
      round.pot += smallBlindAmount;
      if (smallBlindPlayer.chips === 0) {
        smallBlindPlayer.isAllIn = true;
      }
    }
    if (bigBlindPlayer) {
      const bigBlindAmount = Math.min(bigBlindPlayer.chips, round.bigBlind.amount);
      bigBlindPlayer.chips -= bigBlindAmount;
      bigBlindPlayer.betAmount = bigBlindAmount;
      round.pot += bigBlindAmount;
      round.currentBet = bigBlindAmount;
      if (bigBlindPlayer.chips === 0) {
        bigBlindPlayer.isAllIn = true;
      }
    }
  }
  /**
   * إنشاء بوت جانبية (side pots) في حالة all-in
   */
  createSidePots() {
    const round = this.state.currentRound;
    const activePlayers = this.state.players.filter((p) => !p.folded);
    const allInPlayers = activePlayers.filter((p) => p.isAllIn);
    if (allInPlayers.length === 0) {
      return;
    }
    const sortedPlayers = [...activePlayers].sort((a, b) => a.betAmount - b.betAmount);
    round.sidePots = [];
    let processedBet = 0;
    for (const player of sortedPlayers) {
      if (player.isAllIn) {
        const currentBet = player.betAmount;
        const potAmount = (currentBet - processedBet) * sortedPlayers.length;
        const eligiblePlayers = sortedPlayers.filter((p) => p.betAmount >= currentBet).map((p) => p.id);
        round.sidePots.push({
          amount: potAmount,
          eligiblePlayers
        });
        processedBet = currentBet;
      }
    }
  }
  /**
   * إعداد مؤقت لانتهاء وقت دور اللاعب
   */
  setTurnTimer(playerId) {
    const round = this.state.currentRound;
    if (round.turnTimeoutId) {
      clearTimeout(round.turnTimeoutId);
    }
    round.turnTimeoutId = setTimeout(() => {
      const player = this.state.players.find((p) => p.id === playerId);
      if (player && player.isCurrentTurn) {
        if (player.betAmount === round.currentBet) {
          this.performAction(playerId, "check" /* CHECK */);
        } else {
          this.performAction(playerId, "fold" /* FOLD */);
        }
      }
    }, round.turnTimeLimit * 1e3);
  }
  /**
   * التحقق من اكتمال جولة المراهنة
   */
  isBettingRoundComplete() {
    const round = this.state.currentRound;
    if (round.bettingRoundComplete) {
      return true;
    }
    const activePlayers = this.state.players.filter((p) => !p.folded && !p.isAllIn);
    if (activePlayers.length <= 1) {
      return true;
    }
    const allBetsEqual = activePlayers.every((p) => p.betAmount === round.currentBet);
    let lastRaisePlayerIndex = -1;
    for (let i = 0; i < this.state.players.length; i++) {
      if (this.state.players[i].position === round.lastRaisePosition) {
        lastRaisePlayerIndex = i;
        break;
      }
    }
    const lastActionIndex = round.actionHistory.length - 1;
    let lastPlayerAction = -1;
    if (lastActionIndex >= 0) {
      const lastAction = round.actionHistory[lastActionIndex];
      const lastPlayer = this.state.players.find((p) => p.id === lastAction.playerId);
      if (lastPlayer) {
        lastPlayerAction = this.state.players.indexOf(lastPlayer);
      }
    }
    return allBetsEqual && (lastPlayerAction === lastRaisePlayerIndex - 1 || lastPlayerAction === this.state.players.length - 1 && lastRaisePlayerIndex === 0);
  }
};

// server/poker.ts
var pokerModule = {
  broadcastToTable: null,
  broadcastToRoom: null,
  userTables: /* @__PURE__ */ new Map(),
  // معرف المستخدم -> معرف الطاولة
  userRooms: /* @__PURE__ */ new Map(),
  // معرف المستخدم -> معرف الغرفة
  clients: /* @__PURE__ */ new Map(),
  // معرف المستخدم -> معلومات العميل
  tables: /* @__PURE__ */ new Map(),
  // معرف الطاولة -> معلومات الطاولة
  rooms: /* @__PURE__ */ new Map()
  // معرف الغرفة -> معلومات الغرفة
};
function setupPokerGame(app2, httpServer) {
  const wss = new WebSocketServer({
    server: httpServer,
    path: "/ws",
    // مسار محدد لاتصالات WebSocket
    perMessageDeflate: false,
    // تعطيل الضغط لتعزيز التوافق والأداء
    clientTracking: true
    // تتبع العملاء تلقائياً
  });
  function createPokerRoom(id, name, description, blindAmount, minBuyIn, maxBuyIn, isVIP = false, maxPlayers = 6) {
    console.log(`\u0625\u0646\u0634\u0627\u0621 \u063A\u0631\u0641\u0629 \u0628\u0648\u0643\u0631: ${name} \u0645\u0639 blindAmount=${JSON.stringify(blindAmount)}, minBuyIn=${minBuyIn}, maxBuyIn=${maxBuyIn}`);
    try {
      const room = {
        id,
        name,
        description,
        minBuyIn,
        maxBuyIn,
        smallBlind: blindAmount.small,
        bigBlind: blindAmount.big,
        isVIP,
        maxPlayers,
        tables: /* @__PURE__ */ new Map(),
        createdAt: /* @__PURE__ */ new Date()
      };
      pokerModule.rooms.set(id, room);
      console.log(`\u062A\u0645 \u0625\u0646\u0634\u0627\u0621 \u063A\u0631\u0641\u0629 \u0628\u0648\u0643\u0631 \u062C\u062F\u064A\u062F\u0629: ${name} (ID: ${id})`);
      return room;
    } catch (error) {
      console.error(`\u062E\u0637\u0623 \u0641\u064A \u0625\u0646\u0634\u0627\u0621 \u063A\u0631\u0641\u0629 \u0627\u0644\u0628\u0648\u0643\u0631: ${name}`, error);
      throw error;
    }
  }
  function createPokerTable(id, roomId, name, maxPlayers = 6) {
    const room = pokerModule.rooms.get(roomId);
    if (!room) {
      console.error(`\u0645\u062D\u0627\u0648\u0644\u0629 \u0625\u0646\u0634\u0627\u0621 \u0637\u0627\u0648\u0644\u0629 \u0641\u064A \u063A\u0631\u0641\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629: ${roomId}`);
      return null;
    }
    console.log(`\u0625\u0646\u0634\u0627\u0621 \u0637\u0627\u0648\u0644\u0629 \u0628\u0648\u0643\u0631: ${name} \u0641\u064A \u0627\u0644\u063A\u0631\u0641\u0629 ${room.name}`);
    try {
      const blindAmount = { small: room.smallBlind, big: room.bigBlind };
      const gameManager = new GameManager(blindAmount, room.minBuyIn, room.maxBuyIn);
      console.log(`\u062A\u0645 \u0625\u0646\u0634\u0627\u0621 \u0645\u062F\u064A\u0631 \u0627\u0644\u0644\u0639\u0628\u0629 \u0628\u0646\u062C\u0627\u062D \u0644\u0644\u0637\u0627\u0648\u0644\u0629: ${name}`);
      const table = {
        id,
        roomId,
        name,
        gameManager,
        status: "waiting" /* WAITING */,
        players: /* @__PURE__ */ new Map(),
        maxPlayers,
        createdAt: /* @__PURE__ */ new Date()
      };
      pokerModule.tables.set(id, table);
      room.tables.set(id, table);
      console.log(`\u062A\u0645 \u0625\u0646\u0634\u0627\u0621 \u0637\u0627\u0648\u0644\u0629 \u0628\u0648\u0643\u0631 \u062C\u062F\u064A\u062F\u0629: ${name} (ID: ${id}) \u0641\u064A \u0627\u0644\u063A\u0631\u0641\u0629 ${room.name}`);
      const tableInfo = getTableInfo(table);
      if (broadcastToRoom) {
        broadcastToRoom(roomId, {
          type: "table_created" /* TABLE_CREATED */,
          tableInfo
        });
      }
      return table;
    } catch (error) {
      console.error(`\u062E\u0637\u0623 \u0641\u064A \u0625\u0646\u0634\u0627\u0621 \u0637\u0627\u0648\u0644\u0629 \u0627\u0644\u0628\u0648\u0643\u0631: ${name}`, error);
      throw error;
    }
  }
  function getTableInfo(table) {
    const gameState = table.gameManager.getState ? table.gameManager.getState() : { players: [], currentRound: { isActive: false } };
    return {
      id: table.id,
      roomId: table.roomId,
      name: table.name,
      status: table.status,
      playersCount: table.players ? table.players.size : 0,
      maxPlayers: table.maxPlayers,
      minBuyIn: table.gameManager.minBuyIn || 0,
      maxBuyIn: table.gameManager.maxBuyIn || 0,
      blinds: {
        small: table.gameManager.blinds?.small || 0,
        big: table.gameManager.blinds?.big || 0
      },
      isRoundActive: gameState.currentRound?.isActive || false,
      createdAt: table.createdAt
    };
  }
  function getRoomInfo(room) {
    let playersCount = 0;
    room.tables.forEach((table) => {
      playersCount += table.players.size;
    });
    return {
      id: room.id,
      name: room.name,
      description: room.description,
      minBuyIn: room.minBuyIn,
      maxBuyIn: room.maxBuyIn,
      blinds: { small: room.smallBlind, big: room.bigBlind },
      isVIP: room.isVIP,
      tablesCount: room.tables.size,
      playersCount,
      maxPlayersPerTable: room.maxPlayers,
      createdAt: room.createdAt
    };
  }
  function createDefaultPokerRoomsAndTables() {
    const beginnerRoom = createPokerRoom(
      1,
      "\u063A\u0631\u0641\u0629 \u0627\u0644\u0645\u0628\u062A\u062F\u0626\u064A\u0646",
      "\u063A\u0631\u0641\u0629 \u0645\u0646\u0627\u0633\u0628\u0629 \u0644\u0644\u0627\u0639\u0628\u064A\u0646 \u0627\u0644\u062C\u062F\u062F \u0641\u064A \u0644\u0639\u0628\u0629 \u0627\u0644\u0628\u0648\u0643\u0631",
      { small: 5, big: 10 },
      200,
      2e3,
      false,
      6
    );
    createPokerTable(101, 1, "\u0637\u0627\u0648\u0644\u0629 \u0627\u0644\u0645\u0628\u062A\u062F\u0626\u064A\u0646 1", 6);
    createPokerTable(102, 1, "\u0637\u0627\u0648\u0644\u0629 \u0627\u0644\u0645\u0628\u062A\u062F\u0626\u064A\u0646 2", 4);
    const proRoom = createPokerRoom(
      2,
      "\u063A\u0631\u0641\u0629 \u0627\u0644\u0645\u062D\u062A\u0631\u0641\u064A\u0646",
      "\u063A\u0631\u0641\u0629 \u0644\u0644\u0627\u0639\u0628\u064A\u0646 \u0630\u0648\u064A \u0627\u0644\u062E\u0628\u0631\u0629 \u0645\u0639 \u0631\u0647\u0627\u0646\u0627\u062A \u0623\u0639\u0644\u0649",
      { small: 25, big: 50 },
      1e3,
      1e4,
      false,
      6
    );
    createPokerTable(201, 2, "\u0637\u0627\u0648\u0644\u0629 \u0627\u0644\u0645\u062D\u062A\u0631\u0641\u064A\u0646 1", 6);
    createPokerTable(202, 2, "\u0637\u0627\u0648\u0644\u0629 \u0627\u0644\u0645\u062D\u062A\u0631\u0641\u064A\u0646 2", 4);
    const vipRoom = createPokerRoom(
      3,
      "\u063A\u0631\u0641\u0629 VIP",
      "\u063A\u0631\u0641\u0629 \u062D\u0635\u0631\u064A\u0629 \u0645\u0639 \u0631\u0647\u0627\u0646\u0627\u062A \u0639\u0627\u0644\u064A\u0629",
      { small: 100, big: 200 },
      5e3,
      5e4,
      true,
      4
    );
    createPokerTable(301, 3, "\u0637\u0627\u0648\u0644\u0629 VIP", 4);
  }
  const clients = /* @__PURE__ */ new Map();
  const userTables = /* @__PURE__ */ new Map();
  const lastKnownUserStates = /* @__PURE__ */ new Map();
  const broadcast = (message, excludeUserId) => {
    const serializedMessage = JSON.stringify(message);
    clients.forEach((clientInfo, userId) => {
      if (userId !== excludeUserId && clientInfo.ws.readyState === WebSocket.OPEN) {
        try {
          clientInfo.ws.send(serializedMessage);
        } catch (err) {
          console.error(`\u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u0628\u062B \u0644\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId}:`, err);
        }
      }
    });
  };
  const getOnlineCount = () => {
    return clients.size;
  };
  let activeCounter = 0;
  const broadcastOnlineUsers = () => {
    const realCount = getOnlineCount();
    activeCounter++;
    console.log(`\u0639\u062F\u062F \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645\u064A\u0646 \u0627\u0644\u0645\u062A\u0635\u0644\u064A\u0646 \u062D\u0642\u064A\u0642\u064A\u0627\u064B: ${realCount}`);
    console.log(`\u0627\u0644\u0639\u062F\u0627\u062F: ${activeCounter}`);
    console.log(`\u0625\u062C\u0645\u0627\u0644\u064A \u0639\u062F\u062F \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645\u064A\u0646 \u0627\u0644\u0645\u062A\u0635\u0644\u064A\u0646 \u0645\u0639 \u0627\u0644\u0648\u0647\u0645\u064A\u064A\u0646: ${realCount}`);
    const message = {
      type: "online_users_count",
      count: realCount
    };
    broadcast(message);
  };
  const PING_INTERVAL = 5e3;
  const UPDATE_INTERVAL = 5e3;
  const updateIntervalId = setInterval(() => {
    broadcastOnlineUsers();
  }, UPDATE_INTERVAL);
  const heartbeatIntervalId = setInterval(() => {
    console.log("\u0625\u0631\u0633\u0627\u0644 \u0646\u0628\u0636 \u0645\u0639\u0644\u0648\u0645\u0627\u062A\u064A \u0644\u062C\u0645\u064A\u0639 \u0627\u0644\u0639\u0645\u0644\u0627\u0621 \u0627\u0644\u0645\u062A\u0635\u0644\u064A\u0646...");
    const now = Date.now();
    clients.forEach((clientInfo, userId) => {
      if (clientInfo.ws.readyState === WebSocket.OPEN) {
        try {
          clientInfo.ws.send(JSON.stringify({
            type: "ping",
            timestamp: now,
            serverTime: (/* @__PURE__ */ new Date()).toISOString()
          }));
          clientInfo.lastPing = now;
        } catch (err) {
          console.error(`\u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0625\u0631\u0633\u0627\u0644 \u0646\u0628\u0636 \u0644\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId}:`, err);
        }
      }
    });
  }, PING_INTERVAL);
  createDefaultPokerRoomsAndTables();
  function broadcastToTable(tableId, message, excludeUserId) {
    if (tableId === void 0 || isNaN(tableId)) {
      console.warn("\u0645\u062D\u0627\u0648\u0644\u0629 \u0628\u062B \u0631\u0633\u0627\u0644\u0629 \u0644\u0637\u0627\u0648\u0644\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u0629:", tableId, message);
      return;
    }
    const players = getPlayersAtTable(tableId);
    const serializedMessage = JSON.stringify(message);
    for (const playerId of players) {
      if (excludeUserId !== void 0 && playerId === excludeUserId) continue;
      const clientInfo = clients.get(playerId);
      if (clientInfo && clientInfo.ws.readyState === WebSocket.OPEN) {
        try {
          clientInfo.ws.send(serializedMessage);
        } catch (err) {
          console.error(`\u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u0628\u062B \u0644\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${playerId} \u0641\u064A \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId}:`, err);
        }
      }
    }
  }
  function broadcastToRoom(roomId, message, excludeUserId) {
    if (roomId === void 0 || isNaN(roomId)) {
      console.warn("\u0645\u062D\u0627\u0648\u0644\u0629 \u0628\u062B \u0631\u0633\u0627\u0644\u0629 \u0644\u063A\u0631\u0641\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u0629:", roomId, message);
      return;
    }
    const room = pokerModule.rooms.get(roomId);
    if (!room) {
      console.warn("\u0645\u062D\u0627\u0648\u0644\u0629 \u0628\u062B \u0631\u0633\u0627\u0644\u0629 \u0644\u063A\u0631\u0641\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629:", roomId);
      return;
    }
    const players = [];
    const userRooms = pokerModule.userRooms;
    userRooms.forEach((userRoomId, userId) => {
      if (userRoomId === roomId) {
        players.push(userId);
      }
    });
    room.tables.forEach((table, tableId) => {
      const tablePlayers2 = getPlayersAtTable(tableId);
      for (const playerId of tablePlayers2) {
        if (!players.includes(playerId)) {
          players.push(playerId);
        }
      }
    });
    const serializedMessage = JSON.stringify(message);
    for (const playerId of players) {
      if (excludeUserId !== void 0 && playerId === excludeUserId) continue;
      const clientInfo = clients.get(playerId);
      if (clientInfo && clientInfo.ws.readyState === WebSocket.OPEN) {
        try {
          clientInfo.ws.send(serializedMessage);
        } catch (err) {
          console.error(`\u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u0628\u062B \u0644\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${playerId} \u0641\u064A \u0627\u0644\u063A\u0631\u0641\u0629 ${roomId}:`, err);
        }
      }
    }
  }
  function getPlayersInRoom(roomId) {
    const players = [];
    const userRooms = pokerModule.userRooms;
    if (isNaN(roomId)) return players;
    userRooms.forEach((userRoomId, userId) => {
      if (userRoomId === roomId) {
        players.push(userId);
      }
    });
    const room = pokerModule.rooms.get(roomId);
    if (room) {
      room.tables.forEach((_, tableId) => {
        const tablePlayers2 = getPlayersAtTable(tableId);
        for (const playerId of tablePlayers2) {
          if (!players.includes(playerId)) {
            players.push(playerId);
          }
        }
      });
    }
    return players;
  }
  pokerModule.broadcastToTable = broadcastToTable;
  pokerModule.broadcastToRoom = broadcastToRoom;
  pokerModule.userTables = userTables;
  pokerModule.userRooms = /* @__PURE__ */ new Map();
  pokerModule.clients = clients;
  function getPlayersAtTable(tableId) {
    const players = [];
    if (isNaN(tableId)) return players;
    userTables.forEach((userTableId, userId) => {
      if (userTableId === tableId) {
        players.push(userId);
      }
    });
    return players;
  }
  process.on("SIGINT", cleanupServer);
  process.on("SIGTERM", cleanupServer);
  function cleanupServer() {
    console.log("\u062A\u0646\u0638\u064A\u0641 \u0627\u062A\u0635\u0627\u0644\u0627\u062A WebSocket \u0642\u0628\u0644 \u0625\u063A\u0644\u0627\u0642 \u0627\u0644\u062E\u0627\u062F\u0645...");
    clearInterval(updateIntervalId);
    clearInterval(heartbeatIntervalId);
    clients.forEach((clientInfo) => {
      try {
        clientInfo.ws.close(1e3, "Server shutdown");
      } catch (err) {
      }
    });
    wss.close();
    setTimeout(() => {
      process.exit(0);
    }, 1e3);
  }
  wss.on("connection", (ws, req) => {
    let userId;
    const connectionTime = Date.now();
    const newClient = {
      ws,
      userId: 0,
      isAlive: true,
      lastPing: connectionTime,
      reconnectCount: 0,
      joinedAt: connectionTime
    };
    const heartbeat = () => {
      if (userId && clients.has(userId)) {
        const clientInfo = clients.get(userId);
        if (clientInfo) {
          clientInfo.isAlive = true;
          console.log(`\u062A\u0645 \u062A\u062D\u062F\u064A\u062B heartbeat \u0644\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId}`);
        }
      }
    };
    ws.on("pong", heartbeat);
    heartbeat();
    ws.on("message", async (message) => {
      try {
        const data = JSON.parse(message.toString());
        if (data.type === "pong" || data.type === "client_ping") {
          heartbeat();
        } else if (data.type === "get_rooms" /* GET_ROOMS */) {
          const rooms = [];
          pokerModule.rooms.forEach((room) => {
            rooms.push(getRoomInfo(room));
          });
          ws.send(JSON.stringify({
            type: "rooms_list" /* ROOMS_LIST */,
            rooms
          }));
        } else if (data.type === "get_tables" /* GET_TABLES */) {
          const roomId = data.roomId;
          if (!roomId || isNaN(Number(roomId))) {
            ws.send(JSON.stringify({
              type: "error",
              message: "\u0645\u0639\u0631\u0641 \u0627\u0644\u063A\u0631\u0641\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D"
            }));
            return;
          }
          const room = pokerModule.rooms.get(Number(roomId));
          if (!room) {
            ws.send(JSON.stringify({
              type: "error",
              message: "\u0627\u0644\u063A\u0631\u0641\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629"
            }));
            return;
          }
          const tables = [];
          room.tables.forEach((table) => {
            tables.push(getTableInfo(table));
          });
          ws.send(JSON.stringify({
            type: "tables_list" /* TABLES_LIST */,
            roomId,
            tables
          }));
        } else if (data.type === "create_table" /* CREATE_TABLE */) {
          if (!userId) {
            ws.send(JSON.stringify({ type: "error", message: "\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0635\u0631\u062D \u0628\u0647" }));
            return;
          }
          const roomId = data.roomId;
          const tableName = data.tableName || `\u0637\u0627\u0648\u0644\u0629 ${userId}_${Date.now()}`;
          const maxPlayers = data.maxPlayers || 6;
          if (!roomId || isNaN(Number(roomId))) {
            ws.send(JSON.stringify({
              type: "error",
              message: "\u0645\u0639\u0631\u0641 \u0627\u0644\u063A\u0631\u0641\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D"
            }));
            return;
          }
          const room = pokerModule.rooms.get(Number(roomId));
          if (!room) {
            ws.send(JSON.stringify({
              type: "error",
              message: "\u0627\u0644\u063A\u0631\u0641\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629"
            }));
            return;
          }
          const tableId = Date.now();
          const table = createPokerTable(tableId, Number(roomId), tableName, maxPlayers);
          if (!table) {
            ws.send(JSON.stringify({
              type: "error",
              message: "\u0641\u0634\u0644 \u0625\u0646\u0634\u0627\u0621 \u0627\u0644\u0637\u0627\u0648\u0644\u0629"
            }));
            return;
          }
          ws.send(JSON.stringify({
            type: "table_created" /* TABLE_CREATED */,
            tableInfo: getTableInfo(table),
            roomId: Number(roomId)
          }));
          broadcast({
            type: "table_created" /* TABLE_CREATED */,
            tableInfo: getTableInfo(table),
            roomId: Number(roomId)
          }, userId);
        } else if (data.type === "auth") {
          const user = await storage.getUser(data.userId);
          if (!user) {
            ws.send(JSON.stringify({ type: "error", message: "\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0635\u0631\u062D \u0628\u0647" }));
            return;
          }
          userId = user.id;
          newClient.userId = userId;
          if (clients.has(userId)) {
            const existingClient = clients.get(userId);
            if (existingClient && existingClient.ws !== ws) {
              try {
                existingClient.ws.close(1e3, "New connection established");
              } catch (e) {
              }
            }
            newClient.reconnectCount = (existingClient?.reconnectCount || 0) + 1;
            if (existingClient?.tableId) {
              newClient.tableId = existingClient.tableId;
              userTables.set(userId, existingClient.tableId);
            } else if (lastKnownUserStates.has(userId)) {
              const lastState = lastKnownUserStates.get(userId);
              if (lastState && lastState.tableId) {
                newClient.tableId = lastState.tableId;
                userTables.set(userId, lastState.tableId);
              }
            }
          }
          clients.set(userId, newClient);
          ws.send(JSON.stringify({
            type: "auth",
            success: true,
            reconnectCount: newClient.reconnectCount,
            serverTime: (/* @__PURE__ */ new Date()).toISOString()
          }));
          broadcastOnlineUsers();
        } else if (data.type === "chat_message" || data.type === "table_chat_message") {
          const messageId = data.id || `msg_${Date.now()}`;
          let username = data.username;
          let avatar = data.avatar;
          let timestamp2 = data.timestamp || Date.now();
          if (userId) {
            try {
              const user = await storage.getUser(userId);
              if (user) {
                username = username || user.username;
                avatar = avatar || user.avatar;
                console.log(`\u0645\u0639\u0627\u0644\u062C\u0629 \u0631\u0633\u0627\u0644\u0629 \u0645\u0646 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${username}`);
              }
            } catch (e) {
              console.error("\u062E\u0637\u0623 \u0641\u064A \u0627\u0644\u062D\u0635\u0648\u0644 \u0639\u0644\u0649 \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645:", e);
            }
          }
          if (username && data.message && data.message.trim().length > 0) {
            const chatMessage = {
              type: data.type,
              // استخدم نوع الرسالة الذي تم استلامه
              id: messageId,
              username,
              message: data.message.trim(),
              avatar,
              timestamp: timestamp2,
              tableId: data.tableId
              // معرف الطاولة للرسائل الخاصة بالطاولة
            };
            const messageType = data.type === "table_chat_message" ? "\u062F\u0631\u062F\u0634\u0629 \u0627\u0644\u0637\u0627\u0648\u0644\u0629" : "\u0627\u0644\u062F\u0631\u062F\u0634\u0629 \u0627\u0644\u0639\u0627\u0645\u0629";
            console.log(`\u0631\u0633\u0627\u0644\u0629 \u062C\u062F\u064A\u062F\u0629 \u0641\u064A ${messageType} \u0645\u0646 ${username}: ${data.message.substring(0, 30)}${data.message.length > 30 ? "..." : ""}`);
            if (!data.clientHandled) {
              ws.send(JSON.stringify(chatMessage));
            }
            if (data.type === "table_chat_message" && data.tableId) {
              broadcastToTable(data.tableId, chatMessage, userId);
            } else {
              broadcast(chatMessage, userId);
            }
          } else {
            ws.send(JSON.stringify({
              type: "error",
              message: "\u0627\u0644\u0631\u0633\u0627\u0644\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u0629"
            }));
          }
        } else if (data.type === "join_table" /* JOIN_TABLE */) {
          if (!userId) {
            ws.send(JSON.stringify({ type: "error", message: "\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0635\u0631\u062D \u0628\u0647" }));
            return;
          }
          const tableId = data.tableId;
          const safeTableId = Number(tableId);
          if (!tableId || isNaN(safeTableId)) {
            ws.send(JSON.stringify({ type: "error", message: "\u0645\u0639\u0631\u0641 \u0627\u0644\u0637\u0627\u0648\u0644\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D" }));
            return;
          }
          const table = pokerModule.tables.get(safeTableId);
          if (!table) {
            ws.send(JSON.stringify({ type: "error", message: "\u0627\u0644\u0637\u0627\u0648\u0644\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629" }));
            return;
          }
          const currentPlayers = getPlayersAtTable(safeTableId);
          if (currentPlayers.length >= table.maxPlayers) {
            ws.send(JSON.stringify({ type: "error", message: "\u0627\u0644\u0637\u0627\u0648\u0644\u0629 \u0645\u0645\u062A\u0644\u0626\u0629" }));
            return;
          }
          userTables.set(userId, safeTableId);
          pokerModule.userRooms.set(userId, table.roomId);
          if (clients.has(userId)) {
            const clientInfo = clients.get(userId);
            if (clientInfo) {
              clientInfo.tableId = safeTableId;
            }
          }
          if (ws.readyState === WebSocket.OPEN) {
            table.players.set(userId, ws);
          }
          if (table.status === "waiting" /* WAITING */ && currentPlayers.length + 1 >= 2) {
            table.status = "starting" /* STARTING */;
          }
          broadcastToTable(safeTableId, {
            type: "player_joined" /* PLAYER_JOINED */,
            userId,
            tableId: safeTableId,
            playerCount: currentPlayers.length + 1
          }, userId);
          const gameState = table.gameManager.getState ? table.gameManager.getState() : await storage.getGameState(tableId, userId);
          ws.send(JSON.stringify({
            type: "game_state" /* GAME_STATE */,
            gameState
          }));
          broadcastToTable(safeTableId, {
            type: "table_update" /* TABLE_UPDATE */,
            tableInfo: getTableInfo(table)
          });
        } else if (data.type === "start_round" /* START_ROUND */) {
          if (!userId) {
            ws.send(JSON.stringify({ type: "error", message: "\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0635\u0631\u062D \u0628\u0647" }));
            return;
          }
          const tableId = userTables.get(userId);
          if (!tableId) {
            ws.send(JSON.stringify({ type: "error", message: "\u0623\u0646\u062A \u0644\u0633\u062A \u0641\u064A \u0637\u0627\u0648\u0644\u0629" }));
            return;
          }
          const table = pokerModule.tables.get(tableId);
          if (!table) {
            ws.send(JSON.stringify({ type: "error", message: "\u0627\u0644\u0637\u0627\u0648\u0644\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629" }));
            return;
          }
          const players = getPlayersAtTable(tableId);
          if (players.length < 2) {
            ws.send(JSON.stringify({
              type: "error",
              message: "\u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0647\u0646\u0627\u0643 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644 \u0644\u0627\u0639\u0628\u064A\u0646 \u0644\u0628\u062F\u0621 \u062C\u0648\u0644\u0629"
            }));
            return;
          }
          try {
            const result = table.gameManager.startNewRound ? table.gameManager.startNewRound() : { success: true };
            if (!result.success) {
              ws.send(JSON.stringify({
                type: "error",
                message: result.message || "\u0641\u0634\u0644 \u0628\u062F\u0621 \u0627\u0644\u062C\u0648\u0644\u0629"
              }));
              return;
            }
            table.status = "active" /* ACTIVE */;
            const gameState = table.gameManager.getState ? table.gameManager.getState() : await storage.getGameState(tableId, userId);
            broadcastToTable(tableId, {
              type: "game_state" /* GAME_STATE */,
              gameState
            });
            broadcastToTable(tableId, {
              type: "table_update" /* TABLE_UPDATE */,
              tableInfo: getTableInfo(table)
            });
          } catch (error) {
            console.error(`\u062E\u0637\u0623 \u0641\u064A \u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629 \u0641\u064A \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId}:`, error);
            ws.send(JSON.stringify({
              type: "error",
              message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0628\u062F\u0621 \u0627\u0644\u062C\u0648\u0644\u0629"
            }));
          }
        } else if (data.type === "reveal_cards" /* REVEAL_CARDS */) {
          if (!userId) {
            ws.send(JSON.stringify({ type: "error", message: "\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0635\u0631\u062D \u0628\u0647" }));
            return;
          }
          const tableId = userTables.get(userId);
          if (!tableId) {
            ws.send(JSON.stringify({ type: "error", message: "\u0623\u0646\u062A \u0644\u0633\u062A \u0641\u064A \u0637\u0627\u0648\u0644\u0629" }));
            return;
          }
          const table = pokerModule.tables.get(tableId);
          if (!table) {
            ws.send(JSON.stringify({ type: "error", message: "\u0627\u0644\u0637\u0627\u0648\u0644\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629" }));
            return;
          }
          try {
            table.status = "showdown" /* SHOWDOWN */;
            const gameState = table.gameManager.getState ? table.gameManager.getState() : await storage.getGameState(tableId, userId);
            broadcastToTable(tableId, {
              type: "reveal_cards" /* REVEAL_CARDS */,
              gameState
            });
            broadcastToTable(tableId, {
              type: "table_update" /* TABLE_UPDATE */,
              tableInfo: getTableInfo(table)
            });
          } catch (error) {
            console.error(`\u062E\u0637\u0623 \u0641\u064A \u0643\u0634\u0641 \u0627\u0644\u0623\u0648\u0631\u0627\u0642 \u0641\u064A \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId}:`, error);
            ws.send(JSON.stringify({
              type: "error",
              message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0643\u0634\u0641 \u0627\u0644\u0623\u0648\u0631\u0627\u0642"
            }));
          }
        } else if (data.type === "join_table") {
          if (!userId) {
            ws.send(JSON.stringify({ type: "error", message: "\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0635\u0631\u062D \u0628\u0647" }));
            return;
          }
          const tableId = data.tableId;
          userTables.set(userId, tableId);
          if (clients.has(userId)) {
            const clientInfo = clients.get(userId);
            if (clientInfo) {
              clientInfo.tableId = tableId;
            }
          }
          const safeTableId = Number(tableId);
          if (!isNaN(safeTableId)) {
            broadcastToTable(safeTableId, {
              type: "player_joined",
              userId,
              tableId: safeTableId
            }, userId);
          }
          const gameState = await storage.getGameState(tableId, userId);
          ws.send(JSON.stringify({
            type: "game_state",
            gameState
          }));
        } else if (data.type === "join_room" /* JOIN_ROOM */) {
          if (!userId) {
            ws.send(JSON.stringify({ type: "error", message: "\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0635\u0631\u062D \u0628\u0647" }));
            return;
          }
          const roomId = data.roomId;
          const safeRoomId = Number(roomId);
          if (!roomId || isNaN(safeRoomId)) {
            ws.send(JSON.stringify({ type: "error", message: "\u0645\u0639\u0631\u0641 \u0627\u0644\u063A\u0631\u0641\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D" }));
            return;
          }
          const room = pokerModule.rooms.get(safeRoomId);
          if (!room) {
            ws.send(JSON.stringify({ type: "error", message: "\u0627\u0644\u063A\u0631\u0641\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629" }));
            return;
          }
          pokerModule.userRooms.set(userId, safeRoomId);
          ws.send(JSON.stringify({
            type: "room_update" /* ROOM_UPDATE */,
            roomInfo: getRoomInfo(room)
          }));
          const tables = [];
          room.tables.forEach((table) => {
            tables.push(getTableInfo(table));
          });
          ws.send(JSON.stringify({
            type: "tables_list" /* TABLES_LIST */,
            roomId: safeRoomId,
            tables
          }));
          console.log(`\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u0627\u0646\u0636\u0645 \u0644\u0644\u063A\u0631\u0641\u0629 ${safeRoomId}`);
        } else if (data.type === "leave_room" /* LEAVE_ROOM */) {
          if (!userId) {
            ws.send(JSON.stringify({ type: "error", message: "\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0635\u0631\u062D \u0628\u0647" }));
            return;
          }
          const roomId = pokerModule.userRooms.get(userId);
          if (roomId) {
            pokerModule.userRooms.delete(userId);
            const tableId = userTables.get(userId);
            const table = tableId ? pokerModule.tables.get(tableId) : null;
            if (table && table.roomId === roomId) {
              userTables.delete(userId);
              if (clients.has(userId)) {
                const clientInfo = clients.get(userId);
                if (clientInfo) {
                  clientInfo.tableId = void 0;
                }
              }
              if (table.players.has(userId)) {
                table.players.delete(userId);
              }
              broadcastToTable(tableId, {
                type: "player_left" /* PLAYER_LEFT */,
                userId,
                tableId
              }, userId);
              if (table.status !== "waiting" /* WAITING */ && table.players.size < 2) {
                table.status = "waiting" /* WAITING */;
                broadcastToTable(tableId, {
                  type: "table_update" /* TABLE_UPDATE */,
                  tableInfo: getTableInfo(table)
                });
              }
            }
            console.log(`\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u063A\u0627\u062F\u0631 \u0627\u0644\u063A\u0631\u0641\u0629 ${roomId}`);
          }
          const rooms = [];
          pokerModule.rooms.forEach((room) => {
            rooms.push(getRoomInfo(room));
          });
          ws.send(JSON.stringify({
            type: "rooms_list" /* ROOMS_LIST */,
            rooms
          }));
        } else if (data.type === "leave_table") {
          if (!userId) {
            ws.send(JSON.stringify({ type: "error", message: "\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0635\u0631\u062D \u0628\u0647" }));
            return;
          }
          const tableId = userTables.get(userId);
          if (tableId) {
            userTables.delete(userId);
            if (clients.has(userId)) {
              const clientInfo = clients.get(userId);
              if (clientInfo) {
                clientInfo.tableId = void 0;
              }
            }
            const safeLeaveTableId = Number(tableId);
            if (!isNaN(safeLeaveTableId)) {
              broadcastToTable(safeLeaveTableId, {
                type: "player_left",
                userId,
                tableId: safeLeaveTableId
              }, userId);
            }
          }
        } else if (data.type === "game_action") {
          if (!userId) {
            ws.send(JSON.stringify({ type: "error", message: "\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0635\u0631\u062D \u0628\u0647" }));
            return;
          }
          if (data.action === "slot_bet" || data.action === "slot_win" || data.action === "bonus_win") {
            try {
              const user = await storage.getUser(userId);
              if (!user) {
                ws.send(JSON.stringify({ type: "error", message: "\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F" }));
                return;
              }
              if (data.action === "slot_bet") {
                const betAmount = data.amount || 1e4;
                if (user.chips < betAmount) {
                  ws.send(JSON.stringify({
                    type: "error",
                    message: "\u0631\u0635\u064A\u062F \u063A\u064A\u0631 \u0643\u0627\u0641 \u0644\u0644\u0645\u0631\u0627\u0647\u0646\u0629"
                  }));
                  return;
                }
                const newChips = user.chips - betAmount;
                const updatedUser = await storage.updateUserChips(userId, newChips);
                ws.send(JSON.stringify({
                  type: "chips_update",
                  chips: newChips,
                  change: -betAmount,
                  action: "slot_bet",
                  game: data.data?.game || "egypt-queen"
                }));
                console.log(`\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u064A\u0631\u0627\u0647\u0646 \u0628\u0645\u0628\u0644\u063A ${betAmount} \u0641\u064A \u0644\u0639\u0628\u0629 ${data.data?.game || "egypt-queen"}`);
              } else if (data.action === "slot_win" || data.action === "bonus_win") {
                const winAmount = data.amount || 0;
                if (winAmount <= 0) {
                  return;
                }
                const newChips = user.chips + winAmount;
                const updatedUser = await storage.updateUserChips(userId, newChips);
                ws.send(JSON.stringify({
                  type: "chips_update",
                  chips: newChips,
                  change: winAmount,
                  action: data.action,
                  game: data.data?.game || "egypt-queen"
                }));
                console.log(`\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u064A\u0641\u0648\u0632 \u0628\u0645\u0628\u0644\u063A ${winAmount} \u0641\u064A \u0644\u0639\u0628\u0629 ${data.data?.game || "egypt-queen"}`);
              }
              return;
            } catch (error) {
              console.error("\u062E\u0637\u0623 \u0641\u064A \u0645\u0639\u0627\u0644\u062C\u0629 \u0625\u062C\u0631\u0627\u0621 \u0627\u0644\u0644\u0639\u0628\u0629:", error);
              ws.send(JSON.stringify({
                type: "error",
                message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0645\u0639\u0627\u0644\u062C\u0629 \u0625\u062C\u0631\u0627\u0621 \u0627\u0644\u0644\u0639\u0628\u0629"
              }));
              return;
            }
          }
          const tableId = userTables.get(userId);
          if (!tableId) {
            ws.send(JSON.stringify({ type: "error", message: "\u0623\u0646\u062A \u0644\u0633\u062A \u0641\u064A \u0637\u0627\u0648\u0644\u0629" }));
            return;
          }
          const pokerTable = pokerModule.tables.get(tableId);
          if (!pokerTable) {
            ws.send(JSON.stringify({ type: "error", message: "\u0627\u0644\u0637\u0627\u0648\u0644\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629" }));
            return;
          }
          try {
            const action = data.action;
            const amount = data.amount;
            const result = pokerTable.gameManager.performAction(userId, action, amount);
            ws.send(JSON.stringify({
              type: "action_result",
              success: result.success,
              message: result.message,
              action
            }));
            if (!result.success) {
              return;
            }
            const gameState = pokerTable.gameManager.getGameState();
            broadcastToTable(tableId, {
              type: "game_state",
              gameState
            });
            if (result.roundComplete && result.winners) {
              broadcastToTable(tableId, {
                type: "round_complete",
                winners: result.winners
              });
            }
          } catch (error) {
            console.error(`\u062E\u0637\u0623 \u0641\u064A \u062A\u0646\u0641\u064A\u0630 \u0625\u062C\u0631\u0627\u0621 \u0627\u0644\u0644\u0627\u0639\u0628 ${userId} \u0641\u064A \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId}:`, error);
            ws.send(JSON.stringify({
              type: "error",
              message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062A\u0646\u0641\u064A\u0630 \u0627\u0644\u0625\u062C\u0631\u0627\u0621"
            }));
          }
        }
      } catch (error) {
        console.error("WebSocket message error:", error);
        ws.send(JSON.stringify({
          type: "error",
          message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0645\u0639\u0627\u0644\u062C\u0629 \u0627\u0644\u0631\u0633\u0627\u0644\u0629"
        }));
      }
    });
    ws.on("close", (code, reason) => {
      console.log(`\u0625\u063A\u0644\u0627\u0642 \u0627\u062A\u0635\u0627\u0644 WebSocket \u0644\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId || "\u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641"} (\u0643\u0648\u062F: ${code}, \u0633\u0628\u0628: ${reason || "\u063A\u064A\u0631 \u0645\u062D\u062F\u062F"})`);
      if (userId) {
        const now = Date.now();
        const userTableId = userTables.get(userId);
        if (userTableId) {
          lastKnownUserStates.set(userId, {
            tableId: userTableId,
            lastActivity: now
          });
          const isCleanClose = code === 1e3 || code === 1001;
          if (isCleanClose) {
            const safeTableId = Number(userTableId);
            if (!isNaN(safeTableId)) {
              broadcastToTable(safeTableId, {
                type: "player_left",
                userId,
                tableId: safeTableId,
                reason: "\u062E\u0631\u0648\u062C \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645"
              }, userId);
            }
            userTables.delete(userId);
            clients.delete(userId);
            console.log(`\u062A\u0645 \u062D\u0630\u0641 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u0628\u0639\u062F \u062A\u0633\u062C\u064A\u0644 \u062E\u0631\u0648\u062C \u0645\u0646\u062A\u0638\u0645`);
          } else {
            console.log(`\u0642\u0637\u0639 \u0627\u062A\u0635\u0627\u0644 \u063A\u064A\u0631 \u0646\u0638\u064A\u0641 \u0644\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} - \u0627\u0644\u062D\u0641\u0627\u0638 \u0639\u0644\u0649 \u062D\u0627\u0644\u0629 \u0627\u0644\u0627\u062A\u0635\u0627\u0644`);
          }
        } else {
          clients.delete(userId);
        }
        broadcastOnlineUsers();
      }
    });
  });
}

// server/routes.ts
import { z } from "zod";

// server/db.ts
import { drizzle } from "drizzle-orm/node-postgres";
import { migrate } from "drizzle-orm/node-postgres/migrator";
import pkg from "pg";

// shared/schema.ts
var schema_exports = {};
__export(schema_exports, {
  achievementDefinitions: () => achievementDefinitions,
  achievements: () => achievements,
  badgeCategories: () => badgeCategories,
  badges: () => badges,
  friendships: () => friendships,
  gameHistory: () => gameHistory,
  gameTables: () => gameTables,
  gameTypeEnum: () => gameTypeEnum,
  insertBadgeSchema: () => insertBadgeSchema,
  insertUserBadgeSchema: () => insertUserBadgeSchema,
  insertUserSchema: () => insertUserSchema,
  items: () => items,
  messages: () => messages,
  missions: () => missions,
  playerStats: () => playerStats,
  powerUpTypeEnum: () => powerUpTypeEnum,
  shopOffers: () => shopOffers,
  tablePlayers: () => tablePlayers,
  tableStatusEnum: () => tableStatusEnum,
  userBadges: () => userBadges,
  userChipsTransactions: () => userChipsTransactions,
  userDiamondsTransactions: () => userDiamondsTransactions,
  userGifts: () => userGifts,
  userItems: () => userItems,
  userMissions: () => userMissions,
  userPurchases: () => userPurchases,
  userRoleEnum: () => userRoleEnum,
  users: () => users
});
import { pgTable, text, serial, integer, boolean, timestamp, pgEnum, real, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
var userRoleEnum = pgEnum("user_role", ["player", "vip", "admin", "moderator", "guest"]);
var gameTypeEnum = pgEnum("game_type", ["poker", "naruto", "domino", "tekken", "arabic_rocket", "zeus_king", "egypt_queen"]);
var tableStatusEnum = pgEnum("table_status", ["available", "full", "in_progress", "maintenance"]);
var users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").unique(),
  chips: integer("chips").default(5e3).notNull(),
  diamonds: integer("diamonds").default(0).notNull(),
  vipLevel: integer("vip_level").default(0).notNull(),
  vipPoints: integer("vip_points").default(0).notNull(),
  role: userRoleEnum("role").default("player").notNull(),
  avatar: text("avatar"),
  coverPhoto: text("cover_photo"),
  userCode: text("user_code").notNull().unique(),
  // معرف المستخدم المكون من 5 أرقام، فريد لكل مستخدم
  totalDeposits: integer("total_deposits").default(0),
  isVerified: boolean("is_verified").default(false),
  lastLogin: timestamp("last_login"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  facebookId: text("facebook_id"),
  isGuest: boolean("is_guest").default(false),
  authType: text("auth_type"),
  // نوع المصادقة (email، facebook، guest)
  preferences: jsonb("preferences"),
  // إعدادات المستخدم وتفضيلاته
  status: text("status").default("online"),
  // حالة المستخدم (متصل، غير متصل، في لعبة)
  bio: text("bio"),
  // نبذة تعريفية
  phone: text("phone")
  // رقم الهاتف
});
var insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  chips: true,
  diamonds: true,
  isGuest: true,
  role: true,
  userCode: true,
  // إضافة حقل userCode للتأكد من إدخاله عند التسجيل
  authType: true
  // إضافة حقل authType لتحديد نوع المستخدم (guest/facebook/email)
});
var userChipsTransactions = pgTable("user_chips_transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  amount: integer("amount").notNull(),
  // مبلغ المعاملة (سالب للسحب، موجب للإيداع)
  balanceAfter: integer("balance_after").notNull(),
  // الرصيد بعد المعاملة
  type: text("type").notNull(),
  // نوع المعاملة (شراء، ربح، خسارة، هدية، إلخ)
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  gameId: integer("game_id"),
  // مرجع إلى اللعبة إذا كانت المعاملة متعلقة بلعبة
  tableId: integer("table_id"),
  // مرجع إلى الطاولة
  sourceUserId: integer("source_user_id"),
  // المستخدم المصدر (في حالة التحويل)
  reference: text("reference")
  // مرجع للمعاملة (رقم عملية الشراء، رقم اللعبة، إلخ)
});
var userDiamondsTransactions = pgTable("user_diamonds_transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  amount: integer("amount").notNull(),
  balanceAfter: integer("balance_after").notNull(),
  type: text("type").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  reference: text("reference")
});
var items = pgTable("items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  type: text("type").notNull(),
  // نوع العنصر (avatar, gift, vip_item, etc)
  price: integer("price"),
  // السعر بالرقائق
  diamondPrice: integer("diamond_price"),
  // السعر بالماس
  imageUrl: text("image_url"),
  isActive: boolean("is_active").default(true),
  requiredVipLevel: integer("required_vip_level").default(0),
  category: text("category"),
  expiresInDays: integer("expires_in_days"),
  // عدد الأيام للانتهاء (0 للعناصر الدائمة)
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var userItems = pgTable("user_items", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  itemId: integer("item_id").notNull().references(() => items.id),
  acquiredAt: timestamp("acquired_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at"),
  isEquipped: boolean("is_equipped").default(false),
  // هل العنصر مجهز (مثل الصورة الرمزية)
  quantity: integer("quantity").default(1).notNull()
  // كمية العنصر (لو يمكن وجود أكثر من واحد)
});
var userGifts = pgTable("user_gifts", {
  id: serial("id").primaryKey(),
  fromUserId: integer("from_user_id").notNull().references(() => users.id),
  toUserId: integer("to_user_id").notNull().references(() => users.id),
  itemId: integer("item_id").notNull().references(() => items.id),
  message: text("message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  isOpened: boolean("is_opened").default(false)
});
var friendships = pgTable("friendships", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  friendId: integer("friend_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  status: text("status").default("pending").notNull(),
  // pending, accepted, blocked
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});
var messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  recipientId: integer("recipient_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  isRead: boolean("is_read").default(false),
  replyToId: integer("reply_to_id")
  // مرجع للرسالة التي يرد عليها
});
var gameTables = pgTable("game_tables", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  gameType: gameTypeEnum("game_type").notNull().default("poker"),
  smallBlind: integer("small_blind").notNull(),
  bigBlind: integer("big_blind").notNull(),
  minBuyIn: integer("min_buy_in").notNull(),
  maxBuyIn: integer("max_buy_in"),
  maxPlayers: integer("max_players").notNull().default(9),
  currentPlayers: integer("current_players").notNull().default(0),
  status: tableStatusEnum("status").notNull().default("available"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  tableImage: text("table_image"),
  isVip: boolean("is_vip").default(false),
  requiredVipLevel: integer("required_vip_level").default(0),
  password: text("password"),
  // كلمة مرور للطاولات الخاصة
  ownerId: integer("owner_id"),
  // صاحب الطاولة (للطاولات الخاصة)
  tableSettings: jsonb("table_settings")
  // إعدادات إضافية للطاولة
});
var gameHistory = pgTable("game_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  tableId: integer("table_id").notNull().references(() => gameTables.id),
  gameType: gameTypeEnum("game_type").notNull(),
  startedAt: timestamp("started_at").defaultNow().notNull(),
  endedAt: timestamp("ended_at"),
  result: text("result").notNull(),
  // win, loss, draw
  chipsChange: integer("chips_change").notNull(),
  finalPosition: integer("final_position"),
  // المركز النهائي للاعب
  handDetails: jsonb("hand_details"),
  // تفاصيل اليد للاعب (حسب نوع اللعبة)
  opponentIds: integer("opponent_ids").array()
  // قائمة معرفات المنافسين
});
var tablePlayers = pgTable("table_players", {
  id: serial("id").primaryKey(),
  tableId: integer("table_id").notNull().references(() => gameTables.id, { onDelete: "cascade" }),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  position: integer("position").notNull(),
  // موضع اللاعب على الطاولة
  currentChips: integer("current_chips").notNull(),
  // الرقائق الحالية في اللعبة
  isActive: boolean("is_active").default(true),
  // هل اللاعب نشط أم خارج حالياً
  joinedAt: timestamp("joined_at").defaultNow().notNull(),
  lastAction: text("last_action"),
  // آخر حركة قام بها
  lastActionTime: timestamp("last_action_time")
});
var achievementDefinitions = pgTable("achievement_definitions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
  rewardChips: integer("reward_chips").default(0),
  rewardDiamonds: integer("reward_diamonds").default(0),
  rewardItemId: integer("reward_item_id"),
  // مكافأة عنصر خاص
  category: text("category").notNull(),
  // تصنيف الإنجاز
  difficultyLevel: integer("difficulty_level").default(1).notNull(),
  // مستوى صعوبة الإنجاز
  requirements: jsonb("requirements").notNull()
  // متطلبات تحقيق الإنجاز بتنسيق JSON
});
var achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  achievementId: integer("achievement_id").notNull().references(() => achievementDefinitions.id),
  progress: integer("progress").default(0).notNull(),
  // نسبة الإكمال (0-100)
  unlocked: boolean("unlocked").notNull().default(false),
  unlockedDate: timestamp("unlocked_date"),
  rewardClaimed: boolean("reward_claimed").default(false)
});
var playerStats = pgTable("player_stats", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }).unique(),
  gamesPlayed: integer("games_played").notNull().default(0),
  wins: integer("wins").notNull().default(0),
  losses: integer("losses").notNull().default(0),
  draws: integer("draws").notNull().default(0),
  highestWin: integer("highest_win").notNull().default(0),
  biggestPot: integer("biggest_pot").notNull().default(0),
  winRate: real("win_rate").notNull().default(0),
  // نسبة الفوز من 0 إلى 1
  joinDate: timestamp("join_date").notNull().defaultNow(),
  totalPlayTime: integer("total_play_time").default(0),
  // الوقت الإجمالي باللعب بالدقائق
  // إحصائيات خاصة بالبوكر
  handsPlayed: integer("hands_played").default(0),
  flopsSeen: integer("flops_seen").default(0),
  turnsReached: integer("turns_reached").default(0),
  riverReached: integer("river_reached").default(0),
  showdownsReached: integer("showdowns_reached").default(0),
  royalFlushes: integer("royal_flushes").default(0),
  straightFlushes: integer("straight_flushes").default(0),
  fourOfAKind: integer("four_of_a_kind").default(0),
  fullHouses: integer("full_houses").default(0),
  flushes: integer("flushes").default(0),
  straights: integer("straights").default(0),
  threeOfAKind: integer("three_of_a_kind").default(0),
  twoPairs: integer("two_pairs").default(0),
  onePairs: integer("one_pairs").default(0),
  // إحصائيات إضافية
  totalBets: integer("total_bets").default(0),
  totalRaises: integer("total_raises").default(0),
  totalCalls: integer("total_calls").default(0),
  totalFolds: integer("total_folds").default(0),
  totalChecks: integer("total_checks").default(0),
  totalAllIns: integer("total_all_ins").default(0)
});
var missions = pgTable("missions", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  rewardChips: integer("reward_chips").default(0),
  rewardDiamonds: integer("reward_diamonds").default(0),
  rewardVipPoints: integer("reward_vip_points").default(0),
  type: text("type").notNull(),
  // يومي، أسبوعي، خاص، إلخ
  requirementType: text("requirement_type").notNull(),
  // نوع المهمة (عدد الألعاب، الفوز، إلخ)
  targetValue: integer("target_value").notNull(),
  // القيمة المطلوبة للإكمال
  isActive: boolean("is_active").default(true),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  gameType: gameTypeEnum("game_type")
  // نوع اللعبة المتعلقة بالمهمة
});
var userMissions = pgTable("user_missions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  missionId: integer("mission_id").notNull().references(() => missions.id),
  currentProgress: integer("current_progress").default(0).notNull(),
  completed: boolean("completed").default(false),
  completedAt: timestamp("completed_at"),
  rewardClaimed: boolean("reward_claimed").default(false),
  assignedAt: timestamp("assigned_at").defaultNow().notNull()
});
var shopOffers = pgTable("shop_offers", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  imageUrl: text("image_url"),
  price: real("price").notNull(),
  // السعر بالعملة الحقيقية
  chipsAmount: integer("chips_amount").default(0),
  diamondsAmount: integer("diamonds_amount").default(0),
  itemIds: integer("item_ids").array(),
  // قائمة معرفات العناصر المتضمنة
  discountPercentage: integer("discount_percentage").default(0),
  isActive: boolean("is_active").default(true),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  isVipOnly: boolean("is_vip_only").default(false),
  requiredVipLevel: integer("required_vip_level").default(0)
});
var userPurchases = pgTable("user_purchases", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  offerId: integer("offer_id").references(() => shopOffers.id),
  amount: real("amount").notNull(),
  // المبلغ المدفوع
  currency: text("currency").notNull(),
  // عملة الدفع
  status: text("status").notNull(),
  // تم، معلق، ملغي، إلخ
  paymentMethod: text("payment_method").notNull(),
  transactionId: text("transaction_id"),
  purchaseDate: timestamp("purchase_date").defaultNow().notNull(),
  itemsPurchased: jsonb("items_purchased")
  // تفاصيل العناصر المشتراة
});
var badgeCategories = pgTable("badge_categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  icon: text("icon"),
  // رمز الفئة
  sortOrder: integer("sort_order").default(0)
  // ترتيب العرض
});
var badges = pgTable("badges", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description").notNull(),
  imageUrl: text("image_url").notNull(),
  categoryId: integer("category_id").references(() => badgeCategories.id),
  isRare: boolean("is_rare").default(false),
  // هل الشارة نادرة
  isHidden: boolean("is_hidden").default(false),
  // هل الشارة مخفية حتى يتم اكتسابها
  createdAt: timestamp("created_at").defaultNow().notNull(),
  requiredVipLevel: integer("required_vip_level").default(0),
  // مستوى VIP المطلوب
  rarityLevel: integer("rarity_level").default(1),
  // مستوى ندرة الشارة (1-5)
  sortOrder: integer("sort_order").default(0),
  // ترتيب العرض
  grantCriteria: jsonb("grant_criteria"),
  // معايير منح الشارة
  color: text("color").default("#D4AF37"),
  // لون الشارة الافتراضي ذهبي
  glowColor: text("glow_color"),
  // لون توهج الشارة
  effects: jsonb("effects")
  // تأثيرات خاصة للشارة (مثل توهج، حركة، إلخ)
});
var userBadges = pgTable("user_badges", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  badgeId: integer("badge_id").notNull().references(() => badges.id),
  acquiredAt: timestamp("acquired_at").defaultNow().notNull(),
  isEquipped: boolean("is_equipped").default(false),
  // هل الشارة مجهزة (معروضة في الملف الشخصي)
  equippedPosition: integer("equipped_position"),
  // موضع العرض في الملف الشخصي
  displayProgress: integer("display_progress"),
  // تقدم العرض (0-100 للشارات التراكمية)
  source: text("source"),
  // مصدر الحصول على الشارة (إنجاز، هدية، مناسبة، شراء...)
  favoriteOrder: integer("favorite_order"),
  // ترتيب المفضلة
  metadata: jsonb("metadata")
  // بيانات إضافية عن الشارة
});
var insertBadgeSchema = createInsertSchema(badges).omit({
  id: true,
  createdAt: true
});
var insertUserBadgeSchema = createInsertSchema(userBadges).omit({
  id: true,
  acquiredAt: true
});
var powerUpTypeEnum = pgEnum("power_up_type", ["speed_boost", "shield", "slow_down", "teleport", "invisibility", "double_coins", "magnet"]);

// server/vite.ts
import express from "express";
import fs2 from "fs";
import path3, { dirname as dirname2 } from "path";
import { fileURLToPath as fileURLToPath2 } from "url";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import themePlugin from "@replit/vite-plugin-shadcn-theme-json";
import path2, { dirname } from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
import { fileURLToPath } from "url";
var __filename = fileURLToPath(import.meta.url);
var __dirname = dirname(__filename);
var vite_config_default = defineConfig({
  plugins: [
    react(),
    runtimeErrorOverlay(),
    themePlugin(),
    ...process.env.NODE_ENV !== "production" && process.env.REPL_ID !== void 0 ? [
      await import("@replit/vite-plugin-cartographer").then(
        (m) => m.cartographer()
      )
    ] : []
  ],
  resolve: {
    alias: {
      "@": path2.resolve(__dirname, "client", "src"),
      "@shared": path2.resolve(__dirname, "shared"),
      "@assets": path2.resolve(__dirname, "attached_assets")
    }
  },
  root: path2.resolve(__dirname, "client"),
  build: {
    outDir: path2.resolve(__dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    host: true,
    port: 8100,
    allowedHosts: [".replit.dev"]
  }
});

// server/vite.ts
import { nanoid } from "nanoid";
var __filename2 = fileURLToPath2(import.meta.url);
var __dirname2 = dirname2(__filename2);
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path3.resolve(
        __dirname2,
        "..",
        "client",
        "index.html"
      );
      let template = await fs2.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path3.resolve(__dirname2, "public");
  if (!fs2.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path3.resolve(distPath, "index.html"));
  });
}

// server/db.ts
var { Pool } = pkg;
if (!process.env.DATABASE_URL) {
  console.warn("DATABASE_URL environment variable is not set. Using in-memory storage instead.");
}
var pool = process.env.DATABASE_URL ? new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 20,
  // زيادة الحد الأقصى لعدد الاتصالات المتزامنة
  idleTimeoutMillis: 6e4,
  // زيادة وقت انتهاء الاتصال الخامل لتقليل عمليات إعادة الاتصال
  connectionTimeoutMillis: 1e4,
  // زيادة مهلة الاتصال لتحسين الموثوقية
  allowExitOnIdle: false,
  // منع إغلاق الاتصالات عند الخمول لتحسين الأداء
  keepAlive: true,
  // إبقاء الاتصال حياً
  keepAliveInitialDelayMillis: 1e4
  // تأخير أولي لإرسال حزم keep-alive
}) : null;
if (pool) {
  pool.on("error", (err) => {
    log(`Unexpected error on idle client: ${err.message}`, "database");
    process.exit(-1);
  });
}
var db = pool ? drizzle(pool, { schema: schema_exports }) : null;
async function initializeDatabase(maxRetries = 5, retryDelay = 2e3) {
  if (!pool) {
    log("No database connection pool available. Using in-memory storage.", "database");
    return true;
  }
  let retryCount = 0;
  while (retryCount < maxRetries) {
    try {
      log(`Connecting to database (attempt ${retryCount + 1}/${maxRetries})...`, "database");
      const client = await pool.connect();
      const result = await client.query("SELECT NOW()");
      if (!result || !result.rows || result.rows.length === 0) {
        throw new Error("Database connection validation failed");
      }
      client.release();
      log("Database connection successful and validated", "database");
      if (db) {
        log("Running migrations...", "database");
        await migrate(db, { migrationsFolder: "./migrations" });
        log("Migrations completed successfully", "database");
        await pool.query("SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE state = 'idle' AND state_change < NOW() - INTERVAL '1 hour'");
        log("Cleaned up idle connections", "database");
      }
      return true;
    } catch (error) {
      retryCount++;
      log(`Database initialization error (attempt ${retryCount}/${maxRetries}): ${error.message || "Unknown error"}`, "database");
      if (retryCount < maxRetries) {
        log(`Retrying database initialization in ${retryDelay}ms...`, "database");
        await new Promise((resolve) => setTimeout(resolve, retryDelay));
        retryDelay = Math.min(retryDelay * 1.5, 3e4);
      } else {
        log("Maximum retries reached. Database initialization failed.", "database");
        console.error("Full error:", error);
        return false;
      }
    }
  }
  return false;
}
async function closeDatabase(maxRetries = 3, retryDelay = 1e3) {
  if (!pool) {
    log("No database connection pool to close.", "database");
    return true;
  }
  let retryCount = 0;
  while (retryCount < maxRetries) {
    try {
      log("Closing database connections...", "database");
      await pool.end();
      log("Database connections closed successfully", "database");
      return true;
    } catch (error) {
      retryCount++;
      log(`Error closing database connections (attempt ${retryCount}/${maxRetries}): ${error.message || "Unknown error"}`, "database");
      if (retryCount < maxRetries) {
        log(`Retrying database connection close in ${retryDelay}ms...`, "database");
        await new Promise((resolve) => setTimeout(resolve, retryDelay));
      } else {
        log("Maximum retries reached. Database connections may not have closed properly.", "database");
        return false;
      }
    }
  }
  return false;
}

// server/services/user-service.ts
import { eq } from "drizzle-orm";
var UserService = class {
  /**
   * الحصول على مستخدم حسب المعرف
   */
  async getUserById(id) {
    try {
      const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
      return result.length > 0 ? result[0] : void 0;
    } catch (error) {
      log(`Error fetching user by ID: ${error.message}`, "database");
      throw error;
    }
  }
  /**
   * الحصول على مستخدم حسب اسم المستخدم
   */
  async getUserByUsername(username) {
    try {
      const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
      return result.length > 0 ? result[0] : void 0;
    } catch (error) {
      log(`Error fetching user by username: ${error.message}`, "database");
      throw error;
    }
  }
  /**
   * الحصول على مستخدم حسب الرمز الفريد
   */
  async getUserByCode(userCode) {
    try {
      const result = await db.select().from(users).where(eq(users.userCode, userCode)).limit(1);
      return result.length > 0 ? result[0] : void 0;
    } catch (error) {
      log(`Error fetching user by code: ${error.message}`, "database");
      throw error;
    }
  }
  /**
   * إنشاء مستخدم جديد
   */
  async createUser(userData) {
    try {
      const parsedData = insertUserSchema.parse(userData);
      const hashedPassword = await hashPassword(parsedData.password);
      const userCode = await this.generateUniqueUserCode();
      const result = await db.insert(users).values({
        ...parsedData,
        password: hashedPassword,
        userCode,
        createdAt: /* @__PURE__ */ new Date(),
        updatedAt: /* @__PURE__ */ new Date(),
        lastLogin: /* @__PURE__ */ new Date(),
        diamonds: parsedData.diamonds || 0,
        role: parsedData.role || "player"
      }).returning();
      if (result.length === 0) {
        throw new Error("Failed to create user");
      }
      await this.createInitialPlayerStats(result[0].id);
      return result[0];
    } catch (error) {
      log(`Error creating user: ${error.message}`, "database");
      throw error;
    }
  }
  /**
   * إنشاء إحصائيات أولية للاعب
   */
  async createInitialPlayerStats(userId) {
    try {
      await db.insert(playerStats).values({
        userId,
        joinDate: /* @__PURE__ */ new Date()
      });
    } catch (error) {
      log(`Error creating initial player stats: ${error.message}`, "database");
      throw error;
    }
  }
  /**
   * تحديث رصيد الرقائق للمستخدم
   */
  async updateUserChips(userId, newChips, type, description) {
    try {
      const user = await this.getUserById(userId);
      if (!user) {
        throw new Error("User not found");
      }
      const chipsChange = newChips - user.chips;
      const updatedUsers = await db.update(users).set({
        chips: newChips,
        updatedAt: /* @__PURE__ */ new Date()
      }).where(eq(users.id, userId)).returning();
      if (updatedUsers.length === 0) {
        throw new Error("Failed to update user chips");
      }
      await db.insert(userChipsTransactions).values({
        userId,
        amount: chipsChange,
        balanceAfter: newChips,
        type,
        description,
        createdAt: /* @__PURE__ */ new Date()
      });
      return updatedUsers[0];
    } catch (error) {
      log(`Error updating user chips: ${error.message}`, "database");
      throw error;
    }
  }
  /**
   * توليد رمز فريد للمستخدم (5 أرقام)
   */
  async generateUniqueUserCode() {
    try {
      let attempts = 0;
      const maxAttempts = 10;
      while (attempts < maxAttempts) {
        const code = Math.floor(1e4 + Math.random() * 9e4).toString();
        const existing = await this.getUserByCode(code);
        if (!existing) {
          return code;
        }
        attempts++;
      }
      const timestamp2 = Date.now() % 1e5;
      return timestamp2.toString().padStart(5, "0");
    } catch (error) {
      log(`Error generating unique user code: ${error.message}`, "database");
      throw error;
    }
  }
};
var userService = new UserService();

// server/routes.ts
function ensureAuthenticated(req, res, next) {
  if (req.isAuthenticated() && req.user) {
    req.session.touch();
    return next();
  }
  req.session.destroy((err) => {
    if (err) console.error("Session destruction error:", err);
    res.status(401).json({ message: "\u064A\u062C\u0628 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0644\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u0645\u0648\u0631\u062F" });
  });
}
async function registerRoutes(app2) {
  setupAuth(app2);
  const httpServer = createServer(app2);
  setupPokerGame(app2, httpServer);
  app2.get("/health", (req, res) => {
    res.status(200).json({ status: "up", timestamp: (/* @__PURE__ */ new Date()).toISOString() });
  });
  app2.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
    }
    res.json(req.user);
  });
  app2.get("/api/rankings/top3", async (req, res) => {
    try {
      const allUsers = Array.from(storage.users.values());
      const sortedUsers = allUsers.filter((user) => user.chips > 0).sort((a, b) => b.chips - a.chips);
      const topPlayers = sortedUsers.slice(0, 3).map((user) => ({
        id: user.id,
        username: user.username,
        chips: user.chips,
        avatar: user.avatar || null
      }));
      res.json(topPlayers);
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u0627\u0644\u062D\u0635\u0648\u0644 \u0639\u0644\u0649 \u0623\u0641\u0636\u0644 3 \u0644\u0627\u0639\u0628\u064A\u0646:", error);
      res.status(500).json({ error: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062C\u0644\u0628 \u0623\u0641\u0636\u0644 3 \u0644\u0627\u0639\u0628\u064A\u0646" });
    }
  });
  app2.get("/api/rankings/top100", async (req, res) => {
    try {
      const allUsers = Array.from(storage.users.values());
      const sortedUsers = allUsers.filter((user) => user.chips > 0).sort((a, b) => b.chips - a.chips);
      const topPlayers = sortedUsers.slice(0, 100).map((user) => ({
        id: user.id,
        username: user.username,
        chips: user.chips,
        avatar: user.avatar || null
      }));
      res.json(topPlayers);
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u0627\u0644\u062D\u0635\u0648\u0644 \u0639\u0644\u0649 \u0623\u0641\u0636\u0644 100 \u0644\u0627\u0639\u0628:", error);
      res.status(500).json({ error: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062C\u0644\u0628 \u0623\u0641\u0636\u0644 100 \u0644\u0627\u0639\u0628" });
    }
  });
  app2.get("/api/users/:userId", ensureAuthenticated, async (req, res) => {
    try {
      let user;
      const userIdParam = req.params.userId;
      const userId = parseInt(userIdParam);
      console.log(`\u0627\u0644\u0628\u062D\u062B \u0639\u0646 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645: ${userIdParam} - \u0645\u0639\u0631\u0641 \u0631\u0642\u0645\u064A: ${!isNaN(userId) ? userId : "\u0644\u0627"}`);
      if (!isNaN(userId)) {
        user = await storage.getUser(userId);
        if (!user) {
          const usersWithCode = Array.from(storage.users.values()).filter((u) => u.userCode === userIdParam);
          if (usersWithCode.length > 0) {
            user = usersWithCode[0];
            console.log(`\u062A\u0645 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0628\u0648\u0627\u0633\u0637\u0629 \u0627\u0644\u0631\u0645\u0632: ${userIdParam}`);
          }
        } else {
          console.log(`\u062A\u0645 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0628\u0648\u0627\u0633\u0637\u0629 \u0627\u0644\u0645\u0639\u0631\u0641 \u0627\u0644\u0631\u0642\u0645\u064A: ${userId}`);
        }
      } else {
        user = await storage.getUserByUsername(userIdParam);
        if (!user) {
          const usersWithCode = Array.from(storage.users.values()).filter((u) => u.userCode === userIdParam);
          if (usersWithCode.length > 0) {
            user = usersWithCode[0];
            console.log(`\u062A\u0645 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0628\u0648\u0627\u0633\u0637\u0629 \u0627\u0644\u0631\u0645\u0632: ${userIdParam}`);
          }
        } else {
          console.log(`\u062A\u0645 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0628\u0648\u0627\u0633\u0637\u0629 \u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645: ${userIdParam}`);
        }
      }
      if (!user) {
        return res.status(404).json({ error: "\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F" });
      }
      const safeUser = {
        id: user.id,
        username: user.username,
        avatar: user.avatar,
        userCode: user.userCode
        // إضافة معرف المستخدم المكون من 5 أرقام
      };
      res.json(safeUser);
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u0627\u0644\u0628\u062D\u062B \u0639\u0646 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645:", error);
      res.status(500).json({ error: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u0628\u062D\u062B \u0639\u0646 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645" });
    }
  });
  app2.post("/api/send-chips", ensureAuthenticated, async (req, res) => {
    try {
      const { recipientId, amount } = req.body;
      const senderId = req.user.id;
      if (!recipientId || !amount) {
        return res.status(400).json({ error: "\u064A\u0631\u062C\u0649 \u062A\u0642\u062F\u064A\u0645 \u0645\u0639\u0631\u0641 \u0627\u0644\u0645\u0633\u062A\u0644\u0645 \u0648\u0627\u0644\u0645\u0628\u0644\u063A" });
      }
      const recipientIdNum = parseInt(recipientId);
      const amountNum = parseInt(amount);
      if (isNaN(recipientIdNum) || isNaN(amountNum)) {
        return res.status(400).json({ error: "\u0645\u0639\u0631\u0641 \u0627\u0644\u0645\u0633\u062A\u0644\u0645 \u0623\u0648 \u0627\u0644\u0645\u0628\u0644\u063A \u063A\u064A\u0631 \u0635\u0627\u0644\u062D" });
      }
      if (amountNum <= 0) {
        return res.status(400).json({ error: "\u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0627\u0644\u0645\u0628\u0644\u063A \u0623\u0643\u0628\u0631 \u0645\u0646 \u0635\u0641\u0631" });
      }
      const recipient = await storage.getUser(recipientIdNum);
      if (!recipient) {
        return res.status(404).json({ error: "\u0627\u0644\u0645\u0633\u062A\u0644\u0645 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F" });
      }
      if (senderId === recipientIdNum) {
        return res.status(400).json({ error: "\u0644\u0627 \u064A\u0645\u0643\u0646\u0643 \u0625\u0631\u0633\u0627\u0644 \u0631\u0642\u0627\u0626\u0642 \u0644\u0646\u0641\u0633\u0643" });
      }
      let sender;
      try {
        sender = await userService2.getUserById(senderId);
      } catch (dbError) {
        console.error(`\u062E\u0637\u0623 \u0641\u064A \u0627\u0644\u062D\u0635\u0648\u0644 \u0639\u0644\u0649 \u0627\u0644\u0645\u0631\u0633\u0644 \u0645\u0646 \u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A:`, dbError);
      }
      if (!sender) {
        sender = await storage.getUser(senderId);
        if (!sender) {
          return res.status(404).json({ error: "\u0627\u0644\u0645\u0631\u0633\u0644 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F" });
        }
      }
      if (sender.chips < amountNum) {
        return res.status(400).json({ error: "\u0631\u0635\u064A\u062F \u063A\u064A\u0631 \u0643\u0627\u0641\u064D" });
      }
      let dbSenderUpdated = false;
      try {
        await userService2.updateUserChips(
          senderId,
          sender.chips - amountNum,
          "send_chips",
          `\u0625\u0631\u0633\u0627\u0644 \u0631\u0642\u0627\u0626\u0642 \u0625\u0644\u0649 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${recipient.username}`
        );
        dbSenderUpdated = true;
      } catch (dbError) {
        console.error(`\u062E\u0637\u0623 \u0641\u064A \u062A\u062D\u062F\u064A\u062B \u0631\u0635\u064A\u062F \u0627\u0644\u0645\u0631\u0633\u0644 \u0641\u064A \u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A:`, dbError);
      }
      const updatedSender = await storage.updateUserChips(
        senderId,
        sender.chips - amountNum,
        "send_chips",
        `\u0625\u0631\u0633\u0627\u0644 \u0631\u0642\u0627\u0626\u0642 \u0625\u0644\u0649 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${recipient.username}`
      );
      let dbRecipientUpdated = false;
      try {
        await userService2.updateUserChips(
          recipientIdNum,
          recipient.chips + amountNum,
          "receive_chips",
          `\u0627\u0633\u062A\u0644\u0627\u0645 \u0631\u0642\u0627\u0626\u0642 \u0645\u0646 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${sender.username}`
        );
        dbRecipientUpdated = true;
      } catch (dbError) {
        console.error(`\u062E\u0637\u0623 \u0641\u064A \u062A\u062D\u062F\u064A\u062B \u0631\u0635\u064A\u062F \u0627\u0644\u0645\u0633\u062A\u0644\u0645 \u0641\u064A \u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A:`, dbError);
      }
      const updatedRecipient = await storage.updateUserChips(
        recipientIdNum,
        recipient.chips + amountNum,
        "receive_chips",
        `\u0627\u0633\u062A\u0644\u0627\u0645 \u0631\u0642\u0627\u0626\u0642 \u0645\u0646 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${sender.username}`
      );
      res.json({
        success: true,
        message: "\u062A\u0645 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0631\u0642\u0627\u0626\u0642 \u0628\u0646\u062C\u0627\u062D",
        amount: amountNum,
        sender: { id: sender.id, username: sender.username },
        recipient: { id: recipient.id, username: recipient.username }
      });
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0631\u0642\u0627\u0626\u0642:", error);
      res.status(500).json({ error: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0645\u062D\u0627\u0648\u0644\u0629 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0631\u0642\u0627\u0626\u0642" });
    }
  });
  const userService2 = new UserService();
  app2.post("/api/games/egypt-rocket/update-chips", ensureAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0635\u0631\u062D \u0628\u0647" });
      }
      const { betAmount, winAmount, multiplier, gameResult } = req.body;
      const userId = req.user.id;
      if (typeof betAmount !== "number" || isNaN(betAmount)) {
        return res.status(400).json({ error: "\u0645\u0628\u0644\u063A \u0627\u0644\u0631\u0647\u0627\u0646 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D" });
      }
      if (typeof winAmount !== "number" || isNaN(winAmount)) {
        return res.status(400).json({ error: "\u0645\u0628\u0644\u063A \u0627\u0644\u0641\u0648\u0632 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D" });
      }
      let dbUser;
      try {
        dbUser = await userService2.getUserById(userId);
        if (!dbUser) {
          console.log(`\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F \u0641\u064A \u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A\u060C \u0627\u0644\u0627\u0646\u062A\u0642\u0627\u0644 \u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0645\u0646 \u0627\u0644\u0645\u062E\u0632\u0646 \u0627\u0644\u0645\u0624\u0642\u062A`);
        } else {
          console.log(`\u062A\u0645 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u0641\u064A \u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A\u060C \u0627\u0644\u0631\u0635\u064A\u062F \u0627\u0644\u062D\u0627\u0644\u064A: ${dbUser.chips}`);
        }
      } catch (dbError) {
        console.error(`\u062E\u0637\u0623 \u0641\u064A \u0627\u0644\u062D\u0635\u0648\u0644 \u0639\u0644\u0649 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0645\u0646 \u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A:`, dbError);
      }
      const memUser = await storage.getUser(userId);
      if (!memUser && !dbUser) {
        return res.status(404).json({ error: "\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F" });
      }
      const user = dbUser || memUser;
      const profitLoss = winAmount - betAmount;
      if (!user) {
        return res.status(404).json({ error: "\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F \u0623\u0648 \u0644\u0627 \u064A\u0645\u0643\u0646 \u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u064A\u0647" });
      }
      const currentChips = user.chips || 0;
      const newChips = currentChips + profitLoss;
      console.log(`\u062A\u062D\u062F\u064A\u062B \u0631\u0635\u064A\u062F \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} - \u0627\u0644\u0642\u062F\u064A\u0645: ${currentChips}, \u0627\u0644\u062C\u062F\u064A\u062F: ${newChips}, \u0627\u0644\u062A\u063A\u064A\u064A\u0631: ${profitLoss}`);
      const updatedUser = await storage.updateUserChips(
        userId,
        newChips,
        profitLoss >= 0 ? "egypt_rocket_win" : "egypt_rocket_loss",
        `${profitLoss >= 0 ? "\u0631\u0628\u062D" : "\u062E\u0633\u0627\u0631\u0629"} \u0641\u064A \u0644\u0639\u0628\u0629 \u0635\u0627\u0631\u0648\u062E \u0645\u0635\u0631 \u0628\u0645\u0636\u0627\u0639\u0641 ${multiplier}x`
      );
      let dbUpdateSuccess = false;
      try {
        if (dbUser) {
          await userService2.updateUserChips(
            userId,
            newChips,
            profitLoss >= 0 ? "egypt_rocket_win" : "egypt_rocket_loss",
            `${profitLoss >= 0 ? "\u0631\u0628\u062D" : "\u062E\u0633\u0627\u0631\u0629"} \u0641\u064A \u0644\u0639\u0628\u0629 \u0635\u0627\u0631\u0648\u062E \u0645\u0635\u0631 \u0628\u0645\u0636\u0627\u0639\u0641 ${multiplier}x`
          );
          console.log(`\u062A\u0645 \u062A\u062D\u062F\u064A\u062B \u0631\u0635\u064A\u062F \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u0641\u064A \u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0628\u0646\u062C\u0627\u062D`);
          dbUpdateSuccess = true;
        } else {
          console.log(`\u062A\u062E\u0637\u064A \u062A\u062D\u062F\u064A\u062B \u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0644\u0623\u0646 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F \u0641\u064A\u0647\u0627`);
        }
      } catch (dbError) {
        console.error(`\u062E\u0637\u0623 \u0641\u064A \u062A\u062D\u062F\u064A\u062B \u0631\u0635\u064A\u062F \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0641\u064A \u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A:`, dbError);
      }
      const updateData = {
        success: true,
        message: profitLoss >= 0 ? "\u062A\u0645 \u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0631\u0635\u064A\u062F \u0628\u0646\u062C\u0627\u062D \u0628\u0639\u062F \u0627\u0644\u0631\u0628\u062D" : "\u062A\u0645 \u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0631\u0635\u064A\u062F \u0628\u0639\u062F \u0627\u0644\u062E\u0633\u0627\u0631\u0629",
        database_updated: dbUpdateSuccess,
        user: {
          id: user.id,
          username: user.username,
          chips: newChips
        },
        gameDetails: {
          betAmount,
          winAmount,
          profitLoss,
          multiplier,
          gameResult
        },
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      };
      const wsResult = await sendRealtimeUpdate(userId, updateData);
      updateData.realtime_update = wsResult.success ? { success: true, message: "\u062A\u0645 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0645\u0628\u0627\u0634\u0631 \u0628\u0646\u062C\u0627\u062D" } : { success: false, message: "\u0644\u0645 \u064A\u062A\u0645 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0645\u0628\u0627\u0634\u0631 (\u063A\u064A\u0631 \u0645\u0647\u0645)" };
      res.json(updateData);
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u062A\u062D\u062F\u064A\u062B \u0631\u0635\u064A\u062F \u0627\u0644\u0644\u0627\u0639\u0628 \u0628\u0639\u062F \u0644\u0639\u0628\u0629 \u0635\u0627\u0631\u0648\u062E \u0645\u0635\u0631:", error);
      res.status(500).json({ error: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0631\u0635\u064A\u062F" });
    }
  });
  async function sendRealtimeUpdate(userId, data) {
    try {
      const message = {
        ...data,
        type: "user_update",
        updateType: "chips_update",
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      };
      console.log(`\u0645\u062D\u0627\u0648\u0644\u0629 \u0625\u0631\u0633\u0627\u0644 \u062A\u062D\u062F\u064A\u062B \u0641\u0648\u0631\u064A \u0644\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u0645\u0628\u0627\u0634\u0631\u0629\u064B \u0639\u0628\u0631 WebSocket...`);
      if (pokerModule.clients) {
        try {
          if (pokerModule.clients.has && pokerModule.clients.has(userId)) {
            const clientInfo = pokerModule.clients.get(userId);
            if (clientInfo && clientInfo.ws && clientInfo.ws.readyState === 1) {
              clientInfo.ws.send(JSON.stringify(message));
              console.log(`\u062A\u0645 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0645\u0628\u0627\u0634\u0631 \u0644\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u0628\u0646\u062C\u0627\u062D \u0639\u0628\u0631 WebSocket \u0627\u0644\u062F\u0627\u062E\u0644\u064A`);
              return { success: true };
            } else {
              console.warn(`\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId} \u0645\u062A\u0635\u0644 \u0648\u0644\u0643\u0646 WebSocket \u063A\u064A\u0631 \u062C\u0627\u0647\u0632 \u0644\u0644\u0625\u0631\u0633\u0627\u0644`);
            }
          }
        } catch (wsError) {
          console.error(`\u062E\u0637\u0623 \u0641\u064A \u0625\u0631\u0633\u0627\u0644 \u0631\u0633\u0627\u0644\u0629 WebSocket \u0644\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId}:`, wsError);
        }
      } else {
        console.warn(`pokerModule.clients \u063A\u064A\u0631 \u0645\u062A\u0627\u062D \u0623\u0648 \u063A\u064A\u0631 \u0645\u0647\u064A\u0623`);
      }
      return {
        success: true,
        // نعود دائمًا بـ "نجاح" حتى لا تتأثر الواجهة
        warning: "\u0627\u0644\u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0641\u0648\u0631\u064A \u063A\u064A\u0631 \u0645\u062A\u0627\u062D \u062D\u0627\u0644\u064A\u0627\u064B",
        realtime: false
      };
    } catch (error) {
      console.error(`\u062E\u0637\u0623 \u063A\u064A\u0631 \u0645\u062A\u0648\u0642\u0639 \u0641\u064A \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0645\u0628\u0627\u0634\u0631 \u0644\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${userId}:`, error);
      return { success: true, error: "\u062E\u0637\u0623 \u063A\u064A\u0631 \u0645\u062A\u0648\u0642\u0639", realtime: false };
    }
  }
  app2.get("/api/profile", ensureAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      const profile = await storage.getPlayerProfile(req.user.id);
      if (!profile) {
        return res.status(404).json({ message: "\u0644\u0645 \u064A\u062A\u0645 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0634\u062E\u0635\u064A" });
      }
      res.json(profile);
    } catch (error) {
      res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062C\u0644\u0628 \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0634\u062E\u0635\u064A" });
    }
  });
  app2.post("/api/profile/username", ensureAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      const { username } = req.body;
      if (!username || username.length < 3) {
        return res.status(400).json({ message: "\u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 3 \u0623\u062D\u0631\u0641 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644" });
      }
      const updatedUser = await storage.updateUser(req.user.id, { username });
      if (req.user) {
        req.user.username = username;
      }
      try {
        await sendRealtimeUpdate(req.user.id, { user: updatedUser });
      } catch (wsError) {
        console.warn(`\u0641\u0634\u0644 \u0641\u064A \u0625\u0631\u0633\u0627\u0644 \u062A\u062D\u062F\u064A\u062B \u0641\u0648\u0631\u064A \u0644\u062A\u063A\u064A\u064A\u0631 \u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${req.user.id}:`, wsError);
      }
      res.json({ success: true, username });
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u062A\u062D\u062F\u064A\u062B \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645:", error);
      res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062A\u062D\u062F\u064A\u062B \u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645" });
    }
  });
  app2.post("/api/profile/avatar", ensureAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      if (!req.files || !req.files.avatar) {
        return res.status(400).json({ message: "\u0644\u0645 \u064A\u062A\u0645 \u062A\u062D\u0645\u064A\u0644 \u0623\u064A \u0635\u0648\u0631\u0629" });
      }
      const avatar = req.files.avatar;
      const avatarUrl = await storage.uploadAvatar(req.user.id, avatar);
      const updatedUser = await storage.updateUser(req.user.id, { avatar: avatarUrl });
      if (req.user) {
        req.user.avatar = avatarUrl;
      }
      try {
        const message = {
          type: "profile_update",
          user_id: req.user.id,
          data: { avatar: avatarUrl },
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        };
        await sendRealtimeUpdate(req.user.id, message);
      } catch (wsError) {
        console.warn("\u062E\u0637\u0623 \u0641\u064A \u0625\u0631\u0633\u0627\u0644 \u062A\u062D\u062F\u064A\u062B WebSocket:", wsError);
      }
      console.log(`\u062A\u0645 \u062D\u0641\u0638 \u0635\u0648\u0631\u0629 \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0634\u062E\u0635\u064A \u0628\u0646\u062C\u0627\u062D \u0641\u064A: ${avatarUrl}`);
      res.json({ success: true, avatarUrl, user: updatedUser });
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u062A\u062D\u062F\u064A\u062B \u0635\u0648\u0631\u0629 \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0634\u062E\u0635\u064A:", error);
      res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0635\u0648\u0631\u0629", error: String(error) });
    }
  });
  app2.post("/api/profile/cover", ensureAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      if (!req.files || !req.files.coverPhoto) {
        return res.status(400).json({ message: "\u0644\u0645 \u064A\u062A\u0645 \u062A\u062D\u0645\u064A\u0644 \u0623\u064A \u0635\u0648\u0631\u0629" });
      }
      const coverPhoto = req.files.coverPhoto;
      const coverPhotoUrl = await storage.uploadCoverPhoto(req.user.id, coverPhoto);
      res.json({ success: true, coverPhotoUrl });
    } catch (error) {
      res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062A\u062D\u062F\u064A\u062B \u0635\u0648\u0631\u0629 \u0627\u0644\u063A\u0644\u0627\u0641" });
    }
  });
  app2.post("/api/profile/update", ensureAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      const userId = req.user.id;
      const updateData = req.body;
      const allowedFields = ["username", "avatar", "chips", "diamonds"];
      const updates = {};
      for (const field of allowedFields) {
        if (field in updateData) {
          updates[field] = updateData[field];
        }
      }
      if (Object.keys(updates).length === 0) {
        return res.status(400).json({ message: "\u0644\u0645 \u064A\u062A\u0645 \u062A\u062D\u062F\u064A\u062F \u0623\u064A \u062D\u0642\u0648\u0644 \u0644\u0644\u062A\u062D\u062F\u064A\u062B" });
      }
      const user = await storage.updateUser(userId, updates);
      if (!user) {
        return res.status(404).json({ message: "\u0644\u0645 \u064A\u062A\u0645 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645" });
      }
      if (req.user) {
        Object.assign(req.user, updates);
      }
      const message = {
        type: "profile_update",
        user_id: userId,
        data: updates,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      };
      try {
        await sendRealtimeUpdate(userId, message);
      } catch (wsError) {
        console.warn("\u062E\u0637\u0623 \u0641\u064A \u0625\u0631\u0633\u0627\u0644 \u062A\u062D\u062F\u064A\u062B WebSocket:", wsError);
      }
      res.json({
        success: true,
        message: "\u062A\u0645 \u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0628\u0646\u062C\u0627\u062D",
        user,
        updatedFields: Object.keys(updates)
      });
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u062A\u062D\u062F\u064A\u062B \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u0645\u0644\u0641 \u0627\u0644\u0634\u062E\u0635\u064A:", error);
      res.status(500).json({ message: "\u062E\u0637\u0623 \u0641\u064A \u0627\u0644\u062E\u0627\u062F\u0645", error: String(error) });
    }
  });
  app2.post("/api/profile/convert", ensureAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      const { username, password } = req.body;
      if (!username || username.length < 3) {
        return res.status(400).json({ message: "\u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 3 \u0623\u062D\u0631\u0641 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644" });
      }
      if (!password || password.length < 6) {
        return res.status(400).json({ message: "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u064A\u062C\u0628 \u0623\u0646 \u062A\u0643\u0648\u0646 6 \u0623\u062D\u0631\u0641 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644" });
      }
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "\u0627\u0633\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u0645\u0633\u062A\u062E\u062F\u0645 \u0628\u0627\u0644\u0641\u0639\u0644" });
      }
      const hashedPassword = await hashPassword(password);
      const updatedUser = await storage.convertGuestToRegistered(req.user.id, username, hashedPassword);
      if (!updatedUser) {
        return res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062A\u062D\u0648\u064A\u0644 \u0627\u0644\u062D\u0633\u0627\u0628" });
      }
      res.json({ success: true, user: updatedUser });
    } catch (error) {
      res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062A\u062D\u0648\u064A\u0644 \u0627\u0644\u062D\u0633\u0627\u0628" });
    }
  });
  app2.get("/api/tables", ensureAuthenticated, async (req, res) => {
    try {
      const tables = await storage.getGameTables();
      res.json(tables);
    } catch (error) {
      res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062C\u0644\u0628 \u0627\u0644\u0637\u0627\u0648\u0644\u0627\u062A" });
    }
  });
  app2.get("/api/tables/:gameType", ensureAuthenticated, async (req, res) => {
    const gameType = req.params.gameType;
    const validGameTypes = ["poker", "naruto", "tekken", "domino", "arab_poker"];
    if (!validGameTypes.includes(gameType)) {
      return res.status(400).json({ message: "\u0646\u0648\u0639 \u0627\u0644\u0644\u0639\u0628\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D" });
    }
    try {
      const tables = await storage.getGameTablesByType(gameType);
      res.json(tables);
    } catch (error) {
      res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062C\u0644\u0628 \u0627\u0644\u0637\u0627\u0648\u0644\u0627\u062A" });
    }
  });
  app2.post("/api/tables/:gameType", ensureAuthenticated, async (req, res) => {
    const gameType = req.params.gameType;
    const validGameTypes = ["poker", "naruto", "tekken", "domino", "arab_poker"];
    if (!validGameTypes.includes(gameType)) {
      return res.status(400).json({ message: "\u0646\u0648\u0639 \u0627\u0644\u0644\u0639\u0628\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D" });
    }
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      const tableSchema = z.object({
        name: z.string().min(3).max(50),
        smallBlind: z.number().min(10),
        maxPlayers: z.number().min(2).max(9),
        minBuyIn: z.number().min(20),
        maxBuyIn: z.number().min(100),
        category: z.string().min(1),
        isPrivate: z.boolean().optional(),
        password: z.string().optional(),
        createdBy: z.number()
      });
      const validatedData = tableSchema.parse(req.body);
      if (validatedData.createdBy !== req.user.id) {
        return res.status(403).json({ message: "\u063A\u064A\u0631 \u0645\u0633\u0645\u0648\u062D \u0628\u0625\u0646\u0634\u0627\u0621 \u0637\u0627\u0648\u0644\u0629 \u0646\u064A\u0627\u0628\u0629 \u0639\u0646 \u0645\u0633\u062A\u062E\u062F\u0645 \u0622\u062E\u0631" });
      }
      console.log(`\u0625\u0646\u0634\u0627\u0621 \u0637\u0627\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629 \u0628\u0648\u0627\u0633\u0637\u0629 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${req.user.id} \u0644\u0646\u0648\u0639 \u0627\u0644\u0644\u0639\u0628\u0629 ${gameType}`);
      const tableData = {
        name: validatedData.name,
        gameType,
        smallBlind: validatedData.smallBlind,
        bigBlind: validatedData.smallBlind * 2,
        // الرهان الكبير ضعف الرهان الصغير
        minBuyIn: validatedData.minBuyIn,
        maxBuyIn: validatedData.maxBuyIn,
        maxPlayers: validatedData.maxPlayers,
        currentPlayers: 0,
        status: "available",
        ownerId: req.user.id,
        isVip: false,
        password: validatedData.isPrivate ? validatedData.password : void 0,
        tableSettings: {
          category: validatedData.category
        }
      };
      const newTable = await storage.createTable(tableData);
      res.status(201).json({
        message: "\u062A\u0645 \u0625\u0646\u0634\u0627\u0621 \u0627\u0644\u0637\u0627\u0648\u0644\u0629 \u0628\u0646\u062C\u0627\u062D",
        tableId: newTable.id
      });
    } catch (error) {
      console.error("Error creating table:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0637\u0627\u0648\u0644\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u0629", errors: error.errors });
      }
      res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0625\u0646\u0634\u0627\u0621 \u0627\u0644\u0637\u0627\u0648\u0644\u0629" });
    }
  });
  app2.post("/api/game/:tableId/join", ensureAuthenticated, async (req, res) => {
    const tableId = parseInt(req.params.tableId);
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      console.log(`\u0637\u0644\u0628 \u0627\u0646\u0636\u0645\u0627\u0645 \u0645\u0646 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${req.user.id} \u0625\u0644\u0649 \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId}`, req.body);
      const requestSchema = z.object({
        position: z.number().optional(),
        asSpectator: z.boolean().optional()
        // إذا كان يريد الانضمام كمشاهد
      });
      let position = void 0;
      let asSpectator = false;
      try {
        const data = requestSchema.parse(req.body);
        position = data.position;
        asSpectator = data.asSpectator || false;
      } catch (error) {
      }
      const table = await storage.getGameTable(tableId);
      if (!table) {
        console.log(`\u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId} \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629`);
        return res.status(404).json({ success: false, message: "\u0627\u0644\u0637\u0627\u0648\u0644\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629" });
      }
      try {
        const currentState = await storage.getGameState(tableId, req.user.id);
        if (currentState) {
          const playerOnTable = currentState.players.some((p) => p.id === req.user?.id);
          if (playerOnTable) {
            console.log(`\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${req.user.id} \u0645\u0646\u0636\u0645 \u0628\u0627\u0644\u0641\u0639\u0644 \u0644\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId}`);
            return res.json({
              success: true,
              isSpectator: false,
              gameState: currentState,
              message: "\u0623\u0646\u062A \u0645\u0646\u0636\u0645 \u0628\u0627\u0644\u0641\u0639\u0644 \u0644\u0647\u0630\u0647 \u0627\u0644\u0637\u0627\u0648\u0644\u0629"
            });
          }
        }
      } catch (error) {
      }
      if (asSpectator || table.status === "full") {
        console.log(`\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${req.user.id} \u064A\u0646\u0636\u0645 \u0643\u0645\u0634\u0627\u0647\u062F \u0625\u0644\u0649 \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId}`);
        const gameState = await storage.getGameState(tableId, req.user.id);
        if (!gameState) {
          return res.status(400).json({ success: false, message: "\u0644\u0627 \u064A\u0645\u0643\u0646 \u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 \u062D\u0627\u0644\u0629 \u0627\u0644\u0644\u0639\u0628\u0629" });
        }
        return res.json({
          success: true,
          isSpectator: true,
          gameState,
          message: "\u0623\u0646\u062A \u0627\u0644\u0622\u0646 \u0641\u064A \u0648\u0636\u0639 \u0627\u0644\u0645\u0634\u0627\u0647\u062F\u0629"
        });
      }
      console.log(`\u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${req.user.id} \u064A\u062D\u0627\u0648\u0644 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0643\u0644\u0627\u0639\u0628 \u0646\u0634\u0637 \u0625\u0644\u0649 \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId}`);
      const result = await storage.joinTable(tableId, req.user.id, position);
      if (!result.success) {
        console.log(`\u0641\u0634\u0644 \u0627\u0646\u0636\u0645\u0627\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${req.user.id}: ${result.message}`);
        return res.status(400).json({ success: false, message: result.message });
      }
      console.log(`\u0646\u062C\u0627\u062D \u0627\u0646\u0636\u0645\u0627\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${req.user.id} \u0625\u0644\u0649 \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId}`);
      try {
        if (pokerModule.broadcastToTable) {
          pokerModule.broadcastToTable(tableId, {
            type: "player_joined",
            userId: req.user.id,
            username: req.user.username,
            avatar: req.user.avatar || "",
            tableId,
            timestamp: Date.now(),
            message: `\u0627\u0646\u0636\u0645 ${req.user.username} \u0625\u0644\u0649 \u0627\u0644\u0637\u0627\u0648\u0644\u0629`
          }, req.user.id);
          if (pokerModule.userTables) {
            pokerModule.userTables.set(req.user.id, tableId);
          }
        }
      } catch (err) {
        console.log("\u0644\u0627 \u064A\u0645\u0643\u0646 \u0625\u0631\u0633\u0627\u0644 \u0625\u0634\u0639\u0627\u0631 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0639\u0628\u0631 WebSocket:", err?.message || "\u062E\u0637\u0623 \u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641");
      }
      res.json({
        success: true,
        isSpectator: false,
        gameState: result.gameState,
        message: "\u062A\u0645 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0628\u0646\u062C\u0627\u062D \u0643\u0644\u0627\u0639\u0628 \u0646\u0634\u0637"
      });
    } catch (error) {
      console.error(`\u062E\u0637\u0623 \u0639\u0627\u0645 \u0623\u062B\u0646\u0627\u0621 \u0627\u0646\u0636\u0645\u0627\u0645 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645: ${error}`);
      res.status(500).json({ success: false, message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0627\u0644\u0637\u0627\u0648\u0644\u0629" });
    }
  });
  app2.get("/api/game/:tableId", ensureAuthenticated, async (req, res) => {
    const tableId = parseInt(req.params.tableId);
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      const gameState = await storage.getGameState(tableId, req.user.id);
      if (!gameState) {
        return res.status(404).json({ message: "\u0644\u0645 \u064A\u062A\u0645 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0627\u0644\u0644\u0639\u0628\u0629" });
      }
      res.json(gameState);
    } catch (error) {
      res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062C\u0644\u0628 \u062D\u0627\u0644\u0629 \u0627\u0644\u0644\u0639\u0628\u0629" });
    }
  });
  app2.post("/api/debug/reset-chips", ensureAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      const { password, amount } = req.body;
      const REQUIRED_PASSWORD = "56485645";
      if (password !== REQUIRED_PASSWORD) {
        return res.status(403).json({
          success: false,
          message: "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D\u0629"
        });
      }
      const chipsAmount = typeof amount === "number" && !isNaN(amount) ? amount : 1e6;
      let dbUpdateSuccess = false;
      try {
        await userService2.updateUserChips(
          req.user.id,
          chipsAmount,
          "reset_chips",
          "\u0625\u0639\u0627\u062F\u0629 \u062A\u0639\u064A\u064A\u0646 \u0627\u0644\u0631\u0635\u064A\u062F \u0628\u0648\u0627\u0633\u0637\u0629 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645"
        );
        dbUpdateSuccess = true;
        console.log(`\u062A\u0645 \u062A\u062D\u062F\u064A\u062B \u0631\u0635\u064A\u062F \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${req.user.id} \u0641\u064A \u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0625\u0644\u0649 ${chipsAmount}`);
      } catch (dbError) {
        console.error("\u062E\u0637\u0623 \u0641\u064A \u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0631\u0635\u064A\u062F \u0641\u064A \u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A:", dbError);
      }
      const updatedUser = await storage.updateUserChips(
        req.user.id,
        chipsAmount,
        "reset_chips",
        "\u0625\u0639\u0627\u062F\u0629 \u062A\u0639\u064A\u064A\u0646 \u0627\u0644\u0631\u0635\u064A\u062F \u0628\u0648\u0627\u0633\u0637\u0629 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645"
      );
      if (!updatedUser) {
        return res.status(500).json({ success: false, message: "\u0641\u0634\u0644 \u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0631\u0635\u064A\u062F" });
      }
      console.log(`\u062A\u0645 \u0625\u0639\u0627\u062F\u0629 \u062A\u0639\u064A\u064A\u0646 \u0631\u0635\u064A\u062F \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${req.user.id} \u0625\u0644\u0649 ${chipsAmount}`);
      res.json({
        success: true,
        message: `\u062A\u0645 \u0625\u0639\u0627\u062F\u0629 \u062A\u0639\u064A\u064A\u0646 \u0631\u0635\u064A\u062F\u0643 \u0625\u0644\u0649 ${chipsAmount} \u0631\u0642\u0627\u0642\u0629`,
        user: updatedUser
      });
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u0625\u0639\u0627\u062F\u0629 \u062A\u0639\u064A\u064A\u0646 \u0627\u0644\u0631\u0635\u064A\u062F:", error);
      res.status(500).json({ success: false, message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0625\u0639\u0627\u062F\u0629 \u062A\u0639\u064A\u064A\u0646 \u0627\u0644\u0631\u0635\u064A\u062F" });
    }
  });
  app2.post("/api/game/:tableId/action", ensureAuthenticated, async (req, res) => {
    const tableId = parseInt(req.params.tableId);
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      console.log(`\u0637\u0644\u0628 \u0625\u062C\u0631\u0627\u0621 \u0645\u0646 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${req.user.id} \u0639\u0644\u0649 \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId}:`, req.body);
      try {
        if (req.body.action === "restart_round") {
          console.log(`\u0637\u0644\u0628 \u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629 \u0645\u0646 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 ${req.user.id}`);
          const result2 = await storage.startNewRound(tableId);
          return res.json({
            success: true,
            message: "\u062A\u0645 \u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629",
            gameState: result2?.gameState
          });
        }
        const actionSchema = z.object({
          action: z.enum(["fold", "check", "call", "raise", "all_in"]),
          amount: z.number().optional()
        });
        const validatedData = actionSchema.parse(req.body);
        console.log(`\u0625\u062C\u0631\u0627\u0621 \u062A\u0645 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646\u0647:`, validatedData);
        const result = await storage.performGameAction(
          tableId,
          req.user.id,
          validatedData.action,
          validatedData.amount
        );
        console.log(`\u0646\u062A\u064A\u062C\u0629 \u0627\u0644\u0625\u062C\u0631\u0627\u0621:`, {
          success: result.success,
          message: result.message,
          hasGameState: !!result.gameState
        });
        if (!result.success) {
          return res.status(400).json({
            success: false,
            message: result.message
          });
        }
        return res.json({
          success: true,
          gameState: result.gameState,
          message: "\u062A\u0645 \u062A\u0646\u0641\u064A\u0630 \u0627\u0644\u0625\u062C\u0631\u0627\u0621 \u0628\u0646\u062C\u0627\u062D"
        });
      } catch (validationError) {
        console.error("\u062E\u0637\u0623 \u0641\u064A \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0625\u062C\u0631\u0627\u0621:", validationError);
        return res.status(400).json({
          success: false,
          message: "\u0625\u062C\u0631\u0627\u0621 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D"
        });
      }
    } catch (error) {
      res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062A\u0646\u0641\u064A\u0630 \u0627\u0644\u0625\u062C\u0631\u0627\u0621" });
    }
  });
  app2.post("/api/game/:tableId/leave", ensureAuthenticated, async (req, res) => {
    const tableId = parseInt(req.params.tableId);
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      const result = await storage.leaveTable(tableId, req.user.id);
      if (!result.success) {
        return res.status(400).json({ message: result.message });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0645\u063A\u0627\u062F\u0631\u0629 \u0627\u0644\u0637\u0627\u0648\u0644\u0629" });
    }
  });
  app2.post("/api/game/:tableId/start-round", ensureAuthenticated, async (req, res) => {
    const tableId = parseInt(req.params.tableId);
    try {
      if (!req.user) {
        return res.status(401).json({ success: false, message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      const gameState = await storage.getGameState(tableId, req.user.id);
      if (!gameState) {
        return res.status(404).json({ success: false, message: "\u0644\u0645 \u064A\u062A\u0645 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0627\u0644\u0637\u0627\u0648\u0644\u0629" });
      }
      const isPlayer = gameState.players.some((p) => p.id === req.user?.id);
      const isCurrentPlayerTurn = gameState.currentTurn === req.user?.id;
      if (!isPlayer) {
        return res.status(400).json({
          success: false,
          message: "\u064A\u062C\u0628 \u0623\u0646 \u062A\u0643\u0648\u0646 \u0644\u0627\u0639\u0628\u0627\u064B \u0639\u0644\u0649 \u0647\u0630\u0647 \u0627\u0644\u0637\u0627\u0648\u0644\u0629 \u0644\u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629"
        });
      }
      try {
        const result = await storage.startNewRound(tableId);
        if (!result || !result.success) {
          return res.status(400).json({
            success: false,
            message: result?.message || "\u0641\u0634\u0644 \u0641\u064A \u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629"
          });
        }
        const actionResult = await storage.performGameAction(tableId, req.user.id, "restart_round");
        if (pokerModule.broadcastToTable) {
          pokerModule.broadcastToTable(tableId, {
            type: "round_restarted",
            timestamp: Date.now(),
            tableId,
            initiator: req.user.username,
            message: `\u062A\u0645 \u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629 \u0628\u0648\u0627\u0633\u0637\u0629 ${req.user.username}`
          });
        }
        console.log(`\u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629 \u0641\u064A \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId} \u0628\u0648\u0627\u0633\u0637\u0629 \u0627\u0644\u0644\u0627\u0639\u0628 ${req.user.id}`);
        res.json({
          success: true,
          message: "\u062A\u0645 \u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629 \u0628\u0646\u062C\u0627\u062D",
          gameState: actionResult.gameState
        });
      } catch (error) {
        try {
          const actionResult = await storage.performGameAction(tableId, req.user.id, "restart_round");
          if (!actionResult.success) {
            return res.status(400).json({
              success: false,
              message: actionResult.message || "\u0641\u0634\u0644 \u0641\u064A \u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629"
            });
          }
          console.log(`\u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629 (\u0637\u0631\u064A\u0642\u0629 \u0628\u062F\u064A\u0644\u0629) \u0641\u064A \u0627\u0644\u0637\u0627\u0648\u0644\u0629 ${tableId} \u0628\u0648\u0627\u0633\u0637\u0629 \u0627\u0644\u0644\u0627\u0639\u0628 ${req.user.id}`);
          res.json({
            success: true,
            message: "\u062A\u0645 \u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629 \u0628\u0646\u062C\u0627\u062D (\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0637\u0631\u064A\u0642\u0629 \u0628\u062F\u064A\u0644\u0629)",
            gameState: actionResult.gameState
          });
        } catch (innerError) {
          console.error("\u0641\u0634\u0644 \u0641\u064A \u0643\u0644\u0627 \u0627\u0644\u0637\u0631\u064A\u0642\u062A\u064A\u0646 \u0644\u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629:", innerError);
          res.status(500).json({
            success: false,
            message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629"
          });
        }
      }
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629:", error);
      res.status(500).json({
        success: false,
        message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0628\u062F\u0621 \u062C\u0648\u0644\u0629 \u062C\u062F\u064A\u062F\u0629"
      });
    }
  });
  app2.post("/api/system/remove-virtual-players", async (req, res) => {
    try {
      const { password } = req.body;
      if (password !== "56485645") {
        return res.status(403).json({
          success: false,
          message: "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D\u0629"
        });
      }
      await storage.removeVirtualPlayers();
      return res.json({
        success: true,
        message: "\u062A\u0645\u062A \u0625\u0632\u0627\u0644\u0629 \u062C\u0645\u064A\u0639 \u0627\u0644\u0644\u0627\u0639\u0628\u064A\u0646 \u0627\u0644\u0648\u0647\u0645\u064A\u064A\u0646 \u0628\u0646\u062C\u0627\u062D"
      });
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0625\u0632\u0627\u0644\u0629 \u0627\u0644\u0644\u0627\u0639\u0628\u064A\u0646 \u0627\u0644\u0648\u0647\u0645\u064A\u064A\u0646:", error);
      return res.status(500).json({
        success: false,
        message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0625\u0632\u0627\u0644\u0629 \u0627\u0644\u0644\u0627\u0639\u0628\u064A\u0646 \u0627\u0644\u0648\u0647\u0645\u064A\u064A\u0646"
      });
    }
  });
  app2.get("/api/badges/categories", ensureAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      const categories = await storage.getBadgeCategories();
      res.json(categories);
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u0627\u0644\u062D\u0635\u0648\u0644 \u0639\u0644\u0649 \u0641\u0626\u0627\u062A \u0627\u0644\u0634\u0627\u0631\u0627\u062A:", error);
      res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062C\u0644\u0628 \u0641\u0626\u0627\u062A \u0627\u0644\u0634\u0627\u0631\u0627\u062A" });
    }
  });
  app2.get("/api/badges", ensureAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      const categoryId = req.query.categoryId ? parseInt(req.query.categoryId) : void 0;
      const badges2 = await storage.getBadges(categoryId);
      res.json(badges2);
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u0627\u0644\u062D\u0635\u0648\u0644 \u0639\u0644\u0649 \u0627\u0644\u0634\u0627\u0631\u0627\u062A:", error);
      res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062C\u0644\u0628 \u0627\u0644\u0634\u0627\u0631\u0627\u062A" });
    }
  });
  app2.get("/api/badges/user", ensureAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      const userBadges2 = await storage.getUserBadges(req.user.id);
      res.json(userBadges2);
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u0627\u0644\u062D\u0635\u0648\u0644 \u0639\u0644\u0649 \u0634\u0627\u0631\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645:", error);
      res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062C\u0644\u0628 \u0634\u0627\u0631\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645" });
    }
  });
  app2.post("/api/badges/award/:badgeId", ensureAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      const badgeId = parseInt(req.params.badgeId);
      if (isNaN(badgeId)) {
        return res.status(400).json({ message: "\u0645\u0639\u0631\u0641 \u0627\u0644\u0634\u0627\u0631\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D" });
      }
      const userBadge = await storage.addUserBadge(req.user.id, badgeId);
      if (!userBadge) {
        return res.status(404).json({ message: "\u0627\u0644\u0634\u0627\u0631\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629" });
      }
      res.json(userBadge);
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u0645\u0646\u062D \u0627\u0644\u0634\u0627\u0631\u0629:", error);
      res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0645\u0646\u062D \u0627\u0644\u0634\u0627\u0631\u0629" });
    }
  });
  app2.post("/api/badges/equip/:badgeId", ensureAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      const badgeId = parseInt(req.params.badgeId);
      if (isNaN(badgeId)) {
        return res.status(400).json({ message: "\u0645\u0639\u0631\u0641 \u0627\u0644\u0634\u0627\u0631\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D" });
      }
      let position = 0;
      if (req.body && req.body.position !== void 0) {
        position = parseInt(req.body.position);
        if (isNaN(position) || position < 0 || position > 5) {
          return res.status(400).json({ message: "\u0627\u0644\u0645\u0648\u0636\u0639 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D. \u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0628\u064A\u0646 0 \u0648 5." });
        }
      }
      const userBadge = await storage.equipBadge(req.user.id, badgeId, position);
      if (!userBadge) {
        return res.status(404).json({ message: "\u0627\u0644\u0634\u0627\u0631\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629 \u0623\u0648 \u063A\u064A\u0631 \u0645\u0643\u062A\u0633\u0628\u0629" });
      }
      res.json(userBadge);
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u062A\u062C\u0647\u064A\u0632 \u0627\u0644\u0634\u0627\u0631\u0629:", error);
      res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062A\u062C\u0647\u064A\u0632 \u0627\u0644\u0634\u0627\u0631\u0629" });
    }
  });
  app2.post("/api/badges/unequip/:badgeId", ensureAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      const badgeId = parseInt(req.params.badgeId);
      if (isNaN(badgeId)) {
        return res.status(400).json({ message: "\u0645\u0639\u0631\u0641 \u0627\u0644\u0634\u0627\u0631\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D" });
      }
      const userBadge = await storage.unequipBadge(req.user.id, badgeId);
      if (!userBadge) {
        return res.status(404).json({ message: "\u0627\u0644\u0634\u0627\u0631\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629 \u0623\u0648 \u063A\u064A\u0631 \u0645\u062C\u0647\u0632\u0629" });
      }
      res.json(userBadge);
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u0625\u0632\u0627\u0644\u0629 \u0627\u0644\u0634\u0627\u0631\u0629:", error);
      res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0625\u0632\u0627\u0644\u0629 \u0627\u0644\u0634\u0627\u0631\u0629" });
    }
  });
  app2.post("/api/badges/favorite/:badgeId", ensureAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      const badgeId = parseInt(req.params.badgeId);
      if (isNaN(badgeId)) {
        return res.status(400).json({ message: "\u0645\u0639\u0631\u0641 \u0627\u0644\u0634\u0627\u0631\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D" });
      }
      let order = 0;
      if (req.body && req.body.order !== void 0) {
        order = parseInt(req.body.order);
        if (isNaN(order) || order < 0) {
          return res.status(400).json({ message: "\u0627\u0644\u062A\u0631\u062A\u064A\u0628 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D. \u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0631\u0642\u0645\u064B\u0627 \u0645\u0648\u062C\u0628\u064B\u0627." });
        }
      }
      const userBadge = await storage.addToFavorites(req.user.id, badgeId, order);
      if (!userBadge) {
        return res.status(404).json({ message: "\u0627\u0644\u0634\u0627\u0631\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629 \u0623\u0648 \u063A\u064A\u0631 \u0645\u0643\u062A\u0633\u0628\u0629" });
      }
      res.json(userBadge);
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0634\u0627\u0631\u0629 \u0644\u0644\u0645\u0641\u0636\u0644\u0629:", error);
      res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0634\u0627\u0631\u0629 \u0644\u0644\u0645\u0641\u0636\u0644\u0629" });
    }
  });
  app2.post("/api/badges/unfavorite/:badgeId", ensureAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D" });
      }
      const badgeId = parseInt(req.params.badgeId);
      if (isNaN(badgeId)) {
        return res.status(400).json({ message: "\u0645\u0639\u0631\u0641 \u0627\u0644\u0634\u0627\u0631\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D" });
      }
      const userBadge = await storage.removeFromFavorites(req.user.id, badgeId);
      if (!userBadge) {
        return res.status(404).json({ message: "\u0627\u0644\u0634\u0627\u0631\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629 \u0623\u0648 \u0644\u064A\u0633\u062A \u0641\u064A \u0627\u0644\u0645\u0641\u0636\u0644\u0629" });
      }
      res.json(userBadge);
    } catch (error) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u0625\u0632\u0627\u0644\u0629 \u0627\u0644\u0634\u0627\u0631\u0629 \u0645\u0646 \u0627\u0644\u0645\u0641\u0636\u0644\u0629:", error);
      res.status(500).json({ message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0625\u0632\u0627\u0644\u0629 \u0627\u0644\u0634\u0627\u0631\u0629 \u0645\u0646 \u0627\u0644\u0645\u0641\u0636\u0644\u0629" });
    }
  });
  app2.get("/health", (req, res) => {
    res.status(200).json({
      status: "ok",
      server: "running",
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  });
  app2.get("/api/auth/check", (req, res) => {
    try {
      if (req.isAuthenticated()) {
        return res.json({
          isAuthenticated: true,
          user: req.user
        });
      } else {
        return res.json({ isAuthenticated: false });
      }
    } catch (err) {
      console.error("\u062E\u0637\u0623 \u0641\u064A \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u062D\u0627\u0644\u0629 \u0627\u0644\u0645\u0635\u0627\u062F\u0642\u0629:", err);
      return res.status(500).json({
        error: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u062D\u0627\u0644\u0629 \u0627\u0644\u0645\u0635\u0627\u062F\u0642\u0629"
      });
    }
  });
  app2.get("/auth", (req, res, next) => {
    return next();
  });
  app2.use("/api/*", (req, res) => {
    return res.status(404).json({
      success: false,
      message: "\u0646\u0642\u0637\u0629 \u0627\u0644\u0646\u0647\u0627\u064A\u0629 API \u0627\u0644\u0645\u0637\u0644\u0648\u0628\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629"
    });
  });
  app2.use((err, _req, res, _next) => {
    console.error("\u062E\u0637\u0623 \u0639\u0627\u0645:", err);
    res.status(500).json({
      success: false,
      message: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0641\u064A \u0627\u0644\u062E\u0627\u062F\u0645",
      error: process.env.NODE_ENV === "production" ? void 0 : err.message
    });
  });
  return httpServer;
}

// server/index.ts
import cookieParser from "cookie-parser";
import fileUpload from "express-fileupload";
import path4 from "path";
var app = express2();
app.use(express2.json({ limit: "10mb" }));
app.use(express2.urlencoded({ extended: false, limit: "10mb" }));
app.use(cookieParser());
app.use(fileUpload({
  limits: { fileSize: 5 * 1024 * 1024 },
  // 5MB
  useTempFiles: false,
  abortOnLimit: true,
  responseOnLimit: "\u062D\u062C\u0645 \u0627\u0644\u0645\u0644\u0641 \u062A\u062C\u0627\u0648\u0632 \u0627\u0644\u062D\u062F \u0627\u0644\u0645\u0633\u0645\u0648\u062D (5 \u0645\u064A\u062C\u0627\u0628\u0627\u064A\u062A)"
}));
app.use("/uploads", express2.static(path4.join(process.cwd(), "public/uploads")));
app.set("trust proxy", 1);
app.disable("x-powered-by");
app.use((req, res, next) => {
  if (!req.path.startsWith("/api")) {
    return next();
  }
  const start = Date.now();
  const path5 = req.path;
  res.on("finish", () => {
    const duration = Date.now() - start;
    log(`${req.method} ${path5} ${res.statusCode} in ${duration}ms`);
  });
  next();
});
(async () => {
  try {
    log("Initializing database...");
    const dbInitialized = await initializeDatabase();
    if (!dbInitialized) {
      log("Failed to initialize database. Starting server without database.", "error");
    } else {
      log("Database initialized successfully");
    }
    const server = await registerRoutes(app);
    app.use((err, _req, res, _next) => {
      const status = err.status || err.statusCode || 500;
      const message = err.message || "Internal Server Error";
      console.error(`Error: ${status} - ${message}`, err);
      if (!res.headersSent) {
        res.status(status).json({ message });
      }
    });
    if (app.get("env") === "development") {
      await setupVite(app, server);
    } else {
      serveStatic(app);
    }
    const port = 5e3;
    const host = "0.0.0.0";
    server.listen(port, host, () => {
      log(`serving on ${host}:${port}`);
    });
    process.on("SIGTERM", async () => {
      log("SIGTERM signal received. Shutting down gracefully.");
      await closeDatabase();
      process.exit(0);
    });
    process.on("SIGINT", async () => {
      log("SIGINT signal received. Shutting down gracefully.");
      await closeDatabase();
      process.exit(0);
    });
  } catch (error) {
    log(`Error starting server: ${error.message || "Unknown error"}`, "error");
    process.exit(1);
  }
})();
