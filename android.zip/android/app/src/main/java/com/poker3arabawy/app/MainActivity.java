package com.poker3arabawy.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
